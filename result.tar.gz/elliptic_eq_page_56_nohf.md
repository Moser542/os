REMARK 3.6. Functions satisfying the condition of Theorem 3.5 are called functions of bounded mean oscillation (BMO). We have the following relation:

$$
L^{\infty} \subset_{+} \text{BMO.}
$$

The counterexample is given by the following function in $(0, 1) \subset \mathbb{R}$:

$$
u(x) = \log(x).
$$

For convenience we use cubes instead of balls. We need the Calderon-Zygmund decomposition. First we introduce some terminology.

Take the unit cube $Q_0$. Cut it into $2^n$ equally sized cubes, which we take as the first generation. Do the same cutting for these small cubes to get the second generation. Continue this process. These cubes (from all generations) are called *dyadic cubes*. Any $(k+1)$-generation cube $Q$ comes from some $k$-generation cube $\tilde{Q}$, which is called the *predecessor* of $Q$.

LEMMA 3.7 Suppose $f \in L^1(Q_0)$ is nonnegative and $\alpha > |Q_0|^{-1} \int_{Q_0} f$ is a fixed constant. Then there exists a sequence of (nonoverlapping) dyadic cubes $\{Q_j\}$ in $Q_0$ such that

$$
f(x) \le \alpha \text{ a.e. in } Q_0 \setminus \bigcup_j Q_j, \quad \alpha \le \frac{1}{|Q_j|} \int_{Q_j} f \, dx < 2^n \alpha.
$$

PROOF: Cut $Q_0$ into $2^n$ dyadic cubes and keep the cube $Q$ if $|Q|^{-1} \int_Q f \ge \alpha$. For others keep cutting and always keep the cube $Q$ if $|Q|^{-1} \int_Q f \ge \alpha$ and cut the rest. Let $\{Q_j\}$ be the cubes we have kept during this infinite process. We only need to verify that

$$
f(x) \le \alpha \text{ a.e. in } Q_0 \setminus \bigcup_j Q_j.
$$

Indeed, any predecessor $Q$ of $Q_j$ that we have kept has to satisfy $\frac{1}{|Q|} \int_Q f \, dx < \alpha$. Thus for $Q_j$, one has $\alpha \le \frac{1}{|Q_j|} \int_{Q_j} f \, dx < 2^n \alpha$. Let $F = Q_0 \setminus \bigcup_j Q_j$. For any $x \in F$, from the way we collect $\{Q_j\}$, there exists a sequence of cubes $Q^i$ containing $x$ such that

$$
\frac{1}{|Q^i|} \int_{Q^i} f < \alpha \quad \text{and} \quad \text{diam}(Q^i) \to 0 \text{ as } i \to \infty.
$$

By the Lebesgue density theorem this implies that

$$
f \le \alpha \text{ a.e. in } F.
$$

□

PROOF OF THEOREM 3.5: Assume $\Omega = Q_0$. We may rewrite the assumption in terms of cubes as follows:

$$
\int_{Q} |u - u_Q| < M|Q| \quad \text{for any } Q \subset Q_0.
$$