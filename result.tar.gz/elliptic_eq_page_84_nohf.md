Note the following equivalence:

$$
\begin{aligned}
u \ge \frac{1}{2}(\alpha_1 + \beta_1) &\iff \frac{u - \beta_1}{\alpha_1 - \beta_1} \ge \frac{1}{2}, \\
u \le \frac{1}{2}(\alpha_1 + \beta_1) &\iff \frac{\alpha_1 - u}{\alpha_1 - \beta_1} \ge \frac{1}{2}.
\end{aligned}
$$

CASE 1. Suppose that

$$
\left| \left\{ x \in B_1 : \frac{2(u - \beta_1)}{\alpha_1 - \beta_1} \ge 1 \right\} \right| \ge \frac{1}{2} |B_1|.
$$

Apply the above theorem to $\frac{u-\beta_1}{\alpha_1-\beta_1} \ge 0$ in $B_1$. We have for some $C > 1$

$$
\inf_{B_{1/2}} \frac{u - \beta_1}{\alpha_1 - \beta_1} \ge \frac{1}{C},
$$

which results in the following estimate:

$$
\inf_{B_{1/2}} u \ge \beta_1 + \frac{1}{C}(\alpha_1 - \beta_1).
$$

CASE 2. Suppose

$$
\left| \left\{ x \in B_1 : \frac{2(\alpha_1 - u)}{\alpha_1 - \beta_1} \ge 1 \right\} \right| \ge \frac{1}{2} |B_1|.
$$

Similarly as in Case 1 we obtain

$$
\sup_{B_{1/2}} u \le \alpha_1 - \frac{1}{C}(\alpha_1 - \beta_1).
$$

Now set

$$
\alpha_2 = \sup_{B_{1/2}} u \quad \text{and} \quad \beta_2 = \inf_{B_{1/2}} u.
$$

Note $\beta_2 \ge \beta_1$ and $\alpha_2 \le \alpha_1$. In both cases, we have

$$
\alpha_2 - \beta_2 \le \left(1 - \frac{1}{C}\right)(\alpha_1 - \beta_1).
$$

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAeCAIAAABSe/KxAAAAcElEQVR4nO3VMQ7AIAgF0E/jyCEdPY6jR3DzDp7JWZxq2q6QJk35Ey4vEEkgEYFpDlvut2LYVe+9lDLn1HDMDDkTY9S2B+A69RgDQK1VFLmJVov5hb920UUXXXTxLTE83jnn1pqK3GcspaSCAABEtAC7UWYAqFTG+QAAAABJRU5ErkJggg==)

The De Giorgi theorem is an easy consequence of the above results.

THEOREM 4.11 (De Giorgi) Suppose $Lu = 0$ weakly in $B_1$. Then there holds

$$
\sup_{B_{1/2}} |u(x)| + \sup_{x,y \in B_{1/2}} \frac{|u(x) - u(y)|}{|x - y|^\alpha} \le c \left(n, \frac{\Lambda}{\lambda}\right) \|u\|_{L^2(B_1)}
$$

with $\alpha = \alpha(n, \frac{\Lambda}{\lambda}) \in (0, 1)$.

In the rest of the section we will discuss the Hölder continuity of solutions to general linear equations. We need the following lemma: