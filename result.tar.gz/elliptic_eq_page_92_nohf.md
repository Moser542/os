since $I_0$ is bounded in (4.12). Hence we obtain for $\beta \ge 1$

$$
\int_{B_{\tau}} |w|^{\beta} dx \le C_{0}^{\beta} \beta^{\beta} \le C_{0}^{\beta} e^{\beta} \beta!
$$

where we used the Sterling formula for integer $\beta$. Hence for integer $\beta \ge 1$

$$
\int_{B_{\tau}} \frac{(p_0|w|)^\beta}{\beta!} \le p_0^\beta (C_0 e)^\beta \le \frac{1}{2^\beta}
$$

by choosing $p_0 = (2C_0e)^{-1}$. This proves that

$$
\int e^{p_0|w|} = \int 1 + p_0|w| + \frac{(p_0|w|)^2}{2!} + \dots \le 1 + \frac{1}{2^1} + \frac{1}{2^2} + \dots \le 2.
$$

REMARK 4.16. The above method, avoiding BMO, is elementary in nature.

Now we give the second proof of estimate (4.8). Estimate (4.10) gives

$$
\int_{B_1} |Dw|^2 \zeta^2 \le C \int_{B_1} |D\zeta|^2 \quad \text{for any } \zeta \in C_0^1(B_1).
$$

Then for any $B_{2r}(y) \subset B_1$ choose $\zeta$ with

$$
\text{supp } \zeta \subset B_{2r}(y), \quad \zeta \equiv 1 \text{ in } B_r(y), \quad |D\zeta| \le \frac{2}{r}.
$$

Then we obtain

$$
\int_{B_r(y)} |Dw|^2 \le C r^{n-2}.
$$

Hence the Poincaré inequality implies

$$
\begin{aligned} \frac{1}{r^n} \int_{B_r(y)} |w - w_{y,r}| &\le \frac{1}{r^{n/2}} \left( \int_{B_r(y)} |w - w_{y,r}|^2 \right)^{1/2} \\ &\le \frac{1}{r^{n/2}} \left( r^2 \int_{B_r(y)} |Dw|^2 \right)^{1/2} \le C, \end{aligned}
$$

that is, $w \in \text{BMO}$. Then the John-Nirenberg lemma implies

$$
\int_{B_{\tau}} e^{p_0|w|} \le C.
$$

Step 2. The result holds for any positive $p < \frac{n}{n-2}$.

We need to prove for any $0 < r_1 < r_2 < 1$ and $0 < p_2 < p_1 < \frac{n}{n-2}$ there holds

$$
(4.13) \qquad \left( \int_{B_{r_1}} \bar{u}^{p_1} \right)^{\frac{1}{p_1}} \le C \left( \int_{B_{r_2}} \bar{u}^{p_2} \right)^{\frac{1}{p_2}}
$$