such position, that is, the whole surface $y = u(x)$ lies below the plane. Clearly at such a point, the function $u$ is positive. $\square$

PROOF OF THEOREM 2.21: We should choose $g$ appropriately in order to apply Lemma 2.24. Note if $f \equiv 0$ and $c \equiv 0$ then $(-a_{ij} D_{ij} u)^n \le |b|^n |Du|^n$ in $\Omega$. This suggests that we should take $g(p) = |p|^{-n}$. However, such a function is not locally integrable (at the origin). Hence we will choose $g(p) = (|p|^n + \mu^n)^{-1}$ and then let $\mu \to 0^+$.

First we have by the Cauchy inequality

$$
\begin{align*}
-a_{ij} D_{ij} &\le b_i D_i u + cu - f \\
&\le b_i D_i u - f \quad \text{in } \Omega^+ = \{x : u(x) > 0\} \\
&\le |b| \cdot |Du| + f^- \\
&\le \left( |b|^n + \frac{(f^-)^n}{\mu^n} \right)^{1/n} \cdot (|Du|^n + \mu^n)^{1/n} \cdot (1+1)^{\frac{n-2}{n}};
\end{align*}
$$

in particular,

$$
(=a_{ij} D_{ij} u)^n \le \left( |b|^n + \left( \frac{f^-}{\mu} \right)^n \right) (|Du|^n + \mu^n) \cdot 2^{n-2}.
$$

Now we choose

$$
g(p) = \frac{1}{|p|^n + \mu^n}.
$$

By Lemma 2.24 we have

$$
\int_{B_{\tilde{M}}(0)} g \le \frac{2^{n-2}}{n^n} \int_{\Gamma^+ \cap \Omega^+} \frac{|b^n| + \mu^{-n} (f^-)^n}{D}.
$$

We evaluate the integral in the left-hand side in the following way:

$$
\begin{align*}
\int_{B_{\tilde{M}}(0)} g &= \omega_n \int_0^{\tilde{M}} \frac{r^{n-1}}{r^n + \mu^n} dr = \frac{\omega_n}{n} \log \frac{\tilde{M}^n + \mu^n}{\mu^n} \\
&= \frac{\omega_n}{n} \log \left( \frac{\tilde{M}^n}{\mu^n} + 1 \right).
\end{align*}
$$

Therefore we obtain

$$
\tilde{M}^n \le \mu^n \left\{ \exp \left\{ \frac{2^{n-2}}{\omega_n n^n} \left[ \left\| \frac{b}{D^*} \right\|_{L^n(\Gamma^+ \cap \Omega^+)}^n + \mu^{-n} \left\| \frac{f^-}{D^*} \right\|_{L^n(\Gamma^+ \cap \Omega^+)}^n \right] \right\} - 1 \right\}.
$$

If $f \ne 0$, we choose $\mu = \|\frac{f^-}{D^*}\|_{L^n(\Gamma^+ \cap \Omega^+)}$. If $f \ne 0$, we may choose any $\mu > 0$ and then let $\mu \to 0$. $\square$

In what follows we use Theorem 2.21 and Lemma 2.24 to derive some a priori estimates for solutions to quasi-linear equations and fully nonlinear equations. In the next result we do not assume uniform ellipticity.