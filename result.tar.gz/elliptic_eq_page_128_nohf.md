Next, we solve (6.1) by the Perron method. Set

$$
(6.2) \quad u_{\varphi}(x) = \sup\{v(x) : v \in C(\bar{\Omega}) \text{ is subharmonic in } \Omega \text{ and } v \le \varphi \text{ on } \partial\Omega\}.
$$

In the first step in the Perron method, we prove that $u_{\varphi}$ in (6.2) is a harmonic function in $\Omega$.

LEMMA 6.4 Let $\Omega$ be a bounded domain in $\mathbb{R}^n$ and $\varphi$ be a continuous function on $\partial\Omega$. Then $u_{\varphi}$ defined in (6.2) is harmonic in $\Omega$.

PROOF: Set

$$
S_{\varphi} = \{v : v \in C(\bar{\Omega}) \text{ is subharmonic in } \Omega \text{ and } v \le \varphi \text{ on } \partial\Omega\}.
$$

Then for any $x \in \Omega$

$$
u_{\varphi}(x) = \sup\{v(x) : v \in S_{\varphi}\}.
$$

In the following, we simply write $S = S_{\varphi}$.

Step 1. We prove that $u_{\varphi}$ is well defined. To do this, we set

$$
m = \min_{\partial\Omega} \varphi, \quad M = \max_{\partial\Omega} \varphi.
$$

We note that the constant function $m$ is in $S$ and hence the set $S$ is not empty. Next, the constant function $M$ is obviously harmonic in $\Omega$ with $\varphi \le M$ on $\partial\Omega$. By Lemma 6.2, for any $v \in S$

$$
v \le M \quad \text{in } \bar{\Omega}.
$$

Thus $u_{\varphi}$ is well defined and $u_{\varphi} \le M$ in $\Omega$.

Step 2. We claim that $S$ is closed by taking the maximum among finitely many functions in $S$. We take arbitrary $v_1, v_2, \dots, v_k \in S$ and set

$$
v = \max\{v_1, v_2, \dots, v_k\}.
$$

It follows easily from Definition 6.1 that $v$ is subharmonic in $\Omega$. Hence $v \in S$.

Step 3. We prove that $u_{\varphi}$ is harmonic in any $B_r(x_0) \subset \Omega$. First, by the definition of $u_{\varphi}$, there exists a sequence of functions $v_i \in S$ such that

$$
\lim_{i \to \infty} v_i(x_0) = u_{\varphi}(x_0).
$$

We may replace $v_i$ above by any $\tilde{v}_i \in S$ with $\tilde{v}_i \ge v_i$ since

$$
v_i(x_0) \le \tilde{v}_i(x_0) \le u_{\varphi}(x_0).
$$

Replacing, if necessary, $v_i$ by $\max\{m, v_i\} \in S$, we may also assume

$$
m \le v_i \le u_{\varphi} \quad \text{in } \Omega.
$$

For the fixed $B_r(x_0)$ and each $v_i$, we let $w_i$ be the harmonic lifting in Lemma 6.3. In other words, $w_i = v_i$ in $\Omega \setminus B_r(x_0)$ and

$$
\begin{aligned} \Delta w_i &= 0 \quad \text{in } B_r(x_0), \\ w_i &= v_i \quad \text{on } \partial B_r(x_0). \end{aligned}
$$