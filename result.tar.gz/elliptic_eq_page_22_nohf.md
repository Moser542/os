Take a nonnegative function $\varphi \in C_0^1(B_1)$. We obtain by the Hölder inequality

$$
\begin{align*}
\Delta(\varphi w) + 2 \sum_{i=1}^{n} D_i v D_i(\varphi w) \\
&= 2\varphi \sum_{i,j=1}^{n} (D_{ij} v)^2 + 4 \sum_{i,j=1}^{n} D_i \varphi D_j v D_{ij} v + 2w \sum_{i=1}^{n} D_i \varphi D_i v + (\Delta \varphi) w \\
&\geq \varphi \sum_{i,j=1}^{n} (D_{ij} v)^2 - 2|D\varphi||Dv|^3 - \left( |\Delta\varphi| + C \frac{|D\varphi|^2}{\varphi} \right) |Dv|^2
\end{align*}
$$

if $\varphi$ is chosen such that $|D\varphi|^2/\varphi$ is bounded in $B_1$. Choose $\varphi = \eta^4$ for some $\eta \in C_0^1(B_1)$. Hence for such fixed $\eta$ we obtain by (1.1)

$$
\begin{align*}
\Delta(\eta^4 w) + 2 \sum_{i=1}^{n} D_i v D_i(\eta^4 w) \\
&\geq \frac{1}{n} \eta^4 |Dv|^4 - C \eta^3 |D\eta| |Dv|^3 - 4 \eta^2 (\eta \Delta \eta + C |D\eta|^2) |Dv|^2 \\
&\geq \frac{1}{n} \eta^4 |Dv|^4 - C \eta^3 |Dv|^3 - C \eta^2 |Dv|^2
\end{align*}
$$

where $C$ is a positive constant depending only on $n$ and $\eta$. Hence we get by the Hölder inequality

$$
\Delta(\eta^4 w) + 2 \sum_{i=1}^{n} D_i v D_i(\eta^4 w) \geq \frac{1}{n} \eta^4 w^2 - C
$$

where $C$ is a positive constant depending only on $n$ and $\eta$.

Suppose $\eta^4 w$ attains its maximum at $x_0 \in B_1$. Then $D(\eta^4 w) = 0$ and $\Delta(\eta^4 w) \le 0$ at $x_0$. Hence there holds

$$
\eta^4 w^2(x_0) \le C(n, \eta).
$$

If $w(x_0) \ge 1$, then $\eta^4 w(x_0) \le C(n)$. Otherwise $\eta^4 w(x_0) \le w(x_0) \le \eta^4(x_0)$. In both cases we conclude

$$
\eta^4 w \le C(n, \eta) \quad \text{in } B_1.
$$

□

COROLLARY 1.33 Suppose $u$ is a nonnegative harmonic function in $B_1$. Then there holds

$$
u(x_1) \le C u(x_2) \quad \text{for any } x_1, x_2 \in B_{1/2}
$$

where $C$ is a positive constant depending only on $n$.

PROOF: We may assume $u > 0$ in $B_1$. For any $x_1, x_2 \in B_{1/2}$ by simple integration we obtain with Lemma 1.32

$$
\log \frac{u(x_1)}{u(x_2)} \le |x_1 - x_2| \int_0^1 |D \log u(tx_2 + (1-t)x_1)| dt \le C |x_1 - x_2|.
$$

□