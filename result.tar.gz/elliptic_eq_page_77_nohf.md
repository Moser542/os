Set $\gamma = \beta + 2 \ge 2$. Then we obtain

$$
\left( \int_{B_r} \bar{u}_m^{\gamma \chi} \right)^{1/\chi} \le C \frac{(\gamma - 1)^\alpha}{(R - r)^2} \int_{B_R} \bar{u}^\gamma
$$

provided the integral in the right-hand side is bounded. By letting $m \to +\infty$ we conclude that

$$
\|\bar{u}\|_{L^{\gamma\chi}(B_r)} \le \left( C \frac{(\gamma - 1)^\alpha}{(R - r)^2} \right)^{1/\gamma} \|\bar{u}\|_{L^\gamma(B_R)}
$$

provided $\|\bar{u}\|_{L^\gamma(B_R)} < +\infty$, where $C = C(n, q, \lambda, \Lambda)$ is a positive constant independent of $\gamma$. The above estimate suggests that we iterate, beginning with $\gamma = 2$, as $2, 2\chi, 2\chi^2, \dots$. Now set for $i = 0, 1, \dots$,

$$
\gamma_i = 2\chi^i \quad \text{and} \quad r_i = \frac{1}{2} + \frac{1}{2^{i+1}}.
$$

By $\gamma_i = \chi\gamma_{i-1}$ and $r_{i-1} - r_i = 1/2^{i+1}$, we have for $i = 1, 2, \dots$,

$$
\|\bar{u}\|_{L^{\gamma_i}(B_{r_i})} \le C(n, q, \lambda, \Lambda)^{\frac{i}{\chi^i}} \|\bar{u}\|_{L^{\gamma_{i-1}}(B_{r_{i-1}})}
$$

provided $\|\bar{u}\|_{L^{\gamma_{i-1}}(B_{r_{i-1}})} < +\infty$. Hence by iteration we obtain

$$
\|\bar{u}\|_{L^{\gamma_i}(B_{r_i})} \le C^{\sum \frac{i}{\chi^i}} \|\bar{u}\|_{L^2(B_1)};
$$

in particular,

$$
\left( \int_{B_{1/2}} \bar{u}^{2\chi^i} \right)^{\frac{1}{2\chi^i}} \le C \left( \int_{B_1} \bar{u}^2 \right)^{\frac{1}{2}}.
$$

Letting $i \to +\infty$ we get

$$
\sup_{B_{1/2}} \bar{u} \le C \|\bar{u}\|_{L^2(B_1)} \quad \text{or} \quad \sup_{B_{1/2}} u^+ \le C \{\|u^+\|_{L^2(B_1)} + k\}.
$$

Recall the definition of $k$. This finishes the proof for $p = 2$. $\square$

REMARK 4.2. If the subsolution $u$ is bounded, we may simply take the test function

$$
\varphi = \eta^2(\bar{u}^{\beta+1} - k^{\beta+1}) \in H_0^1(B_1)
$$

for some $\beta \ge 0$ and some nonnegative function $\eta \in C_0^1(B_1)$.

Next we discuss the general $p$ case of Theorem 4.1. This is based on a dilation argument.

Take any $R \le 1$. Define

$$
\tilde{u}(y) = u(Ry) \quad \text{for } y \in B_1.
$$

It is easy to see that $\tilde{u}$ satisfies the following equation:

$$
\int_{B_1} \tilde{a}_{ij} D_i \tilde{u} D_j \varphi + \tilde{c} \tilde{u} \varphi \le \int_{B_1} \tilde{f} \varphi \quad \text{for any } \varphi \in H_0^1(B_1) \text{ and } \varphi \ge 0 \text{ in } B_1
$$