By definition of $h$, we have

$$
\frac{\partial h}{\partial \nu}(x_0) < 0.
$$

This finishes the proof.

□

**THEOREM 2.7 (Strong Maximum Principle)** Let $u \in C^2(\Omega) \cap C(\bar{\Omega})$ satisfy $Lu \ge 0$ with $c(x) \le 0$ in $\Omega$. Then the nonnegative maximum of $u$ in $\bar{\Omega}$ can be assumed only on $\partial\Omega$ unless $u$ is a constant.

**PROOF:** Let $M$ be the nonnegative maximum of $u$ in $\bar{\Omega}$. Set $\Sigma = \{x \in \Omega : u(x) = M\}$. It is relatively closed in $\Omega$. We need to show $\Sigma = \Omega$.

We prove by contradiction. If $\Sigma$ is a proper subset of $\Omega$, then we may find an open ball $B \subset \Omega \setminus \Sigma$ with a point on its boundary belonging to $\Sigma$. (In fact, we may choose a point $p \in \Omega \setminus \Sigma$ such that $d(p, \Sigma) < d(p, \partial\Omega)$ first and then extend the ball centered at $p$. It hits $\Sigma$ before hitting $\partial\Omega$.) Suppose $x_0 \in \partial B \cap \Sigma$. Obviously we have $Lu \ge 0$ in $B$ and

$$
u(x) < u(x_0) \text{ for any } x \in B \text{ and } u(x_0) = M \ge 0.
$$

Theorem 2.5 implies $\frac{\partial u}{\partial n}(x_0) > 0$ where $\mathbf{n}$ is the outward normal direction at $x_0$ to the ball $B$. Since $x_0$ is the interior maximal point of $\Omega$, $Du(x_0) = 0$. This leads to a contradiction. □

**COROLLARY 2.8 (Comparison Principle)** Suppose $u \in C^2(\Omega) \cap C(\bar{\Omega})$ satisfies $Lu \ge 0$ in $\Omega$ with $c(x) \le 0$ in $\Omega$. If $u \le 0$ on $\partial\Omega$, then $u \le 0$ in $\Omega$. In fact, either $u < 0$ in $\Omega$ or $u \equiv 0$ in $\Omega$.

In order to discuss the boundary value problem with general boundary condition, we need the following result, which is just a corollary of Theorems 2.5 and 2.7.

**COROLLARY 2.9** Suppose $\Omega$ has the interior sphere property and that $u \in C^2(\Omega) \cap C^1(\bar{\Omega})$ satisfies $Lu \ge 0$ in $\Omega$ with $c(x) \le 0$. Assume $u$ attains its nonnegative maximum at $x_0 \in \bar{\Omega}$. Then $x_0 \in \partial\Omega$ and for any outward direction $\mathbf{v}$ at $x_0$ to $\partial\Omega$

$$
\frac{\partial u}{\partial \nu}(x_0) > 0
$$

unless $u$ is constant in $\bar{\Omega}$.

**APPLICATION.** Suppose $\Omega$ is bounded in $\mathbb{R}^n$ and satisfies the interior sphere property. Consider the following boundary value problem

$$
(*) \qquad \begin{aligned} Lu &= f & \text{in } \Omega \\ \frac{\partial u}{\partial n} + \alpha(x)u &= \varphi & \text{on } \partial\Omega \end{aligned}
$$

for some $f \in C(\bar{\Omega})$ and $\varphi \in C(\partial\Omega)$. Assume in addition that $c(x) \le 0$ in $\Omega$ and $\alpha(x) \ge 0$ on $\partial\Omega$. Then problem (*) has a unique solution $u \in C^2(\Omega) \cap C^1(\bar{\Omega})$ if $c \ne 0$ or $\alpha \ne 0$. If $c \equiv 0$ and $\alpha \equiv 0$, problem (*) has a unique solution $u \in C^2(\Omega) \cap C^1(\bar{\Omega})$ up to additive constants.