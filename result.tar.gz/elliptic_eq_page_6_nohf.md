# Harmonic Functions

## 1.1. Guide

In this chapter we will use various methods to study harmonic functions. These include mean value properties, fundamental solutions, maximum principles, and energy methods. The four sections in this chapter are relatively independent of each other.

The materials in this chapter are rather elementary, but they contain several important ideas on the whole subject, and thus should be covered thoroughly. While doing Sections 1.2 and 1.3, the classic book by Protter and Weinberger [13] may be a very good reference. Also, when one reads Section 1.4, some statements concerning the Hopf maximal principle in Section 2.2 can be selected as exercises. The interior gradient estimates of Section 2.4 follow from the same arguments as those in the proof of Proposition 1.31 in Section 1.4.

## 1.2. Mean Value Properties

We begin this section with the definition of mean value properties. We assume that $\Omega$ is a connected domain in $\mathbb{R}^n$.

DEFINITION 1.1 For $u \in C(\Omega)$ we define

(i) $u$ satisfies the first mean value property if

$$
u(x) = \frac{1}{\omega_n r^{n-1}} \int_{\partial B_r(x)} u(y)dS_y \quad \text{for any } B_r(x) \subset \Omega;
$$

(ii) $u$ satisfies the second mean value property if

$$
u(x) = \frac{n}{\omega_n r^n} \int_{B_r(x)} u(y)dy \quad \text{for any } B_r(x) \subset \Omega
$$

where $\omega_n$ denotes the surface area of the unit sphere in $\mathbb{R}^n$.

REMARK 1.2. These two definitions are equivalent. In fact, if we write (i) as

$$
u(x)r^{n-1} = \frac{1}{\omega_n} \int_{\partial B_r(x)} u(y)dS_y,
$$