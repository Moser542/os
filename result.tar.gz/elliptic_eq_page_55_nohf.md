LEMMA 3.4 Let $\phi(t)$ be a nonnegative and nondecreasing function on $[0, R]$. Suppose that

$$
\phi(\rho) \le A \left[ \left( \frac{\rho}{r} \right)^{\alpha} + \varepsilon \right] \phi(r) + Br^{\beta}
$$

for any $0 < \rho \le r \le R$, with $A, B, \alpha, \beta$ nonnegative constants and $\beta < \alpha$. Then for any $\gamma \in (\beta, \alpha)$, there exists a constant $\varepsilon_0 = \varepsilon_0(A, \alpha, \beta, \gamma)$ such that if $\varepsilon < \varepsilon_0$ we have for all $0 < \rho \le r \le R$

$$
\phi(\rho) \le c \left\{ \left( \frac{\rho}{r} \right)^{\gamma} \phi(r) + B \rho^{\beta} \right\}
$$

where $c$ is a positive constant depending on $A, \alpha, \beta, \gamma$. In particular, we have for any $0 < r \le R$

$$
\phi(r) \le c \left\{ \frac{\phi(R)}{R^{\gamma}} r^{\gamma} + Br^{\beta} \right\}.
$$

PROOF: For $\tau \in (0, 1)$ and $r < R$, we have

$$
\phi(\tau r) \le A \tau^{\alpha} [1 + \varepsilon \tau^{-\alpha}] \phi(r) + Br^{\beta}.
$$

Choose $\tau < 1$ in such a way that $2A\tau^\alpha = \tau^\gamma$ and assume $\varepsilon_0\tau^{-\alpha} < 1$. Then we get for every $r < R$

$$
\phi(\tau r) \le \tau^{\gamma} \phi(r) + Br^{\beta}
$$

and therefore for all integers $k > 0$

$$
\begin{aligned} \phi(\tau^{k+1}r) &\le \tau^{\gamma} \phi(\tau^k r) + B \tau^{k\beta} r^{\beta} \le \tau^{(k+1)\gamma} \phi(r) + B \tau^{k\beta} r^{\beta} \sum_{j=0}^{k} \tau^{j(\gamma-\beta)} \\ &\le \tau^{(k+1)\gamma} \phi(r) + \frac{B \tau^{k\beta} r^{\beta}}{1 - \tau^{\gamma-\beta}}. \end{aligned}
$$

By choosing $k$ such that $\tau^{k+2}r < \rho \le \tau^{k+1}r$, the last inequality gives

$$
\phi(\rho) \le \frac{1}{\tau^{\gamma}} \left(\frac{\rho}{r}\right)^{\gamma} \phi(r) + \frac{B\rho^{\beta}}{\tau^{2\beta}(1 - \tau^{\gamma-\beta})}.
$$

□

In the rest of this section we discuss functions of bounded mean oscillation (BMO). The following result was proved by John and Nirenberg.

THEOREM 3.5 (John-Nirenberg Lemma) Suppose $u \in L^1(\Omega)$ satisfies

$$
\int_{B_r(x)} |u - u_{x,r}| \le M r^n \quad \text{for any } B_r(x) \subset \Omega.
$$

Then there holds for any $B_r(x) \subset \Omega$

$$
\int_{B_r(x)} e^{\frac{p_0}{M} |u - u_{x,r}|} \le C r^n
$$

for some positive $p_0$ and $C$ depending only on $n$.