and

$$
(3.15) \qquad \int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le C \left\{ \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + r^{2\alpha} \int_{B_r(x_0)} |Du|^2 + r^{n+2\alpha} \|f\|_{L^q(B_1)}^2 \right\}.
$$

We need to estimate the integral $\int_{B_r(x_0)} |Du|^2$. Write $\chi(F) = \|f\|_{L^q(B_1)}^2$. Take small $\delta > 0$. Then (3.14) implies

$$
\int_{B_{\rho}(x_0)} |Du|^2 \le C \left\{ \left[ \left(\frac{\rho}{r}\right)^n + r^{2\alpha} \right] \int_{B_r(x_0)} |Du|^2 + r^{n-2\delta} \chi(F) \right\}.
$$

Hence Lemma 3.4 implies the existence of an $R_1 \in (\frac{3}{4}, 1)$ with $r_1 = 1 - R_1$ such that for any $x_0 \in B_{R_1}$ and any $0 < r \le r_1$ there holds

$$
(3.16) \qquad \int_{B_r(x_0)} |Du|^2 \le C r^{n-2\delta} \{\chi(F) + \|Du\|_{L^2(B_1)}^2\}.
$$

Therefore by substituting (3.16) in (3.15) we obtain for any $0 < \rho < r \le r_1$

$$
\int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le C \left\{ \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + r^{n+2\alpha-2\delta} [\chi(F) + \|Du\|_{L^2(B_1)}^2] \right\}.
$$

By Lemma 3.4 again, there holds for any $x_0 \in B_{R_1}$ and any $0 < \rho < r \le r_1$

$$
\int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le C \left\{ \left(\frac{\rho}{r}\right)^{n+2\alpha-2\delta} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + r^{n+2\alpha-2\delta} [\chi(F) + \|Du\|_{L^2(B_1)}^2] \right\}.
$$

With $r = r_1$ this implies that for any $x_0 \in B_{R_1}$ and any $0 < r \le r_1$

$$
\int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 \le C r^{n+2\alpha-2\delta} \{\chi(F) + \|Du\|_{L^2(B_1)}^2\}.
$$