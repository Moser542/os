(1) Prove directly.

(2) Prove that $w \in \text{BMO}$, that is, for any $B_r(y) \subset B_1(0)$

$$
\frac{1}{r^n} \int_{B_r} |w - w_{y,r}| dx \le C.
$$

Then (4.8) follows from Theorem 3.5 (John-Nirenberg lemma).

We shall prove (4.8) directly first. Recall $\bar{u} = u + k \ge k > 0$. Note that

$$
e^{p_0|w|} = 1 + p_0|w| + \frac{(p_0|w|)^2}{2!} + \dots + \frac{(p_0|w|)^n}{n!} + \dots .
$$

Hence we need to estimate $\int_{B_\tau} |w|^\beta$ for each positive integer $\beta$.

We first derive the equation for $w$. Consider $\bar{u}^{-1}\varphi$ as test function in $(*)$. Here we need $\varphi \in L^\infty(B_1) \cap H_0^1(B_1)$ with $\varphi \ge 0$. By direct calculation as before and by the fact that $Dw = \bar{u}^{-1}D\bar{u}$, we have

$$
(4.9) \qquad \int_{B_1} a_{ij} D_i w D_j w \varphi \le \int_{B_1} a_{ij} D_i w D_j \varphi + \int_{B_1} (-\tilde{f} \varphi)
$$

for any $\varphi \in L^\infty(B_1) \cap H_0^1(B_1)$ with $\varphi \ge 0$. Replace $\varphi$ by $\varphi^2$ in (4.9). The Hölder inequality implies

$$
\int_{B_1} |Dw|^2 \varphi^2 \le C \left\{ \int_{B_1} |D\varphi|^2 + \int_{B_1} |\tilde{f}| \varphi^2 \right\}.
$$

By the Hölder and Sobolev inequalities we obtain

$$
\int_{B_1} |\tilde{f}| \varphi^2 \le \|\tilde{f}\|_{L^{n/2}} \|\varphi\|_{L^{2n/(n-2)}}^2 \le c(n, q) \|D\varphi\|_{L^2}^2.
$$

Therefore we have

$$
(4.10) \qquad \int_{B_1} |Dw|^2 \varphi^2 \le C \int_{B_1} |D\varphi|^2
$$

with $C = C(n, q, \lambda, \Lambda) > 0$. Take $\varphi \in C_0^1(B_1)$ with $\varphi \equiv 1$ in $B_\tau$. Then we obtain

$$
(4.11) \qquad \int_{B_\tau} |Dw|^2 \le C(n, q, \lambda, \Lambda, \tau).
$$

Hence the Poincaré inequality implies

$$
\int_{B_\tau} w^2 \le c(n, \tau) \int_{B_\tau} |Dw|^2 \le C(n, q, \lambda, \Lambda, \tau)
$$

since $\int_{B_\tau} w = 0$. Furthermore, we conclude from (4.10)

$$
(4.12) \qquad \int_{B_{\tau'}} w^2 \le C(n, q, \lambda, \Lambda, \tau, \tau')
$$