LEMMA 1.11 Suppose $u \in C(\bar{B}_R)$ is a nonnegative harmonic function in $B_R = B_R(x_0)$. Then there holds

$$
|Du(x_0)| \le \frac{n}{R}u(x_0).
$$

PROOF: As before by the divergence theorem and the nonnegativeness of $u$ we have

$$
|D_{x_i} u(x_0)| \le \frac{n}{\omega_n R^n} \int_{\partial B_R(x_0)} u(y) dS_y = \frac{n}{R} u(x_0)
$$

where in the last equality we used the mean value property.

□

COROLLARY 1.12 A harmonic function in $\mathbb{R}^n$ bounded from above or below is constant.

PROOF: Suppose $u$ is a harmonic function in $\mathbb{R}^n$. We will prove that $u$ is a constant if $u \ge 0$. In fact, for any $x \in \mathbb{R}^n$ we apply Lemma 1.11 to $u$ in $B_R(x)$ and then let $R \to \infty$. We conclude that $Du(x) = 0$ for any $x \in \mathbb{R}^n$. □

PROPOSITION 1.13 Suppose $u \in C(\bar{B}_R)$ is harmonic in $B_R = B_R(x_0)$. Then there holds for any multi-index $\alpha$ with $|\alpha| = m$

$$
|D^\alpha u(x_0)| \le \frac{n^m e^{m-1} m!}{R^m} \max_{\bar{B}_R} |u|.
$$

PROOF: We prove by induction. It is true for $m = 1$ by Lemma 1.10. Assume it holds for $m$. Consider $m + 1$. For $0 < \theta < 1$, define $r = (1 - \theta)R \in (0, R)$. We apply Lemma 1.10 to $u$ in $B_r$ and get

$$
|D^{m+1} u(x_0)| \le \frac{n}{r} \max_{\bar{B}_r} |D^m u|.
$$

By the induction assumption we have

$$
\max_{\bar{B}_r} |D^m u| \le \frac{n^m \cdot e^{m-1} \cdot m!}{(R-r)^m} \max_{\bar{B}_R} |u|.
$$

Hence we obtain

$$
|D^{m+1} u(x_0)| \le \frac{n}{r} \cdot \frac{n^m e^{m-1} m!}{(R-r)^m} \max_{B_R} |u| = \frac{n^{m+1} e^{m-1} m!}{R^{m+1} \theta^m (1-\theta)} \max_{\bar{B}_R} |u|.
$$

Take $\theta = \frac{m}{m+1}$. This implies

$$
\frac{1}{\theta^m (1-\theta)} = \left(1 + \frac{1}{m}\right)^m (m+1) < e(m+1).
$$

Hence the result is established for any single derivative. For any multi-index $\alpha = (\alpha_1, \dots, \alpha_n)$ we have

$$
\alpha_1! \cdots \alpha_n! \le (|\alpha|)!.
$$

□

THEOREM 1.14 Harmonic function is analytic.