EXAMPLE. Consider the equation $-\Delta u = |Du|^2$ in the ball $B_R(0)$ in $\mathbb{R}^2$ with $R < 1$. It is easy to check that $u(x) = \log \log |x|^{-1} - \log \log R^{-1} \in H^1(B_R(0))$ is a weak solution with zero boundary data. Note that $u(x) \equiv 0$ is also a solution.

In this section we always assume $a_{ij} \in L^\infty(B_1)$ satisfies

$$
\lambda|\xi|^2 \le a_{ij}(x)\xi_i\xi_j \le \Lambda|\xi|^2 \quad \text{for any } x \in B_1, \xi \in \mathbb{R}^n,
$$

for some positive constants $\lambda$ and $\Lambda$. We consider the nonlinear equation of the form

$$
(*) \quad \int a_{ij}(x) D_i u D_j \varphi = \int b(x, u, Du) \varphi \quad \text{for any } \varphi \in H_0^1(B_1) \cap L^\infty(B_1).
$$

We say the nonlinear term $b$ satisfies the natural growth condition if

$$
|b(x, u, p)| \le C(u)(f(x) + |p|^2) \quad \text{for any } (x, u, p) \in B_1 \times \mathbb{R} \times \mathbb{R}^n
$$

for some constant $C(u)$ depending only on $u$ and $f \in L^q(B_1)$ for some $q \ge \frac{2n}{n+2}$. We always assume

$$
u \in H^1(B_1) \cap L^\infty(B_1).
$$

LEMMA 4.21 Suppose $u \in H^1(B_1)$ is a nonnegative solution of (*) with $|u| \le M$ in $B_1$ and that $b$ satisfies the natural growth condition with $f(x) \in L^q(B_1)$ for some $q > \frac{n}{2}$. Then for any $B_R \subset B_1$ there holds

$$
\sup_{B_{R/2}} u \le C \left\{ \inf_{B_{R/2}} u + R^{2-\frac{n}{q}} \left( \int_{B_R} |f|^q \right)^{\frac{1}{q}} \right\}
$$

where $C$ is a positive constant depending only on $n, \lambda, \Lambda, M$, and $q$.

PROOF: Let $v = \frac{1}{\alpha}(e^{\alpha u} - 1)$ for some $\alpha > 0$. Then for $\varphi \in H_0^1(B_1) \cap L^\infty(B_1)$ with $\varphi \ge 0$ there holds

$$
\begin{align*} \int a_{ij} D_i v D_j \varphi &= \int a_{ij} e^{\alpha u} D_i u D_j \varphi \\ &= \int a_{ij} D_i u D_j (e^{\alpha u} \varphi) - \alpha \int a_{ij} e^{\alpha u} D_i u D_j u \varphi \\ &= \int b(x, u, Du) e^{\alpha u} \varphi - \alpha \int a_{ij} e^{\alpha u} D_i u D_j u \varphi \\ &\le C(M) \int (f(x) + |Du|^2) e^{\alpha u} \varphi - \alpha \lambda \int |Du|^2 e^{\alpha u} \varphi. \end{align*}
$$

Hence by taking $\alpha$ large we have

$$
(4.16) \qquad \int a_{ij} D_i v D_j \varphi \le C \int f(x) \varphi \\ \text{for any } \varphi \in H_0^1(B_1) \cap L^\infty(B_1) \text{ with } \varphi \ge 0
$$