PROOF: For $m > 0$, set $\bar{u} = u^+$ and

$$
\bar{u}_m = \begin{cases} \bar{u} & \text{if } u < m, \\ m & \text{if } u \ge m. \end{cases}
$$

Then set the test function

$$
\varphi = \eta^2 \bar{u}_m^\beta \bar{u} \in H_0^1(B_1)
$$

for some $\beta \ge 0$ and some nonnegative function $\eta \in C_0^1(B_1)$. By similar calculations as in the proof of Theorem 4.1 we conclude

$$
\left( \int \eta^{2\chi} \bar{u}_m^{\beta\chi} \bar{u}^{2\chi} \right)^{1/\chi} \le C(1+\beta) \left\{ \int |D\eta|^2 \bar{u}_m^{\beta} \bar{u}^2 + \int |c| \eta^2 \bar{u}_m^{\beta} \bar{u}^2 + \int |f| \eta^2 \bar{u}_m^{\beta} \bar{u} \right\}
$$

where $\chi = \frac{n}{n-2} > 1$. The Hölder inequality implies for any $K > 0$

$$
\begin{aligned} \int |c| \eta^2 \bar{u}_m^\beta \bar{u}^2 &\le K \int_{\{|c| \le K\}} \eta^2 \bar{u}_m^\beta \bar{u}^2 + \int_{\{|c| > K\}} |c| \eta^2 \bar{u}_m^\beta \bar{u}^2 \\ &\le K \int \eta^2 \bar{u}_m^\beta \bar{u}^2 + \left( \int_{\{|c| > K\}} |c|^{\frac{n}{2}} \right)^{\frac{2}{n}} \left( \int (\eta^2 \bar{u}_m^\beta \bar{u}^2)^{\frac{n}{n-2}} \right)^{\frac{n-2}{n}} \\ &\le K \int \eta^2 \bar{u}_m^\beta \bar{u}^2 + \varepsilon(K) \left( \int \eta^{2\chi} \bar{u}_m^{\beta\chi} \bar{u}^{2\chi} \right)^{\frac{1}{\chi}}. \end{aligned}
$$

Note $\varepsilon(K) \to 0$ as $K \to +\infty$ since $c \in L^{n/2}(B_1)$. Hence for bounded $\beta$ we obtain by choosing large $K = K(\beta)$

$$
\left( \int \eta^{2\chi} \bar{u}_m^{\beta\chi} \bar{u}^{2\chi} \right)^{1/\chi} \le C(1+\beta) \left\{ \int (|D\eta|^2 + \eta^2) \bar{u}_m^{\beta} \bar{u}^2 + \int |f| \eta^2 \bar{u}_m^{\beta} \bar{u} \right\}.
$$

Observe

$$
\bar{u}_m^\beta \bar{u} \le \bar{u}_m^{\beta - \frac{\beta}{\beta+2}} \bar{u}^{1+\frac{\beta}{\beta+2}} = (\bar{u}_m^\beta \bar{u}^2)^{\frac{\beta+1}{\beta+2}}.
$$

Therefore by the Hölder inequality again we have for $\eta \le 1$

$$
\begin{aligned} \int |f| \eta^2 \bar{u}_m^\beta \bar{u} &\le \left( \int |f|^q \right)^{\frac{1}{q}} \left( \int (\eta^2 \bar{u}_m^\beta \bar{u}^2)^\chi \right)^{\frac{\beta+1}{(\beta+2)\chi}} |\text{supp } \eta|^{1-\frac{1}{q}-\frac{\beta+1}{(\beta+2)\chi}} \\ &\le \varepsilon \left( \int \eta^{2\chi} \bar{u}^\chi \bar{u}_m^{\beta\chi} \right)^{\frac{1}{\chi}} + C(\varepsilon, \beta) \left( \int |f|^q \right)^{\frac{\beta+2}{q}}, \end{aligned}
$$

provided

$$
1 - \frac{1}{q} - \frac{\beta + 1}{(\beta + 2)\chi} \ge 0 \quad \text{which is equivalent to} \quad \beta + 2 \le \frac{q(n-2)}{n-2q}.
$$