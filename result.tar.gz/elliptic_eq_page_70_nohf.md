# Weak Solutions, Part II

## 4.1. Guide

This chapter covers the well-known theory of De Giorgi-Nash-Moser. We present the approaches of both De Giorgi and Moser so students can make comparisons and can see that the ideas involved are essentially the same. The classical paper [12] is certainly very nice material for further reading; one may also wish to compare the results in [7, 12].

## 4.2. Local Boundedness

In the following three sections we will discuss the De Giorgi-Nash-Moser theory for linear elliptic equations. In this section we will prove the local boundedness of solutions. In the next section we will prove Hölder continuity. Then in Section 4.4 we will discuss the Harnack inequality. For all results in these three sections there is no regularity assumption of coefficients.

The main theorem of this section is the following boundedness result.

THEOREM 4.1 Suppose $a_{ij} \in L^\infty(B_1)$ and $c \in L^q(B_1)$ for some $q > \frac{n}{2}$ satisfy the following assumptions:

$$
a_{ij}(x)\xi_i\xi_j \ge \lambda|\xi|^2 \quad \text{for any } x \in B_1, \xi \in \mathbb{R}^n,
$$

and

$$
|a_{ij}|_{L^\infty} + \|c\|_{L^q} \le \Lambda
$$

for some positive constants $\lambda$ and $\Lambda$. Suppose that $u \in H^1(B_1)$ is a subsolution in the following sense:

$$
(*) \quad \int_{B_1} a_{ij} D_i u D_j \varphi + cu\varphi \le \int_{B_1} f\varphi \quad \text{for any } \varphi \in H_0^1(B_1) \text{ and } \varphi \ge 0 \text{ in } B_1.
$$

If $f \in L^q(B_1)$, then $u^+ \in L_{\text{loc}}^\infty(B_1)$. Moreover, there holds for any $\theta \in (0, 1)$ and any $p > 0$

$$
\sup_{B_\theta} u^+ \le C \left\{ \frac{1}{(1-\theta)^{n/p}} \|u^+\|_{L^p(B_1)} + \|f\|_{L^q(B_1)} \right\}
$$

where $C = C(n, \lambda, \Lambda, p, q)$ is a positive constant.

In the following we use two approaches to prove this theorem, one by De Giorgi and the other by Moser.

PROOF: We first prove the theorem for $\theta = \frac{1}{2}$ and $p = 2$.