CASE 1. $c \equiv 0$.

We have for any $B_r(x_0) \subset B_1$ and for any $0 < \rho \le r$

$$
\int_{B_{\rho}(x_0)} |Du|^2 \le C \left\{ \left[ \left(\frac{\rho}{r}\right)^n + \tau^2(r) \right] \int_{B_r(x_0)} |Du|^2 + r^{n-2+2\alpha} \|f\|_{L^q(B_1)}^2 \right\}.
$$

Now the result would follow if in the above inequality we could write $\rho^{n-2+2\alpha}$ instead of $r^{n-2+2\alpha}$. This is in fact true and is stated in Lemma 3.4. By Lemma 3.4, there exists an $R_0 > 0$ such that for any $x_0 \in B_{1/2}$ and any $0 < \rho < r \le R_0$ we have

$$
\int_{B_{\rho}(x_0)} |Du|^2 \le C \left\{ \left(\frac{\rho}{r}\right)^{n-2+2\alpha} \int_{B_r(x_0)} |Du|^2 + \rho^{n-2+2\alpha} \|f\|_{L^q(B_1)}^2 \right\}.
$$

In particular, taking $r = R_0$ yields for any $\rho < R_0$

$$
\int_{B_{\rho}(x_0)} |Du|^2 \le C \rho^{n-2+2\alpha} \left\{ \int_{B_1} |Du|^2 + \|f\|_{L^q(B_1)}^2 \right\}.
$$

CASE 2. General case.

We have for any $B_r(x_0) \subset B_1$ and any $0 < \rho \le r$

$$
(3.8) \qquad \int_{B_{\rho}(x_0)} |Du|^2 \le C \left\{ \left[ \left(\frac{\rho}{r}\right)^n + \tau^2(r) \right] \int_{B_r(x_0)} |Du|^2 + r^{n-2+2\alpha} \chi(F) \right. \\ \qquad \left. + \int_{B_r(x_0)} u^2 \right\}
$$

where $\chi(F) = \|f\|_{L^q(B_1)}^2$. We will prove for any $x_0 \in B_{1/2}$ and any $0 < \rho < r \le \frac{1}{2}$

$$
(3.9) \qquad \int_{B_{\rho}(x_0)} |Du|^2 \le C \left\{ \left[ \left(\frac{\rho}{r}\right)^n + \tau^2(r) \right] \int_{B_r(x_0)} |Du|^2 \right. \\ \qquad \left. + r^{n-2+2\alpha} \left[ \chi(F) + \int_{B_1} u^2 + \int_{B_1} |Du|^2 \right] \right\}.
$$

We need a bootstrap argument. First by Lemma 3.3, there exists an $R_1 \in (\frac{1}{2}, 1)$ such that there holds for any $x_0 \in B_{R_1}$ and any $0 < r \le 1 - R_1$

$$
(3.10) \qquad \int_{B_r(x_0)} u^2 \le C r^{\delta_1} \left\{ \int_{B_1} |Du|^2 + \int_{B_1} u^2 \right\}
$$