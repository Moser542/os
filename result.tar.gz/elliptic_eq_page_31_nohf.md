Then for each outward direction $\mathbf{v}$ at $x_0$ with $\mathbf{v} \cdot \mathbf{n}(x_0) > 0$ there holds

$$
\liminf_{t \to 0^+} \frac{1}{t} [u(x_0) - u(x_0 - t\mathbf{v})] > 0.
$$

REMARK 2.6. If in addition $u \in C^1(B \cup \{x_0\})$, then we have

$$
\frac{\partial u}{\partial \mathbf{v}}(x_0) > 0.
$$

PROOF: We may assume that the center of $B$ is at the origin with radius $r$. We assume further that $u \in C(\bar{B})$ and $u(x) < u(x_0)$ for any $x \in \bar{B} \setminus \{x_0\}$ (since we can construct a tangent ball $B_1$ to $B$ at $x_0$ and $B_1 \subset B$).

Consider $v(x) = u(x) + \varepsilon h(x)$ for some nonnegative function $h$. We will choose $\varepsilon > 0$ appropriately such that $v$ attains its nonnegative maximum only at $x_0$. Denote $\Sigma = B \cap B_{1/2r}(x_0)$. Define $h(x) = e^{-\alpha|x|^2} - e^{-\alpha r^2}$ with $\alpha$ to be determined. We check in the following that

$$
Lh > 0 \quad \text{in } \Sigma.
$$

Direct calculation yields

$$
\begin{aligned} Lh &= e^{-\alpha|x|^2} \left\{ 4\alpha^2 \sum_{i,j=1}^{n} a_{ij}(x)x_i x_j - 2\alpha \sum_{i=1}^{n} a_{ii}(x) - 2\alpha \sum_{i=1}^{n} b_i(x)x_i + c \right\} - ce^{-\alpha r^2} \\ &\ge e^{-\alpha|x|^2} \left\{ 4\alpha^2 \sum_{i,j=1}^{n} a_{ij}(x)x_i x_j - 2\alpha \sum_{i=1}^{n} [a_{ii}(x) + b_i(x)x_i] + c \right\}. \end{aligned}
$$

By the ellipticity assumption, we have

$$
\sum_{i,j=1}^{n} a_{ij}(x)x_i x_j \ge \lambda |x|^2 \ge \lambda \left(\frac{r}{2}\right)^2 > 0 \quad \text{in } \Sigma.
$$

So for $\alpha$ large enough, we conclude $Lh > 0$ in $\Sigma$. With such $h$, we have $Lv = Lu + \varepsilon Lh > 0$ in $\Sigma$ for any $\varepsilon > 0$. By Lemma 2.1, $v$ cannot attain its nonnegative maximum inside $\Sigma$.

Next we prove that for some small $\varepsilon > 0$ $v$ attains at $x_0$ its nonnegative maximum. Consider $v$ on the boundary $\partial\Sigma$.

- For $x \in \partial\Sigma \cap B$, since $u(x) < u(x_0)$, we have $u(x) < u(x_0) - \delta$ for some $\delta > 0$. Take $\varepsilon$ small such that $\varepsilon h < \delta$ on $\partial\Sigma \cap B$. Hence for such $\varepsilon$ we have $v(x) < u(x_0)$ for $x \in \partial\Sigma \cap B$.

- On $\Sigma \cap \partial B$, $h(x) = 0$ and $u(x) < u(x_0)$ for $x \ne x_0$. Hence $v(x) < u(x_0)$ on $\Sigma \cap \partial B \setminus \{x_0\}$ and $v(x_0) = u(x_0)$.

Therefore we conclude

$$
\frac{v(x_0) - v(x_0 - t\mathbf{v})}{t} \ge 0 \quad \text{for any small } t > 0.
$$

Hence we obtain by letting $t \to 0$

$$
\liminf_{t \to 0} \frac{1}{t} [u(x_0) - u(x_0 - t\mathbf{v})] \ge -\varepsilon \frac{\partial h}{\partial \mathbf{v}}(x_0).
$$