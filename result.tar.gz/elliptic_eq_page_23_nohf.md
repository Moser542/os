Next we prove a quantitative Hopf lemma.

PROPOSITION 1.34 Suppose $u \in C(\bar{B}_1)$ is a harmonic function in $B_1 = B_1(0)$. If $u(x) < u(x_0)$ for any $x \in \bar{B}_1$ and some $x_0 \in \partial B_1$, then there holds

$$
\frac{\partial u}{\partial n}(x_0) \geq C(u(x_0) - u(0))
$$

where $C$ is a positive constant depending only on $n$.

PROOF: Consider a positive function $v$ in $B_1$ defined by

$$
v(x) = e^{-\alpha|x|^2} - e^{-\alpha}.
$$

It is easy to see

$$
\Delta v(x) = e^{-\alpha|x|^2}(-2\alpha n + 4\alpha^2|x|^2) > 0 \quad \text{for any } |x| \geq \frac{1}{2}
$$

if $\alpha \geq 2n + 1$. Hence for such fixed $\alpha$ the function $v$ is subharmonic in the region $A = B_1 \setminus B_{1/2}$. Now define for $\varepsilon > 0$

$$
h_{\varepsilon}(x) = u(x) - u(x_0) + \varepsilon v(x).
$$

This is also a subharmonic function, that is, $\Delta h_{\varepsilon} \geq 0$ in $A$. Obviously $h_{\varepsilon} \leq 0$ on $\partial B_1$ and $h_{\varepsilon}(x_0) = 0$. Since $u(x) < u(x_0)$ for $|x| = \frac{1}{2}$ we may take $\varepsilon > 0$ small such that $h_{\varepsilon}(x) < 0$ for $|x| = \frac{1}{2}$. Therefore by Theorem 1.29 $h_{\varepsilon}$ assumes at the point $x_0$ its maximum in $A$. This implies

$$
\frac{\partial h_{\varepsilon}}{\partial n}(x_0) \geq 0 \quad \text{or} \quad \frac{\partial u}{\partial n}(x_0) \geq -\varepsilon \frac{\partial v}{\partial n}(x_0) = 2\alpha\varepsilon e^{-\alpha} > 0.
$$

Note that so far we have only used the subharmonicity of $u$. We estimate $\varepsilon$ as follows. Set $w(x) = u(x_0) - u(x) > 0$ in $B_1$. Obviously $w$ is a harmonic function in $B_1$. By Corollary 1.33 (the Harnack inequality) there holds

$$
\inf_{B_{1/2}} w \geq c(n)w(0) \quad \text{or} \quad \max_{B_{1/2}} u \leq u(x_0) - c(n)(u(x_0) - u(0)).
$$

Hence we may take

$$
\varepsilon = \delta c(n)(u(x_0) - u(0))
$$

for $\delta$ small, depending on $n$. This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAAfCAIAAACQzIFuAAAAe0lEQVR4nO3WoQ3AIBCF4aOtYAkWYToEw7APKCwrIEleBYaUpoL2VO+3JF/IqacAEFsbHy36UxhKKe1fZK3t4FX/6tOlFAA3l/He40XOOSKqtRLf3Vtroosuuuiii/47/ZgfQggxxmW3DwutNdG0Z5bRMWNMzhmAYt3AJwSAyEPzy7u0AAAAAElFTkSuQmCC)

To finish this section we prove a global Hölder continuity result.

LEMMA 1.35 Suppose $u \in C(\bar{B}_1)$ is a harmonic function in $B_1$ with $u = \varphi$ on $\partial B_1$. If $\varphi \in C^\alpha(\partial B_1)$ for some $\alpha \in (0, 1)$, then $u \in C^{\alpha/2}(\bar{B}_1)$. Moreover, there holds

$$
\|u\|_{C^{\alpha/2}(\bar{B}_1)} \leq C \|\varphi\|_{C^\alpha(\partial B_1)}
$$

where $C$ is a positive constant depending only on $n$ and $\alpha$.

PROOF: First the maximum principle implies that $\inf_{\partial B_1} \varphi \leq u \leq \sup_{\partial B_1} \varphi$ in $B_1$. Next we claim that for any $x_0 \in \partial B_1$ there holds

$$
(1.7) \qquad \sup_{x \in B_1} \frac{|u(x) - u(x_0)|}{|x - x_0|^{\alpha/2}} \leq 2^{\alpha/2} \sup_{x \in \partial B_1} \frac{|\varphi(x) - \varphi(x_0)|}{|x - x_0|^{\alpha}}.
$$