Next, for any $w \in R(A)^\perp$, we have

$$
c_0 \|w\|_{H_0^1(\Omega)}^2 \le a(w, w) = (Aw, w)_{H_0^1(\Omega)} = 0
$$

and hence $w = 0$. Then $R(A)^\perp = \{0\}$ and hence $R(A) = H_0^1(\Omega)$; in other words, $A$ is onto.

For the bounded linear functional $F$ in $H_0^1(\Omega)$ introduced at the beginning of the proof, by the Riesz representation theorem, there exists a $w \in H_0^1(\Omega)$ such that

$$
(w, v)_{H_0^1(\Omega)} = F(v)
$$

for any $v \in H_0^1(\Omega)$. Since $A$ is onto, we can find a $u \in H_0^1(\Omega)$ such that $Au = w$; hence,

$$
a(u, v) = (Au, v)_{H_0^1(\Omega)} = (w, v)_{H_0^1(\Omega)} = F(v)
$$

for any $v \in H_0^1(\Omega)$. This proves the existence.

For the uniqueness, we assume $\tilde{u} \in H_0^1(\Omega)$ also satisfies

$$
a(\tilde{u}, v) = F(v)
$$

for any $v \in H_0^1(\Omega)$. Then

$$
a(u - \tilde{u}, v) = 0
$$

for any $v \in H_0^1(\Omega)$. With $v = u - \tilde{u}$, we obtain

$$
a(u - \tilde{u}, u - \tilde{u}) = 0.
$$

By the coerciveness, we have $u = \tilde{u}$. $\square$

We point out that the method in the proof of the general case, when formulated in an abstract form, is known as the Lax-Milgram theorem.

The Dirichlet problem can be solved for a larger class of elliptic equations of divergence form. However, the method is much more involved. In the following, we state a simple consequence of Theorem 6.8.

**THEOREM 6.9** Let $a_{ij}$, $b_i$, and $c$ be bounded functions in $\Omega$ and $f \in L^2(\Omega)$. Then there exists a $\mu_0$ depending only on $a_{ij}$, $b_i$, and $c$ such that for any $\mu \ge \mu_0$ there exists a unique weak solution $u \in H_0^1(\Omega)$ of $(L + \mu)u = f$.

**PROOF:** Define

$$
a_{\mu}(u, v) = a(u, v) + (u, v)_{L^2(\Omega)}.
$$

In other words, $a_\mu$ is the bilinear form associated with the operator $L + \mu$. It is easy to check that $a_\mu$ is coercive for $\mu$ sufficiently large. Then we may apply Theorem 6.8 to $L + \mu$. $\square$

In the rest of this section, we use a minimizing process to solve the Dirichlet problem on the bounded domain with the homogeneous boundary value.

Let $\Omega$ be a bounded domain $a_{ij}$, and $c$ be bounded functions in $\Omega$ satisfying

$$
\lambda |\xi|^2 \le a_{ij}(x) \xi_i \xi_j \le \Lambda |\xi|^2
$$