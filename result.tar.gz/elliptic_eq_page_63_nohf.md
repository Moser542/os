where $\delta_1 = 2$ if $n > 2$ and $\delta_1$ is arbitrary in $(0,2)$ if $n = 2$. This, with (3.8), yields

$$
\int_{B_{\rho}(x_0)} |Du|^2 \le C \left\{ \left[ \left(\frac{\rho}{r}\right)^n + \tau^2(r) \right] \int_{B_r(x_0)} |Du|^2 + r^{n-2+2\alpha} \chi(F) + r^{\delta_1} \|u\|_{H^1(B_1)}^2 \right\}.
$$

Then (3.9) holds in the following cases:

(i) $n = 2$, by choosing $\delta_1 = 2\alpha$;

(ii) $n > 2$ while $n - 2 + 2\alpha \le 2$, by choosing $\delta_1 = 2$.

For $n > 2$ and $n - 2 + 2\alpha > 2$, we have

$$
\int_{B_{\rho}(x_0)} |Du|^2 \le c \left\{ \left[ \left(\frac{\rho}{r}\right)^n + \tau^2(r) \right] \int_{B_r(x_0)} |Du|^2 + r^2[\chi(F) + \|u\|_{H^1(B_1)}^2] \right\}.
$$

Lemma 3.4 again yields for any $x_0 \in B_{R_1}$ and any $0 < r \le 1 - R_1$

$$
\int_{B_r(x_0)} |Du|^2 \le C r^2 \{\chi(F) + \|u\|_{H^1(B_1)}^2\}.
$$

Hence by Lemma 3.3, there exists an $R_2 \in (\frac{1}{2}, R_1)$ such that there holds for any $x_0 \in B_{R_2}$ and any $0 < r \le R_1 - R_2$

$$
(3.11) \qquad \int_{B_r(x_0)} u^2 \le C r^{\delta_2} \{\chi(F) + \|u\|_{H^1(B_1)}^2\}
$$

where $\delta_2 = 4$ if $n > 4$ and $\delta_2$ is arbitrary in $(2, n)$ if $n = 3$ or $4$. Notice (3.11) is an improvement compared with (3.10). Substitute (3.11) in (3.8) and continue the process. After finite steps, we get (3.9). This finishes the proof. $\square$

### 3.4. Hölder Continuity of Gradients

In this section we will prove Hölder regularity for gradients of solutions. We follow the same idea used to prove Theorem 3.8.

Suppose $a_{ij} \in L^\infty(B_1)$ is uniformly elliptic in $B_1 = B_1(0)$, that is,

$$
\lambda |\xi|^2 \le a_{ij}(x) \xi_i \xi_j \le \Lambda |\xi|^2 \quad \text{for any } x \in B_1, \xi \in \mathbb{R}^n.
$$

We assume that $u \in H^1(B_1)$ satisfies

$$
(*) \qquad \int_{B_1} a_{ij} D_i u D_j \varphi + c u \varphi = \int_{B_1} f \varphi \quad \text{for any } \varphi \in H_0^1(B_1).
$$

The main theorems we will prove are the following Hölder estimates for gradients.