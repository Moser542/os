the discussion of quasi-linear equations, where the coefficients depend on the solutions. In fact, the linearity has no bearing in their arguments. This permits an extension of these results to quasi-linear equations with appropriate structure conditions. One may discuss boundary regularities in a similar way. We leave the details to the reader.

The outline of this chapter is as follows: The first section provides some general knowledge of Campanato and BMO spaces that are needed in both Chapters 3 and 4. Sections 3.3 and 3.4 as well as Sections 5.4 and 5.5 can be viewed as perturbation theory (from the constant-coefficient equations). The former deals with equations of divergence type, and the latter is for nondivergence type equations. The classical theory of Schauder estimates and $L^p$-estimates are also contained in the latter treatment. Note we did not use the classical potential estimates. Here two papers by Caffarelli [2, 3] and the book of Giaquinta [5] are sources for further reading.

## 3.2. Growth of Local Integrals

Let $B_R(x_0)$ be the ball in $\mathbb{R}^n$ of radius $R$ centered at $x_0$. The well-known Sobolev theorem states that if $u \in W^{1,p}(B_R(x_0))$ with $p > n$ then $u$ is Hölder-continuous with exponent $\alpha = 1 - n/p$.

In the first part of this section we prove a general result, due to S. Campanato, which characterizes Hölder-continuous functions by the growth of their local integrals. This result will be very useful for studying the regularity of solutions to elliptic differential equations. In the second part of this section we prove a result, due to John and Nirenberg, which gives an equivalent definition of functions of bounded mean oscillation.

Let $\Omega$ be a bounded connected open set in $\mathbb{R}^n$ and let $u \in L^1(\Omega)$. For any ball $B_r(x_0) \subset \Omega$, define

$$
u_{x_0,r} = \frac{1}{|B_r(x_0)|} \int_{B_r(x_0)} u.
$$

THEOREM 3.1 Suppose $u \in L^2(\Omega)$ satisfies

$$
\int_{B_r(x)} |u - u_{x,r}|^2 \le M^2 r^{n+2\alpha} \quad \text{for any } B_r(x) \subset \Omega
$$

for some $\alpha \in (0, 1)$. Then $u \in C^\alpha(\Omega)$ and for any $\Omega' \Subset \Omega$ there holds

$$
\sup_{\Omega'} |u| + \sup_{\substack{x,y \in \Omega' \\ x \neq y}} \frac{|u(x) - u(y)|}{|x - y|^\alpha} \le c\{M + \|u\|_{L^2(\Omega)}\}
$$

where $c = c(n, \alpha, \Omega, \Omega') > 0$.

PROOF: Denote $R_0 = \text{dist}(\Omega', \partial\Omega)$. For any $x_0 \in \Omega'$ and $0 < r_1 < r_2 \le R_0$, we have

$$
|u_{x_0,r_1} - u_{x_0,r_2}|^2 \le 2(|u(x) - u_{x_0,r_1}|^2 + |u(x) - u_{x_0,r_2}|^2)
$$