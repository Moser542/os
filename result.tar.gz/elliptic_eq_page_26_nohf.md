Therefore we obtain

$$
\int_{B_{R/2}} u^2 \le C \int_{B_R \setminus B_{R/2}} u^2, \quad \text{which implies} \quad (C + 1) \int_{B_{R/2}} u^2 \le C \int_{B_R} u^2.
$$

For the second inequality, observe that Lemma 1.36 holds for $u-a$ for arbitrary constant $a$. Then as before we have

$$
\int_{B_R} \eta^2 |Du|^2 \le C \int_{B_R} |D\eta|^2 (u-a)^2 \le \frac{C}{R^2} \int_{B_R \setminus B_{R/2}} (u-a)^2.
$$

The Poincaré inequality implies with $a = |B_R \setminus B_{R/2}|^{-1} \int_{B_R \setminus B_{R/2}} u$

$$
\int_{B_R \setminus B_{R/2}} (u-a)^2 \le c(n)R^2 \int_{B_R \setminus B_{R/2}} |Du|^2.
$$

Hence we obtain

$$
\int_{B_{R/2}} |Du|^2 \le C \int_{B_R \setminus B_{R/2}} |Du|^2;
$$

in particular,

$$
(C + 1) \int_{B_{R/2}} |Du|^2 \le C \int_{B_R} |Du|^2.
$$

□

REMARK 1.39. Corollary 1.38 implies, in particular, that a harmonic function in $\mathbb{R}^n$ with finite $L^2$-norm is identically 0 and that a harmonic function in $\mathbb{R}^n$ with finite Dirichlet integral is constant.

REMARK 1.40. By iterating the result in Corollary 1.38, we have the following estimates. Let $u$ be in Lemma 1.36. Then for any $0 < \rho < r \le 1$ there hold

$$
\int_{B_{\rho}} u^2 \le C \left(\frac{\rho}{r}\right)^{\mu} \int_{B_r} u^2 \quad \text{and} \quad \int_{B_{\rho}} |Du|^2 \le C \left(\frac{\rho}{r}\right)^{\mu} \int_{B_r} |Du|^2
$$

for some positive constant $\mu = \mu(n, \lambda, \Lambda)$. Later on we will prove that we can take $\mu \in (n-2, n)$ in the second inequality. For harmonic functions we have better results.

LEMMA 1.41 Suppose $\{a_{ij}\}$ is a constant positive definite matrix with

$$
\lambda |\xi|^2 \le a_{ij} \xi_i \xi_j \le \Lambda |\xi|^2 \quad \text{for any } \xi \in \mathbb{R}^n
$$

for some constants $0 < \lambda \le \Lambda$. Suppose $u \in C^1(B_1)$ satisfies

$$
(1.8) \qquad \int_{B_1} a_{ij} D_i u D_j \varphi = 0 \quad \text{for any } \varphi \in C_0^1(B_1).
$$