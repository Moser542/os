We shall briefly mention how assumptions in Theorem 6.23 can be verified for the minimal surface equation. For simplicity, we consider the case where $\Omega$ is a uniformly convex, $C^{2,\alpha}$-bounded domain in $\mathbb{R}^n$ and the following Dirichlet problem:

$$
(6.29) \qquad \begin{cases} \operatorname{div} \left( \frac{\nabla u}{\sqrt{1+|\nabla u|^2}} \right) = 0 & \text{in } \Omega, \\ u|_{\partial \Omega} = \phi & \text{on } \partial \Omega. \end{cases}
$$

We assume that $\phi \in C^{2,\alpha}(\partial\Omega)$.

Suppose $u$ is a $C^{2,\alpha}$-solution of (6.28); then the maximum principle implies that

$$
(6.30) \qquad \|u\|_{L^{\infty}(\bar{\Omega})} \le \|\phi\|_{L^{\infty}(\partial\Omega)} \equiv C_0 < \infty.
$$

Next, by the uniform convexity of $\partial\Omega$ and the $C^{2,\alpha}$-regularity of $\phi$, we can check that, for every $x_0 \in \partial\Omega$, there exist linear functions $\ell_{x_0}^{\pm}(x)$ such that

$$
\ell_{x_0}^{\pm}(x_0) = \phi(x_0) \quad \text{and} \quad \ell_{x_0}^{-}(x) \le \phi(x) \le \ell_{x_0}^{+}(x)
$$

for all $x \in \partial\Omega$. Since linear functions are solutions of $\operatorname{div}(\nabla u / \sqrt{1 + |\nabla u|^2}) = 0$ in $\Omega$, from the maximum principle we conclude that

$$
(6.31) \qquad \ell_{x_0}^{-}(x) \le u(x) \le \ell_{x_0}^{+}(x), \quad x \in \bar{\Omega};
$$

in particular, $|\nabla u(x_0)| \le \max |\nabla \ell_{x_0}^{\pm}(x_0)| \equiv C_1 < \infty$.

On the other hand, if $u$ is a $C^{2,\alpha}$-solution of (6.28), then $u_\alpha = \frac{\partial}{\partial x_\alpha} u$, $\alpha = 1, 2, \dots, n$, satisfies

$$
(6.32) \qquad \frac{\partial}{\partial x_i} (F_{P_i} P_j (Du) u_{a_j}) = 0.
$$

Here $F(Du) = \sqrt{1 + |\nabla u|^2}$, hence $(F_{P_i} P_j (Du)) > 0$. Thus $u_\alpha$ satisfies the maximum principle. Therefore we have

$$
(6.33) \qquad \|\nabla u\|_{L^{\infty}(\Omega)} \le \|\nabla u\|_{L^{\infty}(\partial\Omega)} \le C_1 < \infty.
$$

From (6.29), (6.32), and (6.33), we further deduce that

$$
(6.34) \qquad \|\nabla u\|_{C^\beta(\bar{\Omega})} \le C(C_0, C_1, C_2) < \infty
$$

where $C_2 = \|\phi\|_{C^{2,\alpha}(\partial\Omega)}$. This follows from De Giorgi–Moser theory.

We rewrite $\operatorname{div}(\nabla u / \sqrt{1 + |\nabla u|^2}) = 0$ as

$$
(6.35) \qquad \Delta u - \frac{u_i u_j}{1 + |\nabla u|^2} u_{ij} = 0
$$

and combine (6.35) with (6.34) and the Schauder estimates to obtain

$$
(6.36) \qquad \|u\|_{C^{2,\beta}(\bar{\Omega})} \le C(C_0, C_1, C_2, \Omega)
$$

where we may assume that $0 < \beta \le \alpha$.