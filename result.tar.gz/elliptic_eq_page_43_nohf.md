where $\Gamma^+$ is the upper contact set of $u$ and $\tilde{M} = (\sup_{\Omega} u - \sup_{\partial\Omega} u^+)/d$ with $d = \text{diam}(\Omega)$.

REMARK 2.25. For any positive definite matrix $A = (a_{ij})$ we have

$$
\det(-D^2u) \le \frac{1}{D} \left( \frac{-a_{ij} D_{ij} u}{n} \right)^n \quad \text{on } \Gamma^+.
$$

Hence we have another form for Lemma 4.2

$$
\int_{B_{\tilde{M}}(0)} g \le \int_{\Gamma^+} g(Du) \left( \frac{-a_{ij} D_{ij} u}{n D^*} \right)^n.
$$

REMARK 2.26. A special case corresponds to $g = 1$:

$$
\begin{aligned} \sup_{\Omega} \sup u &\le \sup_{\partial \Omega} u^+ + \frac{d}{\omega_n^{1/n}} \left( \int_{\Gamma^+} |\det D^2 u| \right)^{1/n} \\ &\le \sup_{\partial \Omega} u^+ + \frac{d}{\omega_n^{1/n}} \left( \int_{\Gamma^+} \left( -\frac{a_{ij} D_{ij} u}{n D^*} \right)^n \right)^{1/n}. \end{aligned}
$$

Note that this is Theorem 2.21 if $b_i \equiv 0$ and $c \equiv 0$.

PROOF OF LEMMA 2.24: Without loss of generality we assume $u \le 0$ on $\partial\Omega$. Set $\Omega^+ = \{u > 0\}$. By the area formula for $Du$ in $\Gamma^+ \cap \Omega^+ \subset \Omega$, we have

$$
(2.3) \qquad \int_{Du(\Gamma^+ \cap \Omega^+)} g \le \int_{\Gamma^+ \cap \Omega^+} g(Du) |\det(D^2u)|,
$$

where $|\det(D^2u)|$ is the Jacobian of the map $Du : \Omega \to \mathbb{R}^n$. In fact, we may consider $\chi_\varepsilon = Du - \varepsilon \text{Id} : \Omega \to \mathbb{R}^n$. Then $D\chi_\varepsilon = D^2u - \varepsilon I$, which is negative definite in $\Gamma^+$. Hence by the change-of-variable formula we have

$$
\int_{\chi_\varepsilon(\Gamma^+ \cap \Omega^+)} g = \int_{\Gamma^+ \cap \Omega^+} g(\chi_\varepsilon) |\det(D^2u - \varepsilon I)|,
$$

which implies (2.3) if we let $\varepsilon \to 0$.

Now we claim $B_{\tilde{M}}(0) \subset Du(\Gamma^+ \cap \Omega^+)$, that is, for any $a \in \mathbb{R}^n$ with $|a| < \tilde{M}$ there exists $x \in \Gamma^+ \cap \Omega^+$ such that $a = Du(x)$.

We may assume $u$ attains its maximum $m > 0$ at $0 \in \Omega$, that is,

$$
u(0) = m = \sup_{\Omega} u.
$$

Consider an affine function for $|a| < \frac{m}{d} (\equiv \tilde{M})$

$$
L(x) = m + a \cdot x.
$$

Then $L(x) > 0$ for any $x \in \Omega$ and $L(0) = m$. Since $u$ assumes its maximum at $0$, then $Du(0) = 0$. Hence there exists an $x_1$ close to $0$ such that $u(x_1) > L(x_1) > 0$. Note that $u \le 0 < L$ on $\partial\Omega$. Hence there exists an $\tilde{x} \in \Omega$ such that $Du(\tilde{x}) = DL(\tilde{x}) = a$. Now we may translate vertically the plane $y = L(x)$ to the highest