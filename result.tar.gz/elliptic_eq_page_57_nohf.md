We will prove that there exist two positive constants $c_1(n)$ and $c_2(n)$ such that for any $Q \subset Q_0$ there holds

$$
|\{x \in Q : |u - u_Q| > t\}| \le c_1|Q| \exp\left(-\frac{c_2}{M}t\right).
$$

Then Theorem 3.5 follows easily.

Assume without loss of generality $M = 1$. Choose

$$
\alpha > 1 \ge |Q_0|^{-1} \int_{Q_0} |u - u_{Q_0}| dx.
$$

Apply the Calderon-Zygmund decomposition to $f = |u - u_{Q_0}|$. There exists a sequence of (nonoverlapping) cubes $\{Q_j^{(1)}\}_{j=1}^{\infty}$ such that

$$
\alpha \le \frac{1}{|Q_j^{(1)}|} \int_{Q_j^{(1)}} |u - u_{Q_0}| < 2^n \alpha,
$$

$$
|u(x) - u_{Q_0}| \le \alpha \quad \text{a.e. } x \in Q_0 \setminus \bigcup_{j=1}^{\infty} Q_j^{(1)}.
$$

This implies

$$
\sum_j |Q_j^{(1)}| \le \frac{1}{\alpha} \int_{Q_0} |u - u_{Q_0}| \le \frac{1}{\alpha} |Q_0|,
$$

$$
|u_{Q_j^{(1)}} - u_{Q_0}| \le \frac{1}{|Q_j^{(1)}|} \int_{Q_j^{(1)}} |u - u_{Q_0}| dx \le 2^n \alpha.
$$

The definition of the BMO norm implies that for each $j$

$$
\frac{1}{|Q_j^{(1)}|} \int_{Q_j^{(1)}} |u - u_{Q_j^{(1)}}| dx \le 1 < \alpha.
$$

Apply the decomposition procedure above to $f = |u - u_{Q_j^{(1)}}|$ in $Q_j^{(1)}$. There exists a sequence of (nonoverlapping) cubes $\{Q_j^{(2)}\}$ in $\bigcup_j Q_j^{(1)}$ such that

$$
\sum_{j=1}^{\infty} |Q_j^{(2)}| \le \frac{1}{\alpha} \sum_j \int_{Q_j^{(1)}} |u - u_{Q_j^{(1)}}| \le \frac{1}{\alpha} \sum_j |Q_j^{(1)}| \le \frac{1}{\alpha^2} |Q_0|
$$

and

$$
|u(x) - u_{Q_j^{(1)}}| \le \alpha \quad \text{a.e. } x \in Q_j^{(1)} \setminus \bigcup Q_j^{(2)},
$$

which implies

$$
|u(x) - u_{Q_0}| \le 2 \cdot 2^n \alpha \quad \text{a.e. } x \in Q_0 \setminus \bigcup_j Q_j^{(2)}.
$$