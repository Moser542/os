where $C$ is a positive constant depending only on $\lambda$, $\Lambda$, $\alpha_0$, and $\text{diam}(\Omega)$.

PROOF: We prove for a special case and the general case.

CASE 1. Special case: $c(x) \le -c_0 < 0$.

We will show

$$
|u(x)| \le \frac{1}{c_0} F + \frac{1}{\alpha_0} \Phi \quad \text{for any } x \in \Omega.
$$

Define $v = \frac{1}{c_0}F + \frac{1}{\alpha_0}\Phi \pm u$. Then we have

$$
Lv = c(x)\left(\frac{1}{c_0}F + \frac{1}{\alpha_0}\Phi\right) \pm f \le -F \pm f \le 0 \quad \text{in } \Omega,
$$

$$
\frac{\partial v}{\partial n} + \alpha v = \alpha \left( \frac{1}{c_0} F + \frac{1}{\alpha_0} \Phi \right) \pm \varphi \ge \Phi \pm \varphi \ge \quad \text{on } \partial \Omega.
$$

If $v$ has a negative minimum in $\bar{\Omega}$, then $v$ attains it on $\partial\Omega$ by Theorem 2.5, say, at $x_0 \in \partial\Omega$. This implies $\frac{\partial v}{\partial n}(x_0) \le 0$ for $\mathbf{n} = \mathbf{n}(x_0)$, the outward normal direction at $x_0$. Therefore we get

$$
\left( \frac{\partial v}{\partial n} + \alpha v \right)(x_0) \le \alpha v(x_0) < 0,
$$

which is a contradiction. Hence we have $v \ge 0$ in $\bar{\Omega}$, in particular,

$$
|u(x)| \le \frac{1}{c_0} F + \frac{1}{\alpha_0} \Phi \quad \text{for any } x \in \Omega.
$$

Note that for this special case $c_0$ and $\alpha_0$ are independent of $\lambda$ and $\Lambda$.

CASE 2. General case: $c(x) \le 0$ for any $x \in \Omega$.

Consider the auxiliary function $u(x) = z(x)w(x)$ where $z$ is a positive function in $\bar{\Omega}$ to be determined. Direct calculation shows that $w$ satisfies

$$
a_{ij} D_{ij} w + B_i D_i w + \left( c + \frac{a_{ij} D_{ij} z + b_i D_i z}{z} \right) w = \frac{f}{z} \quad \text{in } \Omega,
$$
$$
\frac{\partial w}{\partial n} + \left( \alpha + \frac{1}{z} \frac{\partial z}{\partial n} \right) w = \frac{\varphi}{z} \quad \text{on } \partial \Omega,
$$

where $B_i = \frac{1}{z}(a_{ij} + a_{ji})D_j z + b_i$. We need to choose the function $z > 0$ in $\bar{\Omega}$ such that there hold in

$$
c + \frac{a_{ij} D_{ij} z + b_i D_i z}{z} \le -c_0(\lambda, \Lambda, d, \alpha_0) < 0 \quad \text{in } \Omega,
$$
$$
\alpha + \frac{1}{z} \frac{\partial z}{\partial n} \ge \frac{1}{2} \alpha_0 \quad \text{on } \partial \Omega,
$$

or

$$
\frac{a_{ij} D_{ij} z + b_i D_i z}{z} \le -c_0 < 0 \quad \text{in } \Omega,
$$
$$
\left| \frac{1}{z} \frac{\partial z}{\partial n} \right| \le \frac{1}{2} \alpha_0 \quad \text{on } \partial \Omega.
$$