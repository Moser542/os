Then $\tilde{u} \ge 0$ in $B_{2\sqrt{n}}$ and $\inf_{Q_3} \tilde{u} \le 1$. It is easy to check that $\tilde{u} \in S^+(\lambda, \Lambda, \tilde{f})$ in $B_{2\sqrt{n}}$ with $\|\tilde{f}\|_{L^n(B_{2\sqrt{n}})} \le \varepsilon_0$. In fact, we have

$$
\tilde{f}(y) = \frac{r^2}{M^{k-1}} f(x) \quad \text{for } y \in B_{2\sqrt{n}}
$$

and hence

$$
\|\tilde{f}\|_{L^n(B_{2\sqrt{n}})} \le \frac{r}{M^{k-1}} \|f\|_{L^n(B_{2\sqrt{n}})} \le \|f\|_{L^n(B_{2\sqrt{n}})} \le \varepsilon_0.
$$

Hence $\tilde{u}$ satisfies assumption (5.6). We may apply Lemma 5.13 to $\tilde{u}$ to get

$$
\mu < |\{\tilde{u}(y) \le M\} \cap Q_1| = r^{-n} |\{u(x) \le M^k\} \cap Q|.
$$

Hence $|Q \cap A^c| > \mu|Q|$, which contradicts (5.9). We are in a position to apply Lemma 5.9 to get (5.8). $\square$

PROOF OF LEMMA 5.12: We prove that there exist two constants $\theta > 1$ and $M_0 \gg 1$, depending only on $n$, $\lambda$, and $\Lambda$, such that if $u(x_0) = P > M_0$ for some $x_0 \in B_{1/4}$ there exists a sequence $\{x_k\} \in B_{1/2}$ such that

$$
u(x_k) \ge \theta^k P \quad \text{for } k = 0, 1, \dots
$$

This contradicts the boundedness of $u$, hence we conclude that $\sup_{B_{1/4}} u \le M_0$.

Suppose $u(x_0) = P > M_0$ for some $x_0 \in B_{1/4}$. We will determine $M_0$ and $\theta$ in the process. Consider a cube $Q_r(x_0)$, centered at $x_0$ with side length $r$, which will be chosen later. We want to find a point $x_1 \in Q_{4\sqrt{nr}}(x_0)$ such that $u(x_1) \ge \theta P$. To do that we first choose $r$ such that $\{u > \frac{P}{2}\}$ covers less than half of $Q_r(x_0)$. This can be done by using the power decay of the distribution function of $u$.

Note $\inf_{Q_3} u \le \inf_{Q_{1/4}} u \le 1$. Hence Lemma 5.14 implies

$$
\left| \left\{ u > \frac{P}{2} \right\} \cap Q_1 \right| \le C \left( \frac{P}{2} \right)^{-\varepsilon}.
$$

We choose $r$ such that $\frac{r^n}{2} \ge C(\frac{P}{2})^{-\varepsilon}$ and $r \le \frac{1}{4}$. Hence we have, for such $r$, $Q_r(x_0) \subset Q_1$ and

$$
(5.10) \qquad \frac{1}{|Q_r(x_0)|} \left| \left\{ u > \frac{P}{2} \right\} \cap Q_r(x_0) \right| \le \frac{1}{2}.
$$

Next we show that for $\theta > 1$, with $\theta - 1$ small, $u \ge \theta P$ at some point in $Q_{4\sqrt{nr}}(x_0)$. We prove it by contradiction. Suppose $u \le \theta P$ in $Q_{4\sqrt{nr}}(x_0)$. Consider the transformation

$$
x = x_0 + ry \quad \text{for } y \in Q_{4\sqrt{n}} \text{ and } x \in Q_{4\sqrt{nr}}(x_0)
$$

and the function

$$
\tilde{u}(y) = \frac{\theta P - u(x)}{(\theta - 1)P}.
$$