Set $R(x, y) = -\gamma(x - y)$, and for $f \in C(\partial\Omega)$, we define the *double-layer potential*

$$
(6.15) \qquad \mathcal{D}f(p) = \int_{\partial\Omega} \frac{\partial}{\partial n_Q} R(P, Q) f(Q) d\mathcal{H}^{n-1}(Q), \quad P \notin \partial\Omega,
$$

and the *single-layer potential*

$$
(6.16) \qquad S(f)(P) = \int_{\partial\Omega} R(P, Q) f(Q) d\mathcal{H}^{n-1}(Q), \quad P \notin \partial\Omega.
$$

Here $n_Q$ is the outward unit normal for $\partial\Omega$ at $Q$.

It is easy to check that

$$
\Delta \mathcal{D}f(P) = 0 \quad \text{for } P \in \mathbb{R}^n \mid \partial\Omega.
$$

We need to understand the boundary behavior of $\mathcal{D}f(P)$ on $\partial\Omega$.

LEMMA 6.16 If $f \in C(\partial\Omega)$, then

(i) $\mathcal{D}f \in C(\overline{\Omega})$ and

(ii) $\mathcal{D}f \in C(\overline{\Omega^c})$.

In other words, $\mathcal{D}f$ can be extended continuously from inside $\Omega$ to $\overline{\Omega}$, and from outside $\Omega$ to $\overline{\Omega^c}$. Let $\mathcal{D}_+f$ and $\mathcal{D}_-f$ be the restrictions of these two functions to $\partial\Omega$. Set

$$
K(P, Q) = \frac{\partial}{\partial n_Q} R(P, Q) = \frac{1}{\omega_n} \frac{\langle P - Q, n_Q \rangle}{|P - Q|^n}.
$$

Thus

$$
K \in C(\partial\Omega \times \partial\Omega \setminus \{(P, P) : P \in \partial\Omega\})
$$

and $|K(P, Q)| \le C/|P - Q|^{n-2}$ for $P, Q \in \partial\Omega$ and some $C < \infty$. The latter estimate follows from the $C^2$ property of $\partial\Omega$. We shall define, for $f \in C(\partial\Omega)$, the operator

$$
(6.17) \qquad Tf(P) = \int_{\partial\Omega} K(P, Q) f(Q) d\mathcal{H}^{n-1}(Q), \quad P \in \partial\Omega.
$$

We have the following:

LEMMA 6.17 (Jump Relations for $\mathcal{D}$)

(i) $\mathcal{D}_+ = \frac{1}{2}I + T$ and

(ii) $\mathcal{D}_- = -\frac{1}{2}I + T$.

Moreover, $T : C(\partial\Omega) \to C(\partial\Omega)$ is compact.

PROOF OF LEMMAS 6.16 AND 6.17: We first verify that $T$ defined by (6.17) is a compact operator from $C(\partial\Omega) \to C(\partial\Omega)$. Let

$$
K_N(P, Q) = \operatorname{sign} K(P, Q) \cdot \min\{N, |K(P, Q)|\}, \quad N \in \mathbb{Z}_+.
$$

Thus $K_N$ is continuous on $\partial\Omega \times \partial\Omega$, and the Arzela-Ascoli theorem implies that $T_N f = \int_{\partial\Omega} K_N(P, Q) f(Q) d\mathcal{H}^{n-1}(Q)$ is compact on $C(\partial\Omega)$. Furthermore,