Therefore we have

$$
\int |Dw|^2 \eta^2 \le C \left\{ (1 + \beta) \int w^2 |D\eta|^2 + (1 + \beta) \int c_0 w^2 \eta^2 \right\}
$$

or

$$
\int |D(w\eta)|^2 \le C \left\{ (1 + \beta) \int w^2 |D\eta|^2 + (1 + \beta) \int c_0 w^2 \eta^2 \right\}.
$$

The Hölder inequality implies

$$
\int c_0 w^2 \eta^2 \le \left( \int c_0^q \right)^{\frac{1}{q}} \left( \int (\eta w)^{\frac{2q}{q-1}} \right)^{1-\frac{1}{q}} \le (\Lambda + 1) \left( \int (\eta w)^{\frac{2q}{q-1}} \right)^{1-\frac{1}{q}}.
$$

By interpolation inequality and the Sobolev inequality with $2^* = \frac{2n}{n-2} > \frac{2q}{q-1} > 2$ if $q > \frac{n}{2}$, we have

$$
\begin{aligned} \|\eta w\|_{L^{\frac{2q}{q-1}}} &\le \varepsilon \|\eta w\|_{L^{2^*}} + C(n, q) \varepsilon^{-\frac{n}{2q-n}} \|\eta w\|_{L^2} \\ &\le \varepsilon \|D(\eta w)\|_{L^2} + C(n, q) \varepsilon^{-\frac{n}{2q-n}} \|\eta w\|_{L^2} \end{aligned}
$$

for any small $\varepsilon > 0$. Therefore we obtain

$$
\int |D(w\eta)|^2 \le C \left\{ (1 + \beta) \int w^2 |D\eta|^2 + (1 + \beta)^{\frac{2q}{2q-n}} \int w^2 \eta^2 \right\}
$$

and in particular

$$
\int |D(w\eta)|^2 \le C(1 + \beta)^\alpha \int (|D\eta|^2 + \eta^2) w^2,
$$

where $\alpha$ is a positive number depending only on $n$ and $q$. The Sobolev inequality then implies

$$
\left( \int |\eta w|^{2\chi} \right)^{1/\chi} \le C(1 + \beta)^\alpha \int (|D\eta|^2 + \eta^2) w^2
$$

where $\chi = \frac{n}{n-2} > 1$ for $n > 2$ and $\chi > 2$ for $n = 2$.

Choose the cutoff function as follows. For any $0 < r < R \le 1$ set $\eta \in C_0^1(B_R)$ with the property

$$
\eta \equiv 1 \text{ in } B_r \quad \text{and} \quad |D\eta| \le \frac{2}{R-r}.
$$

Then we obtain

$$
\left( \int_{B_r} w^{2\chi} \right)^{1/\chi} \le C \frac{(1 + \beta)^\alpha}{(R - r)^2} \int_{B_R} w^2.
$$

Recalling the definition of $w$, we have

$$
\left( \int_{B_r} \bar{u}^{2\chi} \bar{u}_m^{\beta\chi} \right)^{1/\chi} \le C \frac{(1 + \beta)^\alpha}{(R - r)^2} \int_{B_R} \bar{u}^{2} \bar{u}_m^{\beta}.
$$