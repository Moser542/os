where $C$ is a positive constant depending only on $n, \lambda, m, M$, and $\Omega$, independently of $k$. In particular, the right-hand side expression in (6.9) is uniformly bounded in $C^{1,\alpha}$-norms independent of $k$. By the global $C^{2,\alpha}$-estimate, we have

$$
\|u_k\|_{C^{2,\alpha}(\bar{\Omega})} \le C
$$

where $C$ is a positive constant depending only on $n, \lambda, m, M$, and $\Omega$, independently of $k$. Therefore, $u \in C^2(\Omega)$ and

$$
u_k \to u \quad \text{in the } C^2\text{-norm in } \Omega.
$$

Hence $u$ is the desired solution.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAhCAIAAABBfoyNAAAAsUlEQVR4nO3WsQ2FIBAG4DuijTu4CgswAis4hIXDMI9gT8cA0hgEXvFeobGTnIkv/N1RfLkcVxzmnIEmjMit9KN0cyzWdR2GYdu2EpExJoSQUkI+ZFmWskZ/advWe38ayHfHp2nKBRnHMYTgnKOadYzxnRtS6Ur/Hb3vOxU9zzMVba2lolNKL/zGSj9HI2JzfVVKaa1vo8YYAOj7/nQsOOe6rrvfKgAAICLn3HuPrzyCP7jNj64EspxgAAAAAElFTkSuQmCC)

As an application, we prove the following result.

COROLLARY 6.14 Let $\Omega$ be a bounded $C^{2,\alpha}$-domain in $\mathbb{R}^n$ and $f$ be a bounded $C^1$-function in $\bar{\Omega} \times \mathbb{R}$. Then there exists a solution $u \in C^{2,\alpha}(\bar{\Omega})$ of

$$
\begin{aligned} \Delta u &= f(x, u) & \text{in } \Omega, \\ u &= 0 & \text{on } \partial\Omega. \end{aligned}
$$

PROOF: Set

$$
M = \sup_{\Omega \times \mathbb{R}} |f|.
$$

Let $\underline{u}, \bar{u} \in C^{2,\alpha}(\bar{\Omega})$ satisfy

$$
\begin{aligned} \Delta \underline{u} &= M & \text{in } \Omega, \quad \underline{u} &= 0 & \text{on } \partial\Omega, \\ \Delta \bar{u} &= -M & \text{in } \Omega, \quad \bar{u} &= 0 & \text{on } \partial\Omega; \end{aligned}
$$

then

$$
\Delta \underline{u} \ge \Delta \bar{u} \quad \text{in } \Omega, \quad \underline{u} = \bar{u} \quad \text{on } \partial\Omega.
$$

By the maximum principle, we have $\underline{u} \le \bar{u}$ in $\Omega$. It is obvious that

$$
\Delta \underline{u} \ge f(x, \underline{u}), \quad \Delta \bar{u} \le f(x, \bar{u}) \quad \text{in } \Omega.
$$

Hence $\underline{u}$ and $\bar{u}$ satisfy the conditions in Theorem 6.13. We obtain the desired result by Theorem 6.13.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAhCAIAAABBfoyNAAAAsUlEQVR4nO3WsQ2FIBAG4DsijTuwCgs4gis4hIXDMA9ob8cAXGNAeMV7hcROg4kv/N1RfLkcVxymlKBMWCG30uc0x8I5NwzDtm13RMZY13V930M6ZFmWe43+wjknomwg30WcpindyDiO3ntrbalZ7/v+zg2pdKX/jg4hlKK11qXodV1L0THGF35jpZ+jEbE5vyqljDGX0XmeAUAIkR0L1tq2ba+3CgAAiCilJCKsl2qeD6cwj66qScOQAAAAAElFTkSuQmCC)

REMARK 6.15. Corollary 6.14 still holds if we assume $f$ is $C^1$ in $\bar{\Omega} \times \mathbb{R}$ and satisfies

$$
|f(x, z)| \le C(1 + |z|^\tau) \quad \text{for any } (x, z) \in \bar{\Omega} \times \mathbb{R}
$$

for some $C > 0$ and $\tau \in [0, 1)$. It is important to assume $\tau < 1$. Dirichlet problems may not be solvable if $\tau = 1$.