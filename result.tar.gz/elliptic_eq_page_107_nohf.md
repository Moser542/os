COROLLARY 5.11 Suppose $u$ belongs to $\mathcal{S}(\lambda, \Lambda, f)$ in $B_1$ for some $f \in C(B_1)$. Then $u \in C^\alpha(B_1)$ for some $\alpha \in (0, 1)$ depending only on $n$, $\lambda$, and $\Lambda$. Moreover, there holds

$$
|u(x) - u(y)| \le C |x - y|^\alpha \left\{ \sup_{B_1} |u| + \|f\|_{L^n(B_1)} \right\} \quad \text{for any } x, y \in B_{1/2}
$$

where $C = C(n, \lambda, \Lambda)$ is a positive constant.

For convenience we work in cubes instead of balls. We will prove the following result.

LEMMA 5.12 Suppose $u$ belongs to $\mathcal{S}(\lambda, \Lambda, f)$ in $Q_{4\sqrt{n}}$ with $u \ge 0$ in $Q_{4\sqrt{n}}$ for some $f \in C(Q_{4\sqrt{n}})$. Then there exist two positive constants $\varepsilon_0$ and $C$, depending only on $n$, $\lambda$, and $\Lambda$, such that if $\inf_{Q_{1/4}} u \le 1$ and $\|f\|_{L^n(Q_{4\sqrt{n}})} \le \varepsilon_0$ there holds $\sup_{Q_{1/4}} u \le C$.

Theorem 5.10 easily follows from Lemma 5.12. For $u \in \mathcal{S}(\lambda, \Lambda, f)$ in $Q_{4\sqrt{n}}$ with $u \ge 0$ in $Q_{4\sqrt{n}}$, consider

$$
u_\delta = \frac{u}{\inf_{Q_{1/4}} u + \delta + \frac{1}{\varepsilon_0} \|f\|_{L^n(Q_{4\sqrt{n}})}} \quad \text{for } \delta > 0.
$$

We apply Lemma 5.12 to $u_\delta$ to get, after letting $\delta \to 0$,

$$
\sup_{Q_{1/4}} u \le C \left\{ \inf_{Q_{1/4}} u + \|f\|_{L^n(Q_{4\sqrt{n}})} \right\}.
$$

Then Theorem 5.10 follows by a standard covering argument.

Now we begin to prove Lemma 5.12. The following result is the key ingredient. It claims that if the solution is small somewhere in $Q_3$ then it is under control in a good portion of $Q_1$.

LEMMA 5.13 Suppose $u$ belongs to $\mathcal{S}^+(\lambda, \Lambda, f)$ in $B_{2\sqrt{n}}$ for some $f \in C(B_{2\sqrt{n}})$. Then there exist constants $\varepsilon_0 > 0$, $\mu \in (0, 1)$, and $M > 1$, depending only on $n$, $\lambda$, and $\Lambda$, such that if

$$
(5.3) \qquad u \ge 0 \text{ in } B_{2\sqrt{n}}, \quad \inf_{Q_3} \inf u \le 1, \quad \|f\|_{L^n(B_{2\sqrt{n}})} \le \varepsilon_0,
$$

there holds

$$
|\{u \le M\} \cap Q_1| > \mu.
$$

PROOF: We will construct a function $g$, which is very concave outside $Q_1$, such that if we correct $u$ by $g$ the contact set occurs in $Q_1$. In other words, we localize where contact occurs by choosing suitable functions.

Note $B_{1/4} \subset B_{1/2} \subset Q_1 \subset Q_3 \subset B_{2\sqrt{n}}$. Define $g$ in $B_{2\sqrt{n}}$ by

$$
g(x) = -M \left(1 - \frac{|x|^2}{4n}\right)^\beta
$$

for large $\beta > 0$ to be determined and some $M > 0$. We choose $M$, according to $\beta$, such that

$$
(5.4) \qquad g = 0 \text{ on } \partial B_{2\sqrt{n}} \quad \text{and} \quad g \le -2 \text{ in } Q_3.
$$