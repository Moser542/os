For $2 \le k < n$, $\varphi_k(y, r) = 0$ for $|y| = r$. Then we have

$$
\int_{B_r(0)} u(y) \frac{\partial \varphi_k}{\partial r}(y, r) dy = 0.
$$

Direct calculation yields $\frac{\partial \varphi_k}{\partial r}(y, r) = (-2r)(n - k + 1)\varphi_{k+1}(y, r)$. Hence we have (1.4). Therefore by taking $k = n - 1$ in (1.4) we conclude

$$
\int_{B_r(0)} u(y)((n + 2)|y|^2 - nr^2) dy = 0.
$$

Differentiating with respect to $r$ again we get (1.2). $\square$

1.3. Fundamental Solutions

We begin this section by seeking a harmonic function $u$, that is, $\Delta u = 0$ in $\mathbb{R}^n$, which depends only on $r = |x - a|$ for some fixed $a \in \mathbb{R}^n$. We set $v(r) = u(x)$. This implies

$$
v'' + \frac{n-1}{r}v' = 0
$$

and hence

$$
v(r) = \begin{cases} c_1 + c_2 \log r, & n = 2, \\ c_3 + c_4 r^{2-n}, & n \ge 3, \end{cases}
$$

where $c_i$ are constants for $i = 1, 2, 3, 4$. We are interested in a function with a singularity such that

$$
\int_{\partial B_r} \frac{\partial v}{\partial r} dS = 1 \quad \text{for any } r > 0.
$$

Hence we set for any fixed $a \in \mathbb{R}^n$

$$
\Gamma(a, x) = \frac{1}{2\pi} \log |a - x| \quad \text{for } n = 2
$$

$$
\Gamma(a, x) = \frac{1}{\omega_n(2-n)} |a - x|^{2-n} \quad \text{for } n \ge 3.
$$

To summarize, we have that for fixed $a \in \mathbb{R}^n$, $\Gamma(a, x)$ is harmonic at $x \neq a$, that is,

$$
\Delta_x \Gamma(a, x) = 0 \quad \text{for any } x \neq a
$$

and has a singularity at $x = a$. Moreover, it satisfies

$$
\int_{\partial B_r(a)} \frac{\partial \Gamma}{\partial n_x}(a, x) dS_x = 1 \quad \text{for any } r > 0.
$$

Now we prove the Green's identity.