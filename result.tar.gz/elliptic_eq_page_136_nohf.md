THEOREM 6.12 Let $\Omega$ be a bounded $C^{2,\alpha}$-domain in $\mathbb{R}^n$ and $L$ be a uniformly elliptic operator in $\Omega$ as defined in (6.7), with (6.8) satisfied, $c \le 0$ in $\Omega$, and $a_{ij}, b_i, c \in C^\alpha(\bar{\Omega})$ for some $\alpha \in (0, 1)$. If the Dirichlet problem for the Poisson equation

$$
\begin{aligned}
\Delta u &= f \quad \text{in } \Omega, \\
u &= \varphi \quad \text{on } \partial\Omega,
\end{aligned}
$$

has a $C^{2,\alpha}(\bar{\Omega})$ solution for all $f \in C^\alpha(\bar{\Omega})$ and $\varphi \in C^{2,\alpha}(\bar{\Omega})$, then the Dirichlet problem

$$
\begin{aligned}
Lu &= f \quad \text{in } \Omega, \\
u &= \varphi \quad \text{on } \partial\Omega,
\end{aligned}
$$

also has a (unique) $C^{2,\alpha}(\bar{\Omega})$ solution for all such $f$ and $\varphi$.

The proof is based on the *method of continuity*. Briefly summarized, this method as applied here starts with the solution of the Poisson equation $\Delta u = f$ and then arrives at a solution of $Lu = f$ through solutions of a continuous family of equations connecting $\Delta u = f$ and $Lu = f$. The global $C^{2,\alpha}$-estimates play essential roles.

PROOF: Without loss of generality, we assume $\varphi = 0$. Otherwise, we consider $Lv = f - L\varphi$ in $\Omega$, $v = 0$ on $\partial\Omega$.

We consider the family of equations

$$
L_t u \equiv tLu + (1-t)\Delta u = f
$$

for $t \in [0, 1]$. We note that $L_0 = \Delta$, $L_1 = L$. By writing

$$
L_t u = a_{ij}^t D_{ij} u + b_i^t D_i u + c^t u,
$$

it is easy to see that

$$
a_{ij}^t(x)\xi_i\xi_j \ge \min(1, \lambda)|\xi|^2
$$

for any $x \in \Omega$ and $\xi \in \mathbb{R}^n$ and that

$$
|a_{ij}^t|_{C^\alpha(\bar{\Omega})}, |b_i^t|_{C^\alpha(\bar{\Omega})}, |c^t|_{C^\alpha(\bar{\Omega})} \le \max(1, \Lambda)
$$

independently of $t \in [0, 1]$. It follows that

$$
|L_t u|_{C^\alpha(\bar{\Omega})} \le C|u|_{C^{2,\alpha}(\Omega)}
$$

where $C$ is a positive constant depending only on $n, \alpha, \lambda, \Lambda$, and $\Omega$. Then for each $t \in [0, 1]$, $L_t : \mathcal{X} \to C^\alpha(\Omega)$ is a bounded linear operator, where

$$
\mathcal{X} = \{u \in C^{2,\alpha}(\bar{\Omega}) : u = 0 \text{ on } \partial\Omega\}.
$$

We note that $\mathcal{X}$ is a Banach space with respect to $|\cdot|_{C^{2,\alpha}(\bar{\Omega})}$.

We now let $I$ be the collection of $s \in [0, 1]$ such that the Dirichlet problem

$$
\begin{aligned}
L_s u &= f \quad \text{in } \Omega, \\
u &= 0 \quad \text{on } \partial\Omega,
\end{aligned}
$$