It is straightforward to verify that for $p \in (1, \infty]$ the condition $\theta \in L^p(\Omega)$ implies $D^2u \in L^p(\Omega)$ and

$$
\|D^2u\|_{L^p(\Omega)} \le 2\|\theta\|_{L^p(\Omega)}.
$$

In order to study the integrability of the function $\theta$ we discuss its distribution function, that is,

$$
\mu_{\theta}(t) = |\{x \in \Omega : \theta(x) > t\}| \quad \text{for any } t > 0.
$$

It is clear that

$$
\mu_{\theta}(t) \le |A_t(u, \Omega)| \quad \text{for any } t > 0.
$$

Hence we need to study the decay of $|A_t(u, \Omega)|$.

LEMMA 5.24 Suppose that $\Omega$ is a bounded domain with $B_{8\sqrt{n}} \subset \Omega$ and that $u \in C(\Omega)$ is a viscosity solution of

$$
a_{ij} D_{ij} u = f \quad \text{in } B_{8\sqrt{n}}.
$$

Then for any $\varepsilon_0 \in (0, 1)$ there exist an $M > 1$, depending only on $n$, $\lambda$, and $\Lambda$, and an $\varepsilon \in (0, 1)$, depending only on $n$, $\lambda$, $\Lambda$, and $\varepsilon_0$, such that if

$$
(5.21) \qquad \|f\|_{L^n(B_{8\sqrt{n}})} \le \varepsilon, \quad \|a_{ij} - a_{ij}(0)\|_{L^n(B_{7\sqrt{n}})} \le \varepsilon,
$$

and

$$
(5.22) \qquad G_1(u, \Omega) \cap Q_3 \ne \emptyset,
$$

then there holds

$$
|G_M(u, \Omega) \cap Q_1| \ge 1 - \varepsilon_0.
$$

PROOF: Let $x_1 \in G_1(u, \Omega) \cap Q_3$. Then there exists an affine function $L$ such that

$$
-\frac{1}{2}|x - x_1|^2 \le u(x) - L(x) \le \frac{1}{2}|x - x_1|^2 \quad \text{in } \Omega.
$$

By considering $(u - L)/c(n)$ instead of $u$, for $c(n) > 1$ large enough, depending only on $n$, we may assume that

$$
(5.23) \qquad |u| \le 1 \quad \text{in } B_{8\sqrt{n}},
$$

which implies

$$
(5.24) \qquad -|x|^2 \le u(x) \le |x|^2 \quad \text{for any } x \in \Omega \setminus B_{6\sqrt{n}}.
$$

Solve for $h \in C(\bar{B}_{7\sqrt{n}}) \cap C^\infty(B_{7\sqrt{n}})$ such that

$$
a_{ij}(0) D_{ij} h = 0 \quad \text{in } B_{7\sqrt{n}},
$$

$$
h = u \quad \text{on } \partial B_{7\sqrt{n}}.
$$

Then Lemma 5.18 implies

$$
(5.25) \qquad |u - h|_{L^\infty(B_{6\sqrt{n}})} \le C\{\varepsilon^\gamma + \|f\|_{L^n(B_{8\sqrt{n}})}\}
$$

and

$$
(5.26) \qquad \|h\|_{C^2((B_{6\sqrt{n}}))} \le C
$$