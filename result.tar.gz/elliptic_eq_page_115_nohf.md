if we take $c_1$ small enough, depending only on $n$, $\lambda$, and $\Lambda$.

Hence $\tilde{u}$ satisfies the assumption of Lemma 5.16 with $\Omega$ replaced by $\tilde{\Omega}$. We may apply Lemma 5.16 to $\tilde{u}$ to get

$$
|G_M^{-}(\tilde{u}, \tilde{\Omega}) \cap Q_1| \geq 1 - \sigma \quad \text{or} \quad |G_M^{k+1}(u, \Omega) \cap Q| > (1 - \sigma)|Q|.
$$

This contradicts (5.14). We are in a position to apply Lemma 5.9.

Step 3. We finish the proof of Lemma 5.15. Define for $k = 0, 1, \dots$,

$$
\begin{aligned} \alpha_k &= |A_M^{-k}(u, \Omega) \cap Q_1|, \\ \beta_k &= |\{x \in Q_1 : m(f^n)(x) \geq (c_1 M^k)^n\}|. \end{aligned}
$$

Then Step 2 implies $\alpha_{k+1} \leq \sigma(\alpha_k + \beta_k)$ for any $k = 0, 1, \dots$. Hence by iteration we have

$$
\alpha_k \leq \sigma^k + \sum_{i=0}^{k-1} \sigma^{k-i} \beta_i.
$$

Since $\|f^n\|_{L^1} \leq \delta_0^n$ and the maximal operator is of weak type (1, 1), we conclude that

$$
\beta_k \leq c(n)\delta_0^n (c_1 M^k)^{-n} = C(n, \lambda, \Lambda) M^{-nk}.
$$

This implies

$$
\sum_{i=0}^{k-1} \sigma^{k-i} \beta_i \leq C \sum_{i=0}^{k-1} \sigma^{k-i} M^{-ni} \leq Ck\gamma_0^k
$$

with $\gamma_0 = \max\{\sigma, M^{-n}\} < 1$. Therefore we obtain for $k$ large

$$
\alpha_k \leq \sigma^k + Ck\gamma_0^k \leq (1 + Ck)\gamma_0^k \leq \gamma^k
$$

for some $\gamma = \gamma(n, \lambda, \Lambda) \in (0, 1)$.

This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAhCAIAAACqSTeOAAAAl0lEQVR4nO3WvQkEIRAF4DfDtWBmH1uFodiBxdiFuWArFuTPBcJxbnS4GBzMy0T4ZoIJHo0xcCB8AhX3uPu6vXvvDy+EiJgZ4yshhCfix/XeL/uWUgBc16W13kN77znnGOOyr3MOQEpp7KbWOgf82z2IK6644oor7i+59wcA1lrmzXmzezDz4iql5l9rbc8FQETGGDrUf9+Fi3s2w2iFXAAAAABJRU5ErkJggg==)

REMARK 5.17. The polynomial decay of the function

$$
\mu(t) = |A_t(u, \Omega) \cap Q_1|
$$

for $u \in S(\lambda, \Lambda, f)$ implies that $D^2u$ is $L^p$-integrable in $Q_1$ for small $p > 0$ depending only on $n$, $\lambda$, and $\Lambda$. In order to show the $L^p$-integrability for large $p$ we need to speed up the convergence in the proof of Lemma 5.15. We will discuss $W^{2,p}$-estimates in Section 5.5.

## 5.4. Schauder Estimates

In this section we will prove the Schauder estimates for viscosity solutions. Throughout this section we always assume that $a_{ij} \in C(B_1)$ satisfies

$$
\lambda|\xi|^2 \leq a_{ij}(x)\xi_i\xi_j \leq \Lambda|\xi|^2 \quad \text{for any } x \in B_1 \text{ and any } \xi \in \mathbb{R}^n
$$

for some positive constants $\lambda$ and $\Lambda$ and that $f$ is a continuous function in $B_1$.

The following approximation result plays an important role in the discussion of regularity theory.