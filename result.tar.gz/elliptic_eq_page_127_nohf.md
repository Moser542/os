It is obvious that $D$ is relatively closed. This follows easily from the continuity of $u$ and $v$.

Next we show that $D$ is open. For any $x_0 \in D$, we take $r < \text{dist}(x_0, \partial\Omega)$. Let $\bar{u}$ and $\bar{v}$ solve, respectively,

$$
\begin{aligned}
\Delta\bar{u} &= 0 \quad \text{in } B_r(x_0), & \bar{u} &= u \quad \text{on } \partial B_r(x_0), \\
\Delta\bar{v} &= 0 \quad \text{in } B_r(x_0), & \bar{v} &= v \quad \text{on } \partial B_r(x_0).
\end{aligned}
$$

The existence of $\bar{u}$ and $\bar{v}$ in $B_r(x_0)$ is implied by the Poisson integral formula. The definition of subsolutions and supersolutions implies $u \le \bar{u}$ and $\bar{v} \le v$ in $B_r(x_0)$; hence

$$
\bar{u} - \bar{v} \ge u - v \quad \text{in } B_r(x_0).
$$

Next,

$$
\begin{aligned}
\Delta(\bar{u} - \bar{v}) &= 0 \quad \text{in } B_r(x_0), \\
\bar{u} - \bar{v} &= u - v \quad \text{on } \partial B_r(x_0).
\end{aligned}
$$

With $u - v \le M$ on $\partial B_r(x_0)$, the maximum principle implies $\bar{u} - \bar{v} \le M$ in $B_r(x_0)$; in particular,

$$
M \ge (\bar{u} - \bar{v})(x_0) \ge (u - v)(x_0) = M.
$$

Hence $(\bar{u} - \bar{v})(x_0) = M$ and then $\bar{u} - \bar{v}$ has an interior maximum at $x_0$. By the strong maximum principle, $\bar{u} - \bar{v} \equiv M$ in $\bar{B}_r(x_0)$. Therefore, $u - v = M$ on $\partial B_r(x_0)$. This holds for any $r < \text{dist}(x_0, \partial\Omega)$. Then $u - v = M$ in $B_r(x_0)$ and hence $B_r(x_0) \subset D$. In conclusion, $D$ is both relatively closed and open in $\Omega$. Therefore either $D = \emptyset$ or $D = \Omega$. In other words, $u - v$ either attains its maximum only on $\partial\Omega$ or $u - v$ is constant. By $u \le v$ in $\partial\Omega$, we have $u \le v$ in $\Omega$ for both cases. $\square$

The proof in fact yields the strong maximum principle: Either $u < v$ in $\Omega$ or $u - v$ is constant in $\Omega$.

Before we start our discussion of Perron's method, we demonstrate how to generate bigger subharmonic functions from existing subharmonic functions.

**LEMMA 6.3** Let $v \in C(\bar{\Omega})$ be a subharmonic function in $\Omega$ and $B$ be a ball in $\Omega$ with $\bar{B} \subset \Omega$. Let $w$ be defined by $w = v$ in $\bar{\Omega} \setminus B$ and $\Delta w = 0$ in $B$. Then $w$ is a subharmonic function in $\Omega$ and $v \le w$ in $\bar{\Omega}$.

The function $w$ is often called the *harmonic lifting* of $v$ (in $B$).

**PROOF:** The existence of $w$ in $B$ is implied by the Poisson integral formula. Then $w$ is smooth in $B$ and is continuous in $\bar{\Omega}$. We also have $v \le w$ in $B$ by Definition 6.1.

Next, we take any $B'$ with $\bar{B}' \subset \Omega$ and consider a harmonic function $u \in C(\bar{B}')$ with $w \le u$ on $\partial B'$. By $v \le w$ on $\partial B'$, we have $v \le u$ on $\partial B'$. Then, $v$ is subharmonic and $u$ is harmonic in $B'$ with $v \le u$ on $\partial B'$. By Lemma 6.2, we have $v \le u$ in $B'$. Hence $w \le u$ in $B \setminus B'$. Next, both $w$ and $u$ are harmonic in $B \cap B'$ and $w \le u$ on $\partial(B \cap B')$. By the maximum principle, we have $w \le u$ in $B \cap B'$. Hence $w \le u$ in $B'$. Therefore, $w$ is subharmonic in $\Omega$ by Definition 6.1. $\square$