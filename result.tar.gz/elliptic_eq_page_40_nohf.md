where $C$ is a positive constant depending only on $\lambda$, $\Omega$, $|a_{ij}, b_i|_{L^\infty(\Omega)}$, $M = |u|_{L^\infty(\Omega)}$, $|f|_{L^\infty(\Omega \times [-M, M])}$, and $|\varphi|_{C^2(\bar{\Omega})}$ for some $\varphi \in C^2(\bar{\Omega})$ with $\varphi = u$ on $\partial\Omega$.

PROOF: For simplicity we assume $u = 0$ on $\partial\Omega$. As before, set $L = a_{ij} D_{ij} + b_i D_i$. Then we have

$$
L(\pm u) = \pm f \geq -F \quad \text{in } \Omega
$$

where we denote $F = \sup_{\Omega} |f(\cdot, u)|$. Now fix $x_0 \in \partial\Omega$. We will construct a function $w$ such that

$$
Lw \leq -F \quad \text{in } \Omega, \quad w(x_0) = 0, \quad w|_{\partial\Omega} \geq 0.
$$

Then by the maximum principle we have

$$
-w \leq u \leq w \quad \text{in } \Omega.
$$

Taking the normal derivative at $x_0$, we have

$$
\left| \frac{\partial u}{\partial n}(x_0) \right| \leq \frac{\partial w}{\partial n}(x_0).
$$

So we need to bound $\frac{\partial w}{\partial n}(x_0)$ independently of $x_0$.

Consider the exterior ball $B_R(y)$ with $\bar{B}_R(y) \cap \bar{\Omega} = \{x_0\}$. Define $d(x)$ as the distance from $x$ to $\partial B_R(y)$. Then we have

$$
0 < d(x) < D \equiv \text{diam}(\Omega) \quad \text{for any } x \in \Omega.
$$

In fact, $d(x) = |x - y| - R$ for any $x \in \Omega$. Consider $w = \psi(d)$ for some function $\psi$ defined in $[0, \infty)$. Then we need

$$
\psi(0) = 0 \quad (\Longrightarrow w(x_0) = 0)
$$

$$
\psi(d) > 0 \quad \text{for } d > 0 \quad (\Longrightarrow w|_{\partial\Omega} \geq 0)
$$

$\psi'(0)$ is controlled.

From the first two inequalities, it is natural to require that $\psi'(d) > 0$. Note

$$
Lw = \psi''a_{ij}D_idD_jd + \psi'a_{ij}D_{ij}d + \psi'b_iD_id.
$$

Direct calculation yields

$$
D_id(x) = \frac{x_i - y_i}{|x - y|},
$$

$$
D_{ij}d(x) = \frac{\delta_{ij}}{|x - y|} - \frac{(x_i - y_i)(x_i - y_i)}{|x - y|^3},
$$

which imply $|Dd| = 1$ and with $\Lambda = \sup |a_{ij}|$

$$
\begin{aligned} a_{ij} D_{ij} d &= \frac{a_{ii}}{|x - y|} - \frac{a_{ij}}{|x - y|} D_i d D_j d \leq \frac{n\Lambda}{|x - y|} - \frac{\lambda}{|x - y|} \\ &= \frac{n\Lambda - \lambda}{|x - y|} \leq \frac{n\Lambda - \lambda}{R}. \end{aligned}
$$