LEMMA 5.18 Suppose $u \in C(B_1)$ is a viscosity solution of

$$
a_{ij} D_{ij} u = f \quad \text{in } B_1
$$

with $|u| \le 1$ in $B_1$. Assume for some $0 < \varepsilon < \frac{1}{16}$,

$$
\|a_{ij} - a_{ij}(0)\|_{L^n(B_{3/4})} \le \varepsilon.
$$

Then there exists a function $h \in C(\bar{B}_{3/4})$ with $a_{ij}(0)D_{ij}h = 0$ in $B_{3/4}$ and $|h| \le 1$ in $B_{3/4}$ such that

$$
|u - h|_{L^{\infty}(B_{1/2})} \le C\{\varepsilon^{\gamma} + \|f\|_{L^n(B_1)}\}
$$

where $C = C(n, \lambda, \Lambda)$ is a positive constant and $\gamma = \gamma(n, \lambda, \Lambda) \in (0, 1)$.

PROOF: Solve for $h \in C(\bar{B}_{3/4}) \cap C^\infty(B_{3/4})$ such that

$$
a_{ij}(0)D_{ij}h = 0 \quad \text{in } B_{3/4},
$$

$$
h = u \quad \text{on } \partial B_{3/4}.
$$

The maximum principle implies $|h| \le 1$ in $B_{3/4}$. Note that $u$ belongs to $\mathcal{S}(\lambda, \Lambda, f)$ in $B_1$. Corollary 5.11 implies that $u \in C^\alpha(\bar{B}_{3/4})$ for some $\alpha = \alpha(n, \lambda, \Lambda) \in (0, 1)$ with the estimate

$$
\|u\|_{C^\alpha(\bar{B}_{3/4})} \le C(n, \lambda, \Lambda)\{1 + \|f\|_{L^n(B_1)}\}.
$$

By Lemma 1.35 we have

$$
\|h\|_{C^{\alpha/2}(\bar{B}_{3/4})} \le C \|u\|_{C^\alpha(\bar{B}_{3/4})} \le C(n, \lambda, \Lambda)\{1 + \|f\|_{L^n(B_1)}\}.
$$

Since $u - h = 0$ on $\partial B_{3/4}$ we get for any $0 < \delta < \frac{1}{4}$

$$
(5.15) \qquad |u - h|_{L^{\infty}(\partial B_{3/4-\delta})} \le C \delta^{\alpha/2} \{1 + \|f\|_{L^n(B_1)}\}.
$$

We claim for any $0 < \delta < 1$

$$
(5.16) \qquad |D^2 h|_{L^{\infty}(B_{3/4-\delta})} \le C \delta^{\alpha/2-2} \{1 + \|f\|_{L^n(B_1)}\}.
$$

In fact, for any $x_0 \in B_{3/4-\delta}$ we apply interior $C^2$-estimate to $h - h(x_1)$ in $B_\delta(x_0) \subset B_{3/4}$ for some $x_1 \in \partial B_\delta(x_0)$ and obtain

$$
|D^2 h(x_0)| \le C \delta^{-2} \sup_{B_\delta(x_0)} |h - h(x_1)| \le C \delta^{-2} \delta^{\alpha/2} \{1 + \|f\|_{L^n(B_1)}\}.
$$

Note that $u - h$ is a viscosity solution of

$$
a_{ij} D_{ij} (u - h) = f - (a_{ij} - a_{ij}(0)) D_{ij} h \equiv F \quad \text{in } B_{3/4}.
$$

By Theorem 5.8 (the Alexandroff maximum principle) we have with (5.15) and (5.16)

$$
\begin{aligned} |u - h|_{L^{\infty}(B_{3/4-\delta})} & \le |u - h|_{L^{\infty}(\partial B_{3/4-\delta})} + C \|F\|_{L^n(B_{3/4-\delta})} \\ & \le |u - h|_{L^{\infty}(\partial B_{3/4-\delta})} \\ & \quad + C |D^2 h|_{L^{\infty}(B_{3/4-\delta})} \|a_{ij} - a_{ij}(0)\|_{L^n(B_{3/4})} + C \|f\|_{L^n(B_1)} \\ & \le C(\delta^{\alpha/2} + \delta^{\alpha/2-2}\varepsilon)\{1 + \|f\|_{L^n(B_1)}\} + C \|f\|_{L^n(B_1)}. \end{aligned}
$$