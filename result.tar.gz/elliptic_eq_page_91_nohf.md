for any small $\varepsilon > 0$. Therefore we obtain by (4.10)

$$
\begin{aligned}
\int_{B_1} |D(\zeta|w|^\beta)|^2 &\le C \left\{ (2\beta)^{2\beta} \int_{B_1} \zeta^2 |Dw|^2 + \beta^\alpha \int_{B_1} (|D\zeta|^2 + \zeta^2)|w|^{2\beta} \right\} \\
&\le C \left\{ (2\beta)^{2\beta} \int_{B_1} |D\zeta|^2 + \beta^\alpha \int_{B_1} (|D\zeta|^2 + \zeta^2)|w|^{2\beta} \right\}
\end{aligned}
$$

for some positive constant $\alpha$ depending only on $n$ and $q$. Apply the Sobolev inequality for $\zeta|w|^\beta \in W_0^{1,2}(\mathbb{R}^n)$ with $\chi = \frac{n}{n-2}$ to get

$$
\left( \int_{B_1} \zeta^{2\chi} |w|^{2\beta\chi} \right)^{1/\chi} \le C \beta^\alpha \left\{ (2\beta)^{2\beta} \int_{B_1} |D\zeta|^2 + \int_{B_1} (|D\zeta|^2 + \zeta^2)|w|^{2\beta} \right\}.
$$

Choose the cutoff function as follows: For $\tau \le r < R \le 1$, set $\zeta \equiv 1$ on $B_r(0)$, $\zeta \equiv 0$ in $B_1(0) \setminus B_R(0)$, and $|D\zeta| \le \frac{2}{R-r}$. Therefore we have

$$
\left( \int_{B_r} |w|^{2\beta\chi} \right)^{1/\chi} \le \frac{C \beta^\alpha}{(R-r)^2} \left\{ (2\beta)^{2\beta} + \int_{B_R} |w|^{2\beta} \right\}.
$$

For some $\tau' \in (\tau, 1)$ set $\beta_i = \chi^{i-1}$ and $r_i = \tau + \frac{1}{2^{i-1}}(\tau' - \tau)$ for any $i = 1, 2, \dots$. Then for each $i = 1, 2, \dots$,

$$
\left( \int_{B_{r_i}} |w|^{2\chi i} \right)^{1/\chi} \le \frac{C \chi^{(i-1)\alpha} 2^{2(i-1)}}{(\tau' - \tau)^2} \left\{ (2\chi^{i-1})^{2\chi^{i-1}} + \int_{B_{r_{i-1}}} |w|^{2\chi^{i-1}} \right\}.
$$

Set

$$
I_j = \|w\|_{L^{2\chi^j}(B_{r_j})}.
$$

Then we have for $j = 1, 2, \dots$,

$$
I_j \le C \frac{j}{2\chi^j} \{2\chi^{j-1} + I_{j-1}\}
$$

with $C = C(n, q, \lambda, \Lambda, \tau, \tau') > 0$. Iterating the above inequality and observing that

$$
\sum_{i=0}^{\infty} \frac{i}{\chi^i} < \infty,
$$

we obtain

$$
I_j \le C \sum_{i=1}^{j} \chi^{i-1} + CI_0, \quad \text{that is,} \quad I_j \le C\chi^j + CI_0.
$$

Now for $\beta \ge 2$ there exists a $j$ such that $2\chi^{j-1} \le \beta < 2\chi^j$. Hence

$$
I_{\beta}(B_{\tau}) \equiv \left( \int_{B_{\tau}} |w|^{\beta} \right)^{1/\beta} \le CI_{j} \le C\chi^{j} + CI_{0} \le C\beta + CI_{0} \le C\bar{0}\beta,
$$