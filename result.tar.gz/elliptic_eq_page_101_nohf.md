# Viscosity Solutions

## 5.1. Guide

In this chapter we generalize the notion of classical solutions to viscosity solutions and study their regularities. We define viscosity solutions by comparing them with quadratic polynomials and thus remove the requirement that solutions be at least $C^2$. The main tool for studying viscosity solutions is the maximum principle due to Alexandroff. We first generalize such maximum principles to viscosity solutions and then use the resulting estimate to discuss the regularity theory. We use it to control the distribution functions of solutions and obtain the Harnack inequality, and hence $C^\alpha$ regularity, which generalizes a result by Krylov and Safonov. We also use it to approximate solutions in $L^\infty$ by quadratic polynomials and get Schauder $(C^{2,\alpha})$-estimates. The methods are basically nonlinear in the sense that they do not rely on differentiating equations. This implies that the results obtained in this way may apply to general fully nonlinear equations, although in this chapter we focus only on linear equations.

Here we only try to explain a few basic ideas in obtaining estimates for viscosity solutions. Students should read the book [4] for further developments.

## 5.2. Alexandroff Maximum Principle

We begin this section with the definition of viscosity solutions. This very weak concept of solutions enables us to define a class of functions containing all classical solutions of linear and nonlinear elliptic equations with fixed ellipticity constants and bounded measurable coefficients.

Suppose that $\Omega$ is a bounded and connected domain in $\mathbb{R}^n$ and that $a_{ij} \in C(\Omega)$ satisfies

$$
\lambda|\xi|^2 \le a_{ij}(x)\xi_i\xi_j \le \Lambda|\xi|^2 \quad \text{for any } x \in \Omega \text{ and any } \xi \in \mathbb{R}^n
$$

for some positive constants $\lambda$ and $\Lambda$. Consider the operator $L$ in $\Omega$ defined by

$$
Lu \equiv a_{ij}(x)D_{ij}u \quad \text{for } u \in C^2(\Omega).
$$

Suppose $u \in C^2(\Omega)$ is a supersolution in $\Omega$, that is, $Lu \le 0$. Then for any $\varphi \in C^2(\Omega)$ with $L\varphi > 0$ we have

$$
L(u - \varphi) < 0 \quad \text{in } \Omega.
$$

This implies by the maximum principle that $u - \varphi$ cannot have local interior minima in $\Omega$. In other words if $u - \varphi$ has a local minimum at $x_0 \in \Omega$, there holds

$$
L\varphi(x_0) \le 0.
$$