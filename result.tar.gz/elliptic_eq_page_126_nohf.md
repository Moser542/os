Existence of Solutions

In this chapter we will discuss the existence of solutions of some boundary value problems for elliptic differential equations. We will illustrate several methods.

6.1. Perron Method

In this section we will discuss the existence of solutions by the Perron method, where we prove the existence of solutions of Dirichlet problems for elliptic operators on general domains when solutions of the same problems on balls are known to exist. We will illustrate this by the Laplace operator.

Let $\Omega$ be a bounded domain in $\mathbb{R}^n$ and $\varphi$ be a continuous function on $\partial\Omega$. Consider

$$
(6.1) \qquad \begin{aligned} \Delta u &= 0 & \text{in } \Omega, \\ u &= \varphi & \text{on } \partial\Omega. \end{aligned}
$$

If $\Omega$ is a ball, then the solution of (6.1) is given by the Poisson integral formula. We now solve (6.1) by Perron's method. The maximum principle plays an essential role. In discussions below, we avoid mean value properties of harmonic functions.

We first define continuous subharmonic and subharmonic functions based on the maximum principle.

DEFINITION 6.1 Let $\Omega$ be a domain in $\mathbb{R}^n$ and $v$ be a continuous function in $\Omega$. Then $v$ is *subharmonic* (*superharmonic*) in $\Omega$ if for any ball $B \subset \Omega$ and any harmonic function $w \in C(\bar{B})$

$$
v \le (\ge) w \text{ on } \partial B \quad \text{implies} \quad v \le (\ge) w \text{ in } B.
$$

We now prove a maximum principle for such subharmonic and superharmonic functions.

LEMMA 6.2 Let $\Omega$ be a bounded domain in $\mathbb{R}^n$ and $u, v \in C(\bar{\Omega})$. Suppose $u$ is subharmonic in $\Omega$ and $v$ is a superharmonic in $\Omega$ with $u \le v$ on $\partial\Omega$. Then $u \le v$ in $\Omega$.

PROOF: Without loss of generality, we assume $\Omega$ is connected. We first note that $u - v \le 0$ on $\partial\Omega$. Set $M = \max_{\bar{\Omega}}(u - v)$ and

$$
D = \{x \in \Omega : u(x) - v(x) = M\} \subset \Omega.
$$