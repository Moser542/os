where we used $\Delta u = 0$ in $B_1$. Hence $|Du|^2$ is a subharmonic function. To get interior estimates we need a cutoff function. For any $\varphi \in C_0^1(B_1)$ we have

$$
\Delta(\varphi|Du|^2) = (\Delta\varphi)|Du|^2 + 4 \sum_{i,j=1}^{n} D_i\varphi D_j u D_{ij} u + 2\varphi \sum_{i,j=1}^{n} (D_{ij} u)^2.
$$

By taking $\varphi = \eta^2$ for some $\eta \in C_0^1(B_1)$ with $\eta \equiv 1$ in $B_{1/2}$, we obtain by the Hölder inequality

$$
\begin{aligned} \Delta(\eta^2|Du|^2) &= 2\eta\Delta\eta|Du|^2 + 2|D\eta|^2|Du|^2 \\ &\quad + 8\eta \sum_{i,j=1}^{n} D_i\eta D_j u D_{ij} u + 2\eta^2 \sum_{i,j=1}^{n} (D_{ij} u)^2 \\ &\ge (2\eta\Delta\eta - 6|D\eta|^2)|Du|^2 \ge -C|Du|^2 \end{aligned}
$$

where $C$ is a positive constant depending only on $\eta$. Note that $\Delta(u^2) = 2|Du|^2 + 2u\Delta u = 2|Du|^2$ since $u$ is harmonic. By taking $\alpha$ large enough we get

$$
\Delta(\eta^2|Du|^2 + \alpha u^2) \ge 0.
$$

We may apply Theorem 1.29 (the maximum principle) to get the result. $\square$

Next we derive the Harnack inequality.

**LEMMA 1.32** *Suppose $u$ is a nonnegative harmonic function in $B_1$. Then there holds*

$$
\sup_{B_{1/2}} |D \log u| \le C
$$

where $C = C(n)$ is a positive constant.

**PROOF:** We may assume $u > 0$ in $B_1$. Set $v = \log u$. Then direct calculation shows

$$
\Delta v = -|Dv|^2.
$$

We need the interior gradient estimate on $v$. Set $w = |Dv|^2$. Then we get

$$
\Delta w + 2 \sum_{i=1}^{n} D_i v D_i w = 2 \sum_{i,j=1}^{n} (D_{ij} v)^2.
$$

As before we need a cutoff function. First note

$$
(1.6) \quad \sum_{i,j=1}^{n} (D_{ij} v)^2 \ge \sum_{i}^{n} (D_{ii} v)^2 \ge \frac{1}{n} (\Delta v)^2 = \frac{|Dv|^4}{n} = \frac{w^2}{n}.
$$