We need the following simple lemma:

LEMMA 4.3 Let $f(t) \ge 0$ be bounded in $[\tau_0, \tau_1]$ with $\tau_0 \ge 0$. Suppose for $\tau_0 \le t < s \le \tau_1$ we have

$$
f(t) \le \theta f(s) + \frac{A}{(s-t)^\alpha} + B
$$

for some $\theta \in [0, 1)$. Then for any $\tau_0 \le t < s \le \tau_1$ there holds

$$
f(t) \le c(\alpha, \theta) \left\{ \frac{A}{(s-t)^\alpha} + B \right\}.
$$

PROOF: Fix $\tau_0 \le t < s \le \tau_1$. For some $0 < \tau < 1$ we consider the sequence $\{t_i\}$ defined by

$$
t_0 = t \quad \text{and} \quad t_{i+1} = t_i + (1-\tau)\tau^i(s-t).
$$

Note $t_\infty = s$. By iteration

$$
f(t) = f(t_0) \le \theta^k f(t_k) + \left[ \frac{A}{(1-\tau)^\alpha} (s-t)^{-\alpha} + B \right] \sum_{i=0}^{k-1} \theta^i \tau^{-i\alpha}.
$$

Choose $\tau < 1$ such that $\theta\tau^{-\alpha} < 1$, that is, $\theta < \tau^\alpha < 1$. As $k \to \infty$ we have

$$
f(t) \le c(\alpha, \theta) \left\{ \frac{A}{(1-\tau)^\alpha} (s-t)^{-\alpha} + B \right\}.
$$

□

In the rest of this section we use Moser's iteration to prove a high integrability result that is closely related to Theorem 4.1. For the next result we require $n \ge 3$.

THEOREM 4.4 Suppose $a_{ij} \in L^\infty(B_1)$ and $c \in L^{n/2}(B_1)$ satisfy the following assumption:

$$
\lambda|\xi|^2 \le a_{ij}(x)\xi_i\xi_j \le \Lambda|\xi|^2 \quad \text{for any } x \in B_1, \xi \in \mathbb{R}^n,
$$

for some positive constants $\lambda$ and $\Lambda$. Suppose that $u \in H^1(B_1)$ is a subsolution in the following sense:

$$
\int_{B_1} a_{ij} D_i u D_j \varphi + cu\varphi \le \int_{B_1} f\varphi \quad \text{for any } \varphi \in H_0^1(B_1) \text{ and } \varphi \ge 0 \text{ in } B_1.
$$

If $f \in L^q(B_1)$ for some $q \in [\frac{2n}{n+2}, \frac{n}{2})$, then $u^+ \in L_{\text{loc}}^{q^*}(B_1)$ for $\frac{1}{q^*} = \frac{1}{q} - \frac{2}{n}$. Moreover, there holds

$$
\|u^+\|_{L^{q^*}(B_{1/2})} \le C\{\|u^+\|_{L^2(B_1)} + \|f\|_{L^q(B_1)}\}
$$

where $C = C(n, \lambda, \Lambda, q, \varepsilon(K))$ is a positive constant with

$$
\varepsilon(K) = \left( \int_{\{|c|>K\}} |c|^{n/2} \right)^{2/n}.
$$