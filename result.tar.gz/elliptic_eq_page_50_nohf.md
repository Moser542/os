# Weak Solutions: Part I

## 3.1. Guide

The goal of this chapter and the next is to discuss various regularity results for weak solutions to elliptic equations of divergence form. In order to explain ideas clearly we will discuss the equations with the following form only:

$$
-D_j(a_{ij}(x)D_i u) + c(x)u = f(x).
$$

We assume that $\Omega$ is a domain in $\mathbb{R}^n$. The function $u \in H^1(\Omega)$ is a *weak solution* if it satisfies

$$
\int_{\Omega} (a_{ij} D_i u D_j \varphi + c u \varphi) = \int_{\Omega} f \varphi \quad \text{for any } \varphi \in H_0^1(\Omega),
$$

where we assume

(i) the leading coefficients $a_{ij} \in L^\infty(\Omega)$ are *uniformly elliptic*, that is, for some positive constant $\lambda$ there holds

$$
a_{ij}(x)\xi_i \xi_j \geq \lambda|\xi|^2 \quad \text{for any } x \in \Omega \text{ and } \xi \in \mathbb{R}^n,
$$

(ii) the coefficient $c \in L^{n/2}(\Omega)$ and nonhomogeneous term $f \in L^{\frac{2n}{n+2}}(\Omega)$.

Note by the Sobolev embedding theorem (ii) is the least assumption on $c$ and $f$ to have a meaningful equation.

We will prove various interior regularity results concerning the solution $u$ if we have better assumptions on coefficients $a_{ij}$ and $c$ and the nonhomogeneous term $f$. Basically there are two class of regularity results, perturbation results and nonperturbation results. The first is based on the regularity assumption on the leading coefficients $a_{ij}$, which are assumed to be at least continuous. Under such an assumption we may compare solutions to the underlying equations with harmonic functions, or solutions to constant-coefficient equations. Then the regularity of solutions depends on how close they are to harmonic functions or how close the leading coefficients $a_{ij}$ are to constant coefficients. In this direction we have Schauder estimates and $W^{2,p}$-estimates. In this chapter we only discuss the Schauder estimates.

For the second kind of regularity result, there is no continuity assumption on the leading coefficients $a_{ij}$. Hence the result is not based on the perturbation. The iteration methods introduced by De Giorgi and Moser are successful in dealing with nonperturbation situations. The results proved by them are fundamental to