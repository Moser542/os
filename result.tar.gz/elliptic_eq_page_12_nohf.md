Then we have

$$
\begin{align*}
& \frac{d}{dr} \left( \frac{1}{\omega_n r^{n-1}} \int_{\partial B_r(x)} u(y) dS_y \right) \\
&= \frac{n}{\omega_n} \frac{d}{dr} \left( \frac{1}{r^n} \int_{B_r(x)} u(y) dy \right) \\
&= \frac{n}{\omega_n} \left\{ -\frac{n}{r^{n+1}} \int_{B_r(x)} u(y) dy + \frac{1}{r^n} \int_{\partial B_r(x)} u(y) dS_y \right\} = 0.
\end{align*}
$$

This implies

$$
\frac{1}{\omega_n r^{n-1}} \int_{\partial B_r(x)} u(y) dS_y = \text{const.}
$$

This constant is $u(x)$ if we let $r \to 0$. Hence we have

$$
u(x) = \frac{1}{\omega_n r^{n-1}} \int_{\partial B_r(x)} u(y) dS_y \quad \text{for any } B_r(x) \subset \Omega.
$$

Next we prove (1.2) for $n \ge 3$. For simplicity we assume that $x = 0$. Set

$$
\varphi(y, r) = \begin{cases} (|y|^2 - r^2)^n, & |y| \le r, \\ 0, & |y| > r, \end{cases}
$$

and then $\varphi_k(y, r) = (|y|^2 - r^2)^{n-k}(2(n-k+1)|y|^2 + n(|y|^2 - r^2))$ for $|y| \le r$ and $k = 2, 3, \dots, n$. Direct calculation shows $\varphi(\cdot, r) \in C_0^2(\Omega)$ and

$$
\Delta_y \varphi(y, r) = \begin{cases} 2n\varphi_2(y, r), & |y| \le r, \\ 0, & |y| > r. \end{cases}
$$

By assumption (1.1) we have

$$
\int_{B_r(0)} u(y) \varphi_2(y, r) dy = 0.
$$

Now we prove if for some $k = 2, 3, \dots, n-1$,

$$
(1.3) \qquad \int_{B_r(0)} u(y) \varphi_k(y, r) dy = 0,
$$

then

$$
(1.4) \qquad \int_{B_r(0)} u(y) \varphi_{k+1}(y, r) dy = 0.
$$

In fact, we differentiate (1.3) with respect to $r$ and get

$$
\int_{\partial B_r(0)} u(y) \varphi_k(y, r) dy + \int_{B_r(0)} u(y) \frac{\partial \varphi_k}{\partial r}(y, r) dy = 0.
$$