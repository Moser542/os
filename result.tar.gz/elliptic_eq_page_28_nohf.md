Then $v$ is harmonic in $\{y : \sum_{i=1}^n \lambda_i y_i^2 < 1\}$. In the ball $\{y : |y - y_0| < r_0\}$ use the interior estimates to yield

$$
|v(y_0)|^2 + |Dv(y_0)|^2 \le c(\lambda, \Lambda) \int_{B_{r_0}(y_0)} v^2 \le c(\lambda, \Lambda) \int_{\{\sum_{i=1}^n \lambda_i y_i^2 < 1\}} v^2.
$$

Transform back to $u$ to get

$$
|u(x_0)|^2 + |Du(x_0)|^2 \le c(\lambda, \Lambda) \int_{|x|<1} u^2.
$$

METHOD 2. If $u$ is a solution to (1.8), so are any derivatives of $u$. By applying Corollary 1.37 to derivatives of $u$ we conclude that for any positive integer $k$

$$
\|u\|_{H^k(B_{1/2})} \le c(k, \lambda, \Lambda) \|u\|_{L^2(B_1)}.
$$

If we fix a value of $k$ sufficiently large with respect to $n$, $H^k(B_{1/2})$ is continuously embedded into $C^1(\bar{B}_{1/2})$ and therefore

$$
|u|_{L^\infty(B_{1/2})} + |Du|_{L^\infty(B_{1/2})} \le c(\lambda, \Lambda) \|u\|_{L^2(B_1)}.
$$

This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAhCAIAAABFi1ywAAAAeUlEQVR4nO3WoQ0AIQxAUXohYRc8Y7EDgmHYByZgBFxVTxyHIKcoiEv6FZiXogoQkdrdtV0U9D+oHqfWmvceETkcAFhrFb2VUtgj9ubnxxiJUQjhAz0yqaCCCiqooIIupKd7SinnvMz1lTwWYa3VGMMZ8Mk5Byf+pzewQ2tFFGqd0gAAAABJRU5ErkJggg==)