for some $c_1 > 0$ to be determined, depending only on $n, \lambda, \Lambda$, and $\varepsilon_0$. Then there holds

$$
|A| \le \varepsilon_0 |B|.
$$

The proof is identical to that of Lemma 5.15.

Step 3. We finish the proof of Lemma 5.24. We take $\varepsilon_0$ such that

$$
\varepsilon_0 M^p = \frac{1}{2}
$$

where $M$, depending only on $n, \lambda$, and $\Lambda$, is as in Step 1. Hence the constants $\varepsilon$ and $c_1$ depend only on $n, \lambda, \Lambda$, and $p$. Define for $k = 0, 1, \dots$,

$$
\begin{aligned} \alpha_k &= |A_{M^k}(u, B_{8\sqrt{n}}) \cap Q_1|, \\ \beta_k &= |\{x \in Q_1 : m(f^n)(x) \ge (c_1 M^k)^n\}|. \end{aligned}
$$

Then Step 2 implies $\alpha_{k+1} \le \varepsilon_0(\alpha_k + \beta_k)$ for any $k = 0, 1, \dots$. Hence by iteration we have

$$
\alpha_k \le \varepsilon_0^k + \sum_{i=1}^{k-1} \varepsilon_0^{k-i} \beta_i.
$$

Since $f^n \in L^{p/n}$ and the maximal operator is of strong type $(p, p)$, we conclude that $m(f^n) \in L^{p/n}$ and

$$
\|m(f^n)\|_{L^{p/n}} \le C \|f\|_{L^p}^n \le C.
$$

Then the definition of $\beta_k$ implies

$$
\sum_{k \ge 0} M^{pk} \beta_k \le C.
$$

As before we set

$$
\theta(x) = \theta(u, B_{1/2})(x) = \inf\{M : x \in G_M(u, B_{1/2})\} \in [0, \infty] \quad \text{for } x \in B_{1/2}
$$

and

$$
\mu_{\theta}(t) = |\{x \in B_{1/2} : \theta(x) > t\}| \quad \text{for any } t > 0.
$$

The proof will be finished if we show

$$
\|\theta\|_{L^p(B_{1/2})} \le C.
$$

It is clear that

$$
\mu_{\theta}(t) \le |A_t(u, B_{1/2})| \le |A_t(u, B_{8\sqrt{n}}) \cap Q_1| \quad \text{for any } t > 0.
$$

It suffices to prove, with the definition of $\alpha_k$, that

$$
\sum_{k \ge 1} M^{pk} \alpha_k \le C.
$$