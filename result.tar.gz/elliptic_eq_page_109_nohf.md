We may apply Theorem 5.8 to $w$ in $B_{2\sqrt{n}}$. Note $\inf_{Q_3} w \le -1$ and $w \ge 0$ on $\partial B_{2\sqrt{n}}$ by (5.3) and (5.4). We obtain

$$
\begin{aligned}
1 \le C \left( \int_{B_{2\sqrt{n}} \cap \{w=\Gamma_w\}} (|f| + \eta)^n \right)^{\frac{1}{n}} \\
\le C \|f\|_{L^n(B_{2\sqrt{n}})} + C |\{w = \Gamma_w\} \cap Q_1|^{\frac{1}{n}}.
\end{aligned}
$$

Choosing $\varepsilon_0$ small enough we get

$$
\frac{1}{2} \le C |\{w = \Gamma_w\} \cap Q_1|^{\frac{1}{n}} \le C |\{u \le M\} \cap Q_1|^{\frac{1}{n}}
$$

since $w(x) = \Gamma_w(x)$ implies $w(x) \le 0$ and hence $u(x) \le -g(x) \le M$. This finishes the proof. $\square$

Next we prove the power decay of distribution functions.

LEMMA 5.14 Let $u$ belong to $S^+(\lambda, \Lambda, f)$ in $B_{2\sqrt{n}}$ for some $f \in C(B_{2\sqrt{n}})$. Then there exist positive constants $\varepsilon_0, \varepsilon$, and $C$, depending only on $n, \lambda$, and $\Lambda$, such that if

$$
(5.6) \qquad u \ge 0 \text{ in } B_{2\sqrt{n}}, \quad \inf_{Q_3} \inf u \le 1, \quad \|f\|_{L^n(B_{2\sqrt{n}})} \le \varepsilon_0,
$$

there holds

$$
|\{u \ge t\} \cap Q_1| \le Ct^{-\varepsilon} \quad \text{for } t > 0.
$$

PROOF: We will prove that under assumption (5.6) there holds

$$
(5.7) \qquad |\{u > M^k\} \cap Q_1| \le (1 - \mu)^k \quad \text{for } k = 1, 2, \dots,
$$

where $M$ and $\mu$ are as in Lemma 5.13.

For $k = 1$, (5.7) is just Lemma 5.13. Suppose now (5.7) holds for $k - 1$. Set

$$
A = \{u > M^k\} \cap Q_1, \quad B = \{u > M^{k-1}\} \cap Q_1.
$$

We will use Lemma 5.9 to prove that

$$
(5.8) \qquad |A| \le (1 - \mu)|B|.
$$

Clearly $A \subset B \subset Q_1$ and $|A| \le |\{u > M\} \cap Q_1| \le 1 - \mu$ by Lemma 5.13. We claim that if $Q = Q_r(x_0)$ is a cube in $Q_1$ such that

$$
(5.9) \qquad |A \cap Q| > (1 - \mu)|Q|
$$

then $\tilde{Q} \cap Q_1 \subset B$ for $\tilde{Q} = Q_{3r}(x_0)$.

We prove it by contradiction. Suppose not. We may take $\tilde{x} \in \tilde{Q}$ such that $u(\tilde{x}) \le M^{k-1}$. Consider the transformation

$$
x = x_0 + ry \quad \text{for } y \in Q_1 \text{ and } x \in Q = Q_r(x_0)
$$

and the function

$$
\tilde{u}(y) = \frac{1}{M^{k-1}} u(x).
$$