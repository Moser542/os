PROOF: Suppose $u$ is a solution to the following homogeneous equation:

$$
\begin{aligned}
Lu &= 0 && \text{in } \Omega, \\
\frac{\partial u}{\partial n} + \alpha(x)u &= 0 && \text{on } \partial\Omega.
\end{aligned}
$$

CASE 1. $c \neq 0$ or $\alpha \neq 0$. We want to show $u \equiv 0$.

Suppose that $u$ has a positive maximum at $x_0 \in \bar{\Omega}$. If $u \equiv \text{const} > 0$, this contradicts the condition $c \neq 0$ in $\Omega$ or $\alpha \neq 0$ on $\partial\Omega$. Otherwise $x_0 \in \partial\Omega$ and $\frac{\partial u}{\partial n}(x_0) > 0$ by Corollary 2.9, which contradicts the boundary value. Therefore $u \equiv 0$.

CASE 2. $c \equiv 0$ and $\alpha \equiv 0$. We want to show $u \equiv \text{const}$.

Suppose $u$ is a nonconstant solution. Then its maximum in $\bar{\Omega}$ is assumed only on $\partial\Omega$ by Theorem 2.7, say at $x_0 \in \partial\Omega$. Again Corollary 2.9 implies $\frac{\partial u}{\partial n}(x_0) > 0$. This is a contradiction. $\square$

The following theorem, due to Serrin, generalizes the comparison principle with no restriction on $c(x)$.

THEOREM 2.10 Suppose $u \in C^2(\Omega) \cap C(\bar{\Omega})$ satisfies $Lu \ge 0$. If $u \le 0$ in $\Omega$, then either $u < 0$ in $\Omega$ or $u \equiv 0$ in $\Omega$.

PROOF: We present two methods.

METHOD 1. Suppose $u(x_0) = 0$ for some $x_0 \in \Omega$. We will prove that $u \equiv 0$ in $\Omega$.

Write $c(x) = c^+(x) - c^-(x)$ where $c^+(x)$ and $c^-(x)$ are the positive part and negative part of $c(x)$, respectively. Hence $u$ satisfies

$$
a_{ij} D_{ij} u + b_i D_i u - c^- u \ge -c^+ u \ge 0.
$$

So we have $u \equiv 0$ by Theorem 2.7.

METHOD 2. Set $v = ue^{-\alpha x_1}$ for some $\alpha > 0$ to be determined. By $Lu \ge 0$, we have

$$
a_{ij} D_{ij} v + [\alpha(a_{1i} + a_{i1}) + b_i] D_i v + (a_{11}\alpha^2 + b_1\alpha + c)v \ge 0.
$$

Choose $\alpha$ large enough such that $a_{11}\alpha^2 + b_1\alpha + c > 0$. Therefore $v$ satisfies

$$
a_{ij} D_{ij} v + [\alpha(a_{1i} + a_{i1}) + b_i] D_i v \ge 0.
$$

Hence we apply Theorem 2.7 to $v$ to conclude that either $v < 0$ in $\Omega$ or $v \equiv 0$ in $\Omega$. $\square$

The next result is the general maximum principle for the operator $L$ with no restriction on $c(x)$.

THEOREM 2.11 Suppose there exists a $w \in C^2(\Omega) \cap C^1(\bar{\Omega})$ satisfying $w > 0$ in $\bar{\Omega}$ and $Lw \le 0$ in $\Omega$. If $u \in C^2(\Omega) \cap C(\bar{\Omega})$ satisfies $Lu \ge 0$ in $\Omega$, then $\frac{u}{w}$ cannot assume in $\Omega$ its nonnegative maximum unless $\frac{u}{w} \equiv \text{const}$. If, in addition,