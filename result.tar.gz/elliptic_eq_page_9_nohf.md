where in the last equality we used the mean value property. Hence we get

$$
u(x) = (\varphi_{\varepsilon} * u)(x) \quad \text{for any } x \in \Omega_{\varepsilon} = \{y \in \Omega; d(y, \partial\Omega) > \varepsilon\}.
$$

Therefore $u$ is smooth. Moreover, by formula (*) in the proof of Theorem 1.2 and the mean value property we have

$$
\begin{aligned} \int_{B_r(x)} \Delta u &= r^{n-1} \frac{\partial}{\partial r} \int_{|w|=1} u(x + rw) dS_w \\ &= r^{n-1} \frac{\partial}{\partial r} (\omega_n u(x)) = 0 \quad \text{for any } B_r(x) \subset \Omega. \end{aligned}
$$

This implies $\Delta u = 0$ in $\Omega$.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAhCAIAAABBfoyNAAAAh0lEQVR4nO3WMQqDIQwF4Je2CuLsqRwdxFt5DI8ogrwOXX7XWgs/5B3gS0iGREjiTB6HXKX/SoOX1FqNMc+9WGtzziQXupTyk3a99ySXgYwxALTWuBEAvXfcdY1KK6200korfY5eLnpKCYCI7DwLAJxzJF/XMiGET7E559e9ikiMEYDc8gl+AyHuhD3l0aHqAAAAAElFTkSuQmCC)

REMARK 1.9. By combining Theorem 1.6 and Theorem 1.8, we conclude that harmonic functions are smooth and satisfy the mean value property. Hence harmonic functions satisfy the maximum principle, a consequence of which is the uniqueness of solution to the following Dirichlet problem in a bounded domain

$$
\begin{aligned} \Delta u &= f \quad \text{in } \Omega, \\ u &= \varphi \quad \text{on } \partial\Omega, \end{aligned}
$$

for $f \in C(\Omega)$ and $\varphi \in C(\partial\Omega)$. In general uniqueness does not hold for an unbounded domain. Consider the following Dirichlet problem in the unbounded domain $\Omega$

$$
\begin{aligned} \Delta u &= 0 \quad \text{in } \Omega, \\ u &= 0 \quad \text{on } \partial\Omega. \end{aligned}
$$

First consider the case $\Omega = \{x \in \mathbb{R}^n; |x| > 1\}$. For $n = 2$, $u(x) = \log|x|$ is a solution. Note $u \to \infty$ as $r \to \infty$. For $n \ge 3$, $u(x) = |x|^{2-n} - 1$ is a solution. Note $u \to -1$ as $r \to \infty$. Hence $u$ is bounded. Next, consider the upper half space $\Omega = \{x \in \mathbb{R}^n; x_n > 0\}$. Then $u(x) = x_n$ is a nontrivial solution, which is unbounded.

In the following we discuss the gradient estimates.

LEMMA 1.10 Suppose $u \in C(\bar{B}_R)$ is harmonic in $B_R = B_R(x_0)$. Then there holds

$$
|Du(x_0)| \le \frac{n}{R} \max_{\bar{B}_R} |u|.
$$

PROOF: For simplicity we assume $u \in C^1(\bar{B}_R)$. Since $u$ is smooth, then $\Delta(D_{x_i}u) = 0$, that is, $D_{x_i}u$ is also harmonic in $B_R$. Hence $D_{x_i}u$ satisfies the mean value property. By the divergence theorem we have

$$
D_{x_i} u(x_0) = \frac{n}{\omega_n R^n} \int_{B_R(x_0)} D_{x_i} u(y) dy = \frac{n}{\omega_n R^n} \int_{\partial B_R(x_0)} u(y) v_i dS_y,
$$

which implies

$$
|D_{x_i} u(x_0)| \le \frac{n}{\omega_n R^n} \max_{\partial B_R} |u| \cdot \omega_n R^{n-1} \le \frac{n}{R} \max_{\bar{B}_R} |u|.
$$