For some $k > 0$ and $m > 0$, set $\bar{u} = u^+ + k$ and

$$
\bar{u}_m = \begin{cases} \bar{u} & \text{if } u < m, \\ k + m & \text{if } u \ge m. \end{cases}
$$

Then we have $D\bar{u}_m = 0$ in $\{u < 0\}$ and $\{u > m\}$ and $\bar{u}_m \le \bar{u}$. Set the test function

$$
\varphi = \eta^2 (\bar{u}_m^\beta \bar{u} - k^{\beta+1}) \in H_0^1(B_1)
$$

for some $\beta \ge 0$ and some nonnegative function $\eta \in C_0^1(B_1)$. Direct calculation yields

$$
\begin{aligned} D\varphi &= \beta\eta^2\bar{u}_m^{\beta-1}D\bar{u}_m\bar{u} + \eta^2\bar{u}_m^\beta D\bar{u} + 2\eta D\eta(\bar{u}_m^\beta\bar{u} - k^{\beta+1}) \\ &= \eta^2\bar{u}_m^\beta(\beta D\bar{u}_m + D\bar{u}) + 2\eta D\eta(\bar{u}_m^\beta\bar{u} - k^{\beta+1}). \end{aligned}
$$

We should emphasize that later on we will begin the iteration with $\beta = 0$. Note $\varphi = 0$ and $D\varphi = 0$ in $\{u \le 0\}$. Hence if we substitute such $\varphi$ in the equation we integrate in the set $\{u > 0\}$. Note also that $u^+ \le \bar{u}$ and $\bar{u}_m^\beta \bar{u} - k^{\beta+1} \le \bar{u}_m^\beta \bar{u}$ for $k > 0$.

First we have by the Hölder inequality

$$
\begin{aligned} \int a_{ij} D_i u D_j \varphi &= \int a_{ij} D_i \bar{u} (\beta D_j \bar{u}_m + D_j \bar{u}) \eta^2 \bar{u}_m^\beta + 2 \int a_{ij} D_i \bar{u} D_j \eta (\bar{u}_m^\beta \bar{u} - k^{\beta+1}) \eta \\ &\ge \lambda\beta \int \eta^2 \bar{u}_m^\beta |D\bar{u}_m|^2 + \lambda \int \eta^2 \bar{u}_m^\beta |D\bar{u}|^2 - \Lambda \int |D\bar{u}| |D\eta| \bar{u}_m^\beta \bar{u} \eta \\ &\ge \lambda\beta \int \eta^2 \bar{u}_m^\beta |D\bar{u}_m|^2 + \frac{\lambda}{2} \int \eta^2 \bar{u}_m^\beta |D\bar{u}|^2 - \frac{2\Lambda^2}{\lambda} \int |D\eta|^2 \bar{u}_m^\beta \bar{u}^2. \end{aligned}
$$

Hence we obtain by noting $\bar{u} \ge k$

$$
\begin{aligned} & \beta \int \eta^2 \bar{u}_m^\beta |D\bar{u}_m|^2 + \int \eta^2 \bar{u}_m^\beta |D\bar{u}|^2 \\ & \le C \left\{ \int |D\eta|^2 \bar{u}_m^\beta \bar{u}^2 + \int (|c|\eta^2 \bar{u}_m^\beta \bar{u}^2 + |f|\eta^2 \bar{u}_m^\beta \bar{u}) \right\} \\ & \le C \left\{ \int |D\eta|^2 \bar{u}_m^\beta \bar{u}^2 + \int c_0 \eta^2 \bar{u}_m^\beta \bar{u}^2 \right\}, \end{aligned}
$$

where $c_0$ is defined as

$$
c_0 = |c| + \frac{|f|}{k}.
$$

Choose $k = \|f\|_{L^q}$ if $f$ is not identically 0. Otherwise choose arbitrary $k > 0$ and eventually let $k \to 0^+$. By assumption we have

$$
\|c_0\|_{L^q} \le \Lambda + 1.
$$

Set $w = \bar{u}_m^{\beta/2} \bar{u}$. Note

$$
|Dw|^2 \le (1 + \beta) \{ \beta \bar{u}_m^\beta |D\bar{u}_m|^2 + \bar{u}_m^\beta |D\bar{u}|^2 \}.
$$