Lemma 1.35 follows easily from (1.7). For any $x, y \in B_1$, set $d_x = \text{dist}(x, \partial B_1)$ and $d_y = \text{dist}(y, \partial B_1)$. Suppose $d_y \le d_x$. Take $x_0, y_0 \in \partial B_1$ such that $|x - x_0| = d_x$ and $|y - y_0| = d_y$. Assume first that $|x - y| \le d_x/2$. Then $y \in \bar{B}_{d_x/2}(x) \subset B_{d_x}(x) \subset B_1$. We apply Proposition 1.31 (scaled version) to $u - u(x_0)$ in $B_{d_x}(x)$ and get by (1.7)

$$
d_x^{\alpha/2} \frac{|u(x) - u(y)|}{|x - y|^{\alpha/2}} \le C |u - u(x_0)|_{L^{\infty}(B_{d_x}(x))} \le C d_x^{\alpha/2} \|\varphi\|_{C^{\alpha}(\partial B_1)}.
$$

Hence we obtain

$$
|u(x) - u(y)| \le C |x - y|^{\alpha/2} \|\varphi\|_{C^{\alpha}(\partial B_1)}.
$$

Assume now that $d_y \le d_x \le 2|x - y|$. Then by (1.7) again we have

$$
\begin{aligned} |u(x) - u(y)| &\le |u(x) - u(x_0)| + |u(x_0) - u(y_0)| + |u(y_0) - u(y)| \\ &\le C(d_x^{\alpha/2} + |x_0 - y_0|^{\alpha/2} + d_y^{\alpha/2}) \|\varphi\|_{C^{\alpha}(\partial B_1)} \\ &\le C|x - y|^{\alpha/2} \|\varphi\|_{C^{\alpha}(\partial B_1)} \end{aligned}
$$

since $|x_0 - y_0| \le d_x + |x - y| + d_y \le 5|x - y|$.

In order to prove (1.7) we assume $B_1 = B_1((1, 0, \dots, 0))$, $x_0 = 0$, and $\varphi(0) = 0$. Define $K = \sup_{x \in \partial B_1} |\varphi(x)|/|x|^\alpha$. Note $|x|^2 = 2x_1$ for $x \in \partial B_1$. Therefore for $x \in \partial B_1$ there holds

$$
\varphi(x) \le K|x|^\alpha \le 2^{\alpha/2} K x_1^{\alpha/2}.
$$

Define $v(x) = 2^{\alpha/2} K x_1^{\alpha/2}$ in $B_1$. Then we have

$$
\Delta v(x) = 2^{\alpha/2} K \cdot \frac{\alpha}{2} \left( \frac{\alpha}{2} - 1 \right) x_1^{\alpha/2 - 2} < 0 \quad \text{in } B_1.
$$

Theorem 3.1 implies

$$
u(x) \le v(x) = 2^{\alpha/2} K x_1^{\alpha/2} \le 2^{\alpha/2} K |x|^{\alpha/2} \quad \text{for any } x \in B_1.
$$

Considering $-u$ similarly, we get

$$
|u(x)| \le 2^{\alpha/2} K |x|^{\alpha/2} \quad \text{for any } x \in B_1.
$$

This proves (1.7).

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAAjCAIAAADjdEa4AAAAkklEQVR4nO3XMQrFIAwG4PTRwUt4D4/l4AEcPIz30cnZUbyAwv+GLoV2qgReefm3IHyEgJBsAIgtHz5adNEfZD8XtVbn3DpqjLHWEhHhlJzzOn2k9w7gZjIhBCzEe09ErTXim/sYg1GfczLqb+5ddNF/S5ffJPr/6fv1IcaYUnrsHouFUoqIZ+PQWpdSAGwvvg6+woi4aN+UAZ4AAAAASUVORK5CYII=)

1.5. Energy Method

In this section we discuss harmonic functions by using the energy method. In general we assume throughout this section that $a_{ij} \in C(B_1)$ satisfies

$$
\lambda |\xi|^2 \le a_{ij}(x) \xi_i \xi_j \le \Lambda |\xi|^2 \quad \text{for any } x \in B_1 \text{ and } \xi \in \mathbb{R}^n
$$

for some positive constants $\lambda$ and $\Lambda$. We consider the function $u \in C^1(B_1)$ satisfying

$$
\int_{B_1} a_{ij} D_i u D_j \varphi = 0 \quad \text{for any } \varphi \in C_0^1(B_1).
$$