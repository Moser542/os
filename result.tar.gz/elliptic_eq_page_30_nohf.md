REMARK 2.2. If $c(x) \equiv 0$, then the requirement for nonnegativeness can be removed. This remark also holds for some results in the rest of this section.

THEOREM 2.3 (Weak Maximum Principle) Suppose $u \in C^2(\Omega) \cap C(\bar{\Omega})$ satisfies $Lu \ge 0$ in $\Omega$ with $c(x) \le 0$ in $\Omega$. Then $u$ attains on $\partial\Omega$ its nonnegative maximum in $\bar{\Omega}$.

PROOF: For any $\varepsilon > 0$, consider $w(x) = u(x) + \varepsilon e^{\alpha x_1}$ with $\alpha$ to be determined. Then we have

$$
Lw = Lu + \varepsilon e^{\alpha x_1} (a_{11}\alpha^2 + b_1\alpha + c).
$$

Since $b_1$ and $c$ are bounded and $a_{11}(x) \ge \lambda > 0$ for any $x \in \Omega$, by choosing $\alpha > 0$ large enough we get

$$
a_{11}(x)\alpha^2 + b_1(x)\alpha + c(x) > 0 \quad \text{for any } x \in \Omega.
$$

This implies $Lw > 0$ in $\Omega$. By Lemma 2.1, $w$ attains its nonnegative maximum only on $\partial\Omega$, that is,

$$
\sup_{\Omega} w \le \sup_{\partial\Omega} w^+.
$$

Then we obtain

$$
\sup_{\Omega} u \le \sup_{\Omega} w \le \sup_{\partial\Omega} w^+ \le \sup_{\partial\Omega} u^+ + \varepsilon \sup_{x \in \partial\Omega} e^{\alpha x_1}.
$$

We finish the proof by letting $\varepsilon \to 0$. $\square$

As an application we have the uniqueness of solution $u \in C^2(\Omega) \cap C(\bar{\Omega})$ to the following Dirichlet boundary value problem for $f \in C(\Omega)$ and $\varphi \in C(\partial\Omega)$

$$
\begin{aligned} Lu &= f \quad \text{in } \Omega, \\ u &= \varphi \quad \text{on } \partial\Omega, \end{aligned}
$$

if $c(x) \le 0$ in $\Omega$.

REMARK 2.4. The boundedness of domain $\Omega$ is essential, since it guarantees the existence of a maximum and a minimum of $u$ in $\bar{\Omega}$. The uniqueness does not hold if the domain is unbounded. Some examples are given in Remark 1.9. Equally important is the nonpositiveness of the coefficient $c$.

EXAMPLE. Set $\Omega = \{(x, y) \in \mathbb{R}^2 : 0 < x < \pi, 0 < y < \pi\}$. Then $u = \sin x \sin y$ is a nontrivial solution for the problem

$$
\begin{aligned} \Delta u + 2u &= 0 \quad \text{in } \Omega, \\ u &= 0 \quad \text{on } \partial\Omega. \end{aligned}
$$

THEOREM 2.5 (Hopf Lemma) Let $B$ be an open ball in $\mathbb{R}^n$ with $x_0 \in \partial B$. Suppose $u \in C^2(B) \cap C(B \cup \{x_0\})$ satisfies $Lu \ge 0$ in $B$ with $c(x) \le 0$ in $B$. Assume in addition that

$$
u(x) < u(x_0) \quad \text{for any } x \in B \text{ and } u(x_0) \ge 0.
$$