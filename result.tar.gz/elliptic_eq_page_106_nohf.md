We end this section with a simple consequence of Calderon-Zygmund decomposition. We first recall some terminology. Let $Q_1$ be the unit cube. Cut it equally into $2^n$ cubes, which we take as the first generation. Do the same cutting for these small cubes to get the second generation. Continue this process. These cubes (from all generations) are called *dyadic cubes*. Any $(k+1)$-generation cube $Q$ comes from some $k$-generation cube $\tilde{Q}$, which is called the *predecessor* of $Q$.

LEMMA 5.9 Suppose measurable sets $A \subset B \subset Q_1$ have the following properties:

(i) $|A| < \delta$ for some $\delta \in (0, 1)$;
(ii) for any dyadic cube $Q$, $|A \cap Q| \ge \delta|Q|$ implies $\tilde{Q} \subset B$ for the predecessor $\tilde{Q}$ of $Q$.

Then there holds $|A| \le \delta|B|$.

PROOF: Apply Calderon-Zygmund decomposition (Lemma 3.7) to $f = \chi_A$. We obtain, by assumption (i), a sequence of dyadic cubes $\{Q^j\}$ such that

$$
A \subset \bigcup_j Q^j \quad \text{except for a set of measure 0,}
$$

$$
\delta \le \frac{|A \cap Q^j|}{|Q^j|} < 2^n \delta, \quad \frac{|A \cap \tilde{Q}^j|}{|\tilde{Q}^j|} < \delta,
$$

for any predecessor $\tilde{Q}^j$ of $Q^j$. By assumption (ii) we have $\tilde{Q}^j \subset B$ for each $j$. Hence we obtain

$$
A \subset \bigcup_j \tilde{Q}^j \subset B.
$$

We relabel $\{\tilde{Q}^j\}$ so that they are nonoverlapping. Therefore we get

$$
|A| \le \sum_i |A \cap \tilde{Q}^i| \le \delta \sum_i |\tilde{Q}^i| \le \delta|B|.
$$

□

5.3. Harnack Inequality

The main result in this section is the following Harnack inequality.

THEOREM 5.10 Suppose $u$ belongs to $\mathcal{S}(\lambda, \Lambda, f)$ in $B_1$ with $u \ge 0$ in $B_1$ for some $f \in C(B_1)$. Then there holds

$$
\sup_{B_{1/2}} u \le C \left\{ \inf_{B_{1/2}} u + \|f\|_{L^n(B_1)} \right\}
$$

where $C$ is a positive constant depending only on $n$, $\lambda$, and $\Lambda$.

The interior Hölder continuity of solutions is a direct consequence, whose proof is identical to that of Corollary 4.18.