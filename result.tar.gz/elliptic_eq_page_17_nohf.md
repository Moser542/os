For $n \ge 3$, we have

$$
\Gamma(x, y) = \frac{1}{(2-n)\omega_n} |x - y|^{2-n} < 0 \quad \text{for } y \in \partial\Omega,
$$

which implies $\Phi(x, \cdot) > 0$ on $\partial\Omega$. By the maximum principle, we have $\Phi > 0$ in $\Omega$. For $n = 2$ we have

$$
\Gamma(x, y) = \frac{1}{2\pi} \log |x - y| \le \frac{1}{2\pi} \log \operatorname{diam}(\Omega) \quad \text{for } y \in \partial\Omega.
$$

Hence the maximum principle implies $\Phi > -\frac{1}{2\pi} \log \operatorname{diam}(\Omega)$ in $\Omega$. $\square$

We may calculate the Green's functions for some special domains.

**PROPOSITION 1.22** *The Green's function for the ball $B_R(0)$ is given by*

$$
\text{(i)} \quad G(x, y) = \frac{1}{(2-n)\omega_n} \left( |x - y|^{2-n} - \left| \frac{R}{|x|}x - \frac{|x|}{R}y \right|^{2-n} \right) \quad \text{for } n \ge 3,
$$

$$
\text{(ii)} \quad G(x, y) = \frac{1}{2\pi} \left( \log |x - y| - \log \left| \frac{R}{|x|}x - \frac{|x|}{R}y \right| \right) \quad \text{for } n = 2.
$$

**PROOF:** Fix $x \ne 0$ with $|x| < R$. Consider $X \in \mathbb{R}^n \setminus \bar{B}_R$ with $X$ the multiple of $x$ and $|X| \cdot |x| = R^2$, that is, $X = \frac{R^2}{|x|^2}x$. In other words, $X$ and $x$ are reflexive with respect to the sphere $\partial B_R$. Note the map $x \mapsto X$ is conformal; that is, it preserves angles. If $|y| = R$, we have by similarity of triangles

$$
\frac{|x|}{R} = \frac{R}{|X|} = \frac{|y - x|}{|y - X|},
$$

which implies

$$
(1.5) \quad |y - x| = \frac{|x|}{R} |y - X| = \left| \frac{|x|}{R} y - \frac{R}{|x|} x \right| \quad \text{for any } y \in \partial B_R.
$$

Therefore, in order to have zero boundary value, we take for $n \ge 3$

$$
G(x, y) = \frac{1}{(2-n)\omega_n} \left( \frac{1}{|x - y|^{n-2}} - \left( \frac{R}{|x|} \right)^{n-2} \frac{1}{|y - X|^{n-2}} \right).
$$

The case $n = 2$ is similar. $\square$

Next, we calculate the normal derivative of Green's function on the sphere.

**COROLLARY 1.23** *Suppose $G$ is the Green's function in $B_R(0)$. Then there holds*

$$
\frac{\partial G}{\partial n}(x, y) = \frac{R^2 - |x|^2}{\omega_n R |x - y|^n} \quad \text{for any } x \in B_R \text{ and } y \in \partial B_R.
$$

**PROOF:** We just consider the case $n \ge 3$. Recall with $X = R^2 x / |x|^2$

$$
G(x, y) = \frac{1}{(2-n)\omega_n} \left( |x - y|^{2-n} - \left( \frac{R}{|x|} \right)^{n-2} |y - X|^{2-n} \right) \\ \text{for } x \in B_R, y \in \partial B_R.
$$