THEOREM 3.13 Let $u \in H^1(B_1)$ solve $(*)$. Assume $a_{ij} \in C^\alpha(\bar{B}_1)$, $c \in L^q(B_1)$ and $f \in L^q(B_1)$ for some $q > n$ and $\alpha = 1 - \frac{n}{q} \in (0, 1)$. Then $Du \in C^\alpha(B_1)$. Moreover, there exists an $R_0 = R_0(\lambda, |a_{ij}|_{C^\alpha}, |c|_{L^q})$ such that for any $x \in B_{1/2}$ and $r \le R_0$ there holds

$$
\int_{B_r(x)} |Du - (Du)_{x,r}|^2 \le C r^{n+2\alpha} \{\|f\|_{L^q(B_1)}^2 + \|u\|_{H^1(B_1)}^2\}
$$

where $C = C(\lambda, |a_{ij}|_{C^\alpha}, |c|_{L^q})$ is a positive constant.

PROOF: We shall decompose $u$ into a sum $v + w$ where $w$ satisfies a homogeneous equation and $v$ has estimates in terms of nonhomogeneous terms.

For any $B_r(x_0) \subset B_1$ write the equation in the following form:

$$
\int_{B_1} a_{ij}(x_0) D_i u D_j \varphi = \int_{B_1} f \varphi - c u \varphi + (a_{ij}(x_0) - a_{ij}(x)) D_i u D_j \varphi.
$$

In $B_r(x_0)$ the Dirichlet problem

$$
\int_{B_r(x_0)} a_{ij}(x_0) D_i w D_j \varphi = 0 \quad \text{for any } \varphi \in H_0^1(B_r(x_0))
$$

has a unique solution $w$ with $w - u \in H_0^1(B_r(x_0))$. Obviously the function $v = u - w \in H_0^1(B_r(x_0))$ satisfies the equation

$$
\int_{B_r(x_0)} a_{ij}(x_0) D_i v D_j \varphi = \int_{B_r(x_0)} f \varphi - c u \varphi + (a_{ij}(x_0) - a_{ij}(x)) D_i u D_j \varphi \\ \text{for any } \varphi \in H_0^1(B_r(x_0)).
$$

By taking the test function $\varphi = v$ we obtain

$$
\int_{B_r(x_0)} |Dv|^2 \le c \left\{ \tau^2(r) \int_{B_r(x_0)} |Du|^2 + \left( \int_{B_r(x_0)} |c|^n \right)^{\frac{2}{n}} \int_{B_r(x_0)} u^2 \right. \\ \left. + \left( \int_{B_r(x_0)} |f|^{\frac{2n}{n+2}} \right)^{\frac{n+2}{n}} \right\}.
$$

Therefore Corollary 3.11 implies for any $0 < \rho \le r$

$$
(3.12) \quad \int_{B_\rho(x_0)} |Du|^2 \le c \left\{ \left[ \left( \frac{\rho}{r} \right)^n + \tau^2(r) \right] \int_{B_r(x_0)} |Du|^2 \right. \\ \left. + \left( \int_{B_r(x_0)} |c|^n \right)^{\frac{2}{n}} \int_{B_r(x_0)} u^2 + \left( \int_{B_r(x_0)} |f|^{\frac{2n}{n+2}} \right)^{\frac{n+2}{n}} \right\}
$$