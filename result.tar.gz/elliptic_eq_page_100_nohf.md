Corollary 4.2 implies $u \in C^{\delta_0}$ for some $\delta_0 > 0$. Therefore we have by (4.18) and (4.20)

$$
\int_{B_{\rho}(x_0)} |Du|^2 \le C \left\{ \left[ \left(\frac{\rho}{r}\right)^n + r^{2\alpha} + r^{\delta_0} \right] \int_{B_r(x_0)} |Du|^2 + r^{n+2\alpha} \|f\|_{L^q}^2 \right\}.
$$

By Lemma 3.4 we obtain that for any $\delta < 1$ there holds for any $B_r(x_0) \subset B_{7/8}$

$$
\int_{B_r(x_0)} |Du|^2 \le C r^{n-2+2\delta} \left\{ \int_{B_{7/8}} |Du|^2 + \|f\|_{L^q(B_1)}^2 \right\}.
$$

This implies $u \in C_{\text{loc}}^{\delta}$ for any $\delta < 1$. Moreover, for any $B_r(x_0) \subset B_{3/4}$ there holds

$$
\operatorname{osc}_{B_r(x_0)} u \le C r^{\delta}
$$

where $C$ is some positive constant depending only on $n, \lambda, \Lambda, q, |u|_{L^\infty(B_1)}$, and $\|f\|_{L^q(B_1)}$, by Remark 4.22. With (4.20) we have for any $B_r(x_0) \subset B_{2/3}$

$$
\begin{aligned} \int_{B_r(x_0)} |Dv|^2 &\le C \left\{ (r^{2\alpha} + r^{\delta}) r^{n-2+2\delta} \int_{B_{7/8}} |Du|^2 + r^{n+2\alpha} \|f\|_{L^q}^2 \right\} \\ &\le C r^{n+2\alpha'} \end{aligned}
$$

for some $\alpha' < \alpha$ if $\delta \in (0, 1)$ is chosen such that $3\delta > 2$ and $\alpha + \delta > 1$. Hence with (4.19) we obtain for any $B_r(x_0) \subset B_{2/3}$ and any $0 < \rho \le r$

$$
\int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le C \left\{ \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + r^{n+2\alpha'} \right\}.
$$

By Lemma 3.4 and Theorem 3.1 we again conclude that $Du \in C_{\text{loc}}^{\alpha'}$ for some $\alpha' < \alpha$, in particular $Du \in L_{\text{loc}}^{\infty}$. This finishes the proof. $\square$