In order to prove (5.1) we take $h(x) = -\varepsilon|x|^2/2$ in $B_1$. Obviously $u - h$ has a minimum at 0. Note that the eigenvalues of $D^2h(0)$ are $-\varepsilon, \dots, -\varepsilon$. By definition of $S^+(\lambda, \Lambda, f)$ we have

$$
-n\Lambda\varepsilon \le f(0).
$$

By letting $\varepsilon \to 0$ we get (5.1).

For estimate (5.2) we will prove

$$
0 \le \Gamma_u(x) \le C(n, \lambda, \Lambda)\{f(0) + \varepsilon(x)\}|x|^2 \quad \text{for } x \in B_1
$$

where $\varepsilon(x) \to 0$ as $x \to 0$. By setting $w = \Gamma_u$ we need to estimate for any small $r > 0$

$$
C_r = \frac{1}{r^2} \max_{B_r} w.
$$

Fix $r > 0$. By convexity $w$ attains its maximum in $\bar{B}_r$ at some point on the boundary, say, $(0, \dots, 0, r)$. The set $\{x \in B_1 : w(x) \le w(0, \dots, 0, r)\}$ is convex and contains $B_r$. It follows easily that

$$
w(x', r) \ge w(0, \dots, 0, r) = C_r r^2 \quad \text{for any } x = (x', r) \in B_1.
$$

Take a positive number $N$ to be determined. Set

$$
R_r = \{(x', x_n) : |x'| \le Nr, |x_n| \le r\}.
$$

We will construct a quadratic polynomial that touches $u$ from below in $R_r$ and curves upward very much. Set for some $b > 0$

$$
h(x) = (x_n + r)^2 - b|x'|^2.
$$

Then we have

(i) for $x_n = -r, h \le 0$;

(ii) for $|x'| = Nr, h \le (4 - bN^2)r^2 \le 0$ if we take $b = 4/N^2$;

(iii) for $x_n = r, h = 4r^2 - b|x'|^2 \le 4r^2$.

Hence if we set

$$
\tilde{h}(x) = \frac{C_r}{4} h(x) = \frac{C_r}{4} \left\{ (x_n + r)^2 - \frac{4}{N^2} |x'|^2 \right\}
$$

we obtain $\tilde{h} \le w \le u$ on $\partial R_r$ (since $w$ is the convex envelope of $u$) and $\tilde{h}(0) = C_r r^2/4 > 0 = w(0) = u(0)$. By lowering $\tilde{h}$ appropriately we conclude that $u - \tilde{h}$ has a local minimum somewhere inside $R_r$. Note the eigenvalues of $D^2\tilde{h}$ are given by $C_r/2, -2C_r/N^2, \dots, -2C_r/N^2$. Hence by definition of $S^+(\lambda, \Lambda, f)$ we have

$$
\lambda \frac{C_r}{2} - 2\Lambda(n-1) \frac{C_r}{N^2} \le \max_{R_r} f.
$$

By choosing $N$ large, depending only on $n, \lambda$, and $\Lambda$, we obtain

$$
C_r \le \frac{4}{\lambda} \max_{R_r} f \quad \text{or} \quad \max_{B_r} w \le \frac{4}{\lambda} r^2 \max_{R_r} f.
$$

Note $\max_{R_r} f \to f(0)$ as $r \to 0$. This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAeCAIAAACwp+nIAAAAaElEQVR4nO3VsRHAIAgF0E+izuo4sgWdaziTnoetuZTY5MIvKR5wFJCq4nSu46Kj0C3MHGO8bUkphb1Ba22MYZxyzvlYv/cOQETUEHzpUI466qijjv4NDe9SKaXWalL3R5hzNlkAACJaLWJrlCyylNoAAAAASUVORK5CYII=)