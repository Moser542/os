Obviously $\tilde{u} \ge 0$ in $B_{2\sqrt{n}}$ and $\tilde{u}(0) = 1$, hence $\inf_{Q_3} \tilde{u} \le 1$. It is easy to check that $\tilde{u} \in S^+(\lambda, \Lambda, \tilde{f})$ in $B_{2\sqrt{n}}$ with $\|\tilde{f}\|_{L^n(B_{2\sqrt{n}})} \le \varepsilon_0$. In fact, we have

$$
\tilde{f}(y) = -\frac{r^2}{(\theta-1)P} f(x) \quad \text{for } y \in B_{2\sqrt{n}}
$$

and hence

$$
\|\tilde{f}\|_{L^n(B_{2\sqrt{n}})} \le \frac{r}{(\theta-1)P} \|f\|_{L^n(B_{2\sqrt{n}r}(x_0))} \le \varepsilon_0
$$

if we choose $P$ such that $r \le (\theta - 1)P$. Hence we may apply Lemma 5.13 to $\tilde{u}$. Note that $u(x) \le \frac{P}{2}$ if and only if $\tilde{u}(y) \ge \frac{\theta-1/2}{\theta-1}$ and that $\frac{\theta-1/2}{\theta-1}$ is large if $\theta$ is close to 1. So we obtain

$$
\frac{1}{|Q_{r}(x_0)|} \left| \left\{ u \le \frac{P}{2} \right\} \cap Q_{r}(x_0) \right| = \left| \left\{ \tilde{u} \ge \frac{\theta - \frac{1}{2}}{\theta - 1} \right\} \cap Q_{1} \right| \\ \le C \left( \frac{\theta - \frac{1}{2}}{\theta - 1} \right)^{-\varepsilon} < \frac{1}{2}
$$

if $\theta$ is chosen close to 1. This contradicts (5.10).

Hence we conclude that there exists a $\theta = \theta(n, \lambda, \Lambda) > 1$ such that if

$$
u(x_0) = P \quad \text{for some } x_0 \in B_{1/4}
$$

then

$$
u(x_1) \ge \theta P \quad \text{for some } x_1 \in Q_{4\sqrt{n}r}(x_0) \subset B_{2nr}(x_0)
$$

provided

$$
C(n, \lambda, \Lambda) P^{-\frac{\varepsilon}{n}} \le r \le (\theta - 1)P.
$$

So we need to choose $P$ such that $P \ge (\frac{C}{\theta-1})^{n/(n+\varepsilon)}$ and then take $r = CP^{-\varepsilon/n}$.

Now we may iterate the above result to get a sequence $\{x_k\}$ such that for any $k = 1, 2, \dots$,

$$
u(x_k) \ge \theta^k P \quad \text{for some } x_k \in B_{2nr_k}(x_{k-1})
$$

where $r_k = C(\theta^{k-1}P)^{-\varepsilon/n} = C\theta^{-(k-1)\varepsilon/n}P^{-\varepsilon/n}$. In order to have $\{x_k\} \in B_{1/2}$ we need $\sum 2nr_k < \frac{1}{4}$. Hence we choose $M_0$ such that

$$
M_0^{\varepsilon/n} \ge 8nC \sum_{k=1}^{\infty} \theta^{-(k-1)\frac{\varepsilon}{n}} \quad \text{and} \quad M_0 \ge \left( \frac{C}{\theta-1} \right)^{\frac{n}{n+\varepsilon}}
$$

and then take $P > M_0$. This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAAhCAIAAACuvOezAAAAlElEQVR4nO3WsQ0DIQwF0O8kY7AAjOAhmImCAZiKCRAswBggp7gmOl0VghSd/Ad4/jIFJhHBtjz20arfVId8pJTy/EWY+QBfp2FzTuectfbrurXWnHPv3Rhz7g4gxigLCSEAaK2JyK69jzGw71VVV1111VVX/T/1i1+biFbODSICkFK6uDiOeXPOleLM7L0HQFvv9zf7ZNEZ5c5i0wAAAABJRU5ErkJggg==)

In the rest of this section we prove a technical lemma concerning the second-order derivatives of functions in $S(\lambda, \Lambda, f)$. Such results will be needed in the discussion of $W^{2,p}$-estimates. First we introduce some terminology.