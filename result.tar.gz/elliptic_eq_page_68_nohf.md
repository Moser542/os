In (3.18), we may replace $r^{n+2\alpha}$ by $r^n$. As in the proof of Theorem 3.8, we can show that for any small $\delta > 0$ there exists an $R_1 \in (\frac{3}{4}, 1)$ such that for any $x \in B_{R_1}$ and $r < 1 - R_1$

$$
(3.20) \qquad \int_{B_r(x_0)} |Du|^2 \le C r^{n-2\delta} \{\chi(F) + \|u\|_{H^1(B)}^2\}.
$$

By Lemma 3.3, we also get

$$
(3.21) \qquad \int_{B_r(x_0)} u^2 \le C r^{n-2\delta} \{\chi(F) + \|u\|_{H^1(B)}^2\}.
$$

Write $\chi(F, u) = \|f\|_{L^q}^2 + \|u\|_{H^1}^2$. Then (3.19), (3.20), and (3.21) imply that

$$
\int_{B_\rho(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le c \left\{ \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + r^{n+2\alpha-2\delta} \chi(F, u) \right\}.
$$

Hence Lemma 3.4 and Theorem 3.1 imply that $Du \in C_{\text{loc}}^{\alpha-\delta}$ for small $\delta < \alpha$. In particular, $u \in C_{\text{loc}}^1$ with the estimate

$$
(3.22) \qquad \sup_{B_{3/4}} |u|^2 + \sup_{B_{3/4}} |Du|^2 \le C \chi(F, u).
$$

Now (3.19) and (3.22) imply that

$$
\int_{B_\rho(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le C \left\{ \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + r^{n+2\alpha} \chi(F, u) \right\}.
$$

This finishes the proof of Theorem 3.8. $\square$

REMARK 3.14. It is natural to ask whether $f \in L^\infty(B_1)$, with appropriate assumptions on $a_{ij}$ and $c$, implies $Du \in C_{\text{loc}}^1$. Consider a special case

$$
\int_{B_1} D_i u D_i \varphi = \int_{B_1} f \varphi \quad \text{for any } \varphi \in H_0^1(B_1).
$$

There exists an example showing that $f \in C$ and $u \in C_{\text{loc}}^{1,\alpha}$ for any $\alpha \in (0, 1)$ while $D^2u \notin C$.

EXAMPLE. In the $n$-dimensional ball $B_R = B_R(0)$ of radius $R < 1$ consider

$$
\Delta u = \frac{x_2^2 - x_1^2}{2|x|^2} \left\{ \frac{n+2}{(-\log|x|)^{1/2}} + \frac{1}{2(-\log|x|)^{3/2}} \right\}
$$