Geometrically $u - \varphi$ having a local minimum at $x_0$ means that $\varphi$ touches $u$ from below at $x_0$ if we adjust $\varphi$ appropriately by adding a constant. This suggests the following definition. We assume $f \in C(\Omega)$.

DEFINITION 5.1 $u \in C(\Omega)$ is a viscosity supersolution (respectively, subsolution) of

$$
Lu = f \quad \text{in } \Omega
$$

if for any $x_0 \in \Omega$ and any function $\varphi \in C^2(\Omega)$ such that $u-\varphi$ has a local minimum (respectively, maximum) at $x_0$ there holds

$$
L\varphi(x_0) \le f(x_0) \quad (\text{respectively, } L\varphi(x_0) \ge f(x_0)).
$$

We say that $u$ is a viscosity solution if it is a viscosity subsolution and a viscosity supersolution.

REMARK 5.2. By approximation we may replace the $C^2$-function $\varphi$ by a quadratic polynomial $Q$.

REMARK 5.3. The above analysis shows that a classical supersolution is a viscosity supersolution. It is straightforward to prove that a $C^2$ viscosity supersolution is a classical supersolution. Similar statements hold for subsolutions and solutions.

REMARK 5.4. The notion of viscosity solutions can be generalized to nonlinear equations accordingly.

Now we define in a weak way the class of “all solutions to all elliptic equations.” For any function $\varphi$ that is $C^2$ at $x_0$, we have the following equivalence:

$$
\begin{align*} \sum_{i,j=1}^{n} a_{ij}(x_0) D_{ij} \varphi(x_0) \le 0 \\ \iff \sum_{k=1}^{n} \alpha_k e_k \le 0 \quad \text{with } \lambda \le \alpha_k \le \Lambda, \ e_k = e_k(D^2 \varphi(x_0)) \\ \iff \sum_{e_i > 0} \alpha_i e_i + \sum_{e_i < 0} \alpha_i e_i \le 0 \\ \iff \sum_{e_i > 0} \alpha_i e_i \le \sum_{e_i < 0} \alpha_i (-e_i), \end{align*}
$$

which implies

$$
\lambda \sum_{e_i > 0} e_i \le \Lambda \sum_{e_i < 0} (-e_i)
$$

where $e_1, \dots, e_n$ are eigenvalues of the Hessian matrix $D^2\varphi(x_0)$. This means that positive eigenvalues of $D^2\varphi(x_0)$ are controlled by negative eigenvalues.

DEFINITION 5.5 Suppose $f$ is a continuous function in $\Omega$ and that $\lambda$ and $\Lambda$ are two positive constants. We define $u \in C(\Omega)$ to belong to $S^+(\lambda, \Lambda, f)$ (respectively,