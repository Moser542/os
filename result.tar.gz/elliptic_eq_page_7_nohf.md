we may integrate to get (ii). If we write (ii) as

$$
u(x)r^n = \frac{n}{\omega_n} \int_{B_r(x)} u(y)dy,
$$

we may differentiate to get (i).

REMARK 1.3. We may write the mean value properties in the following equivalent ways:

(i) $u$ satisfies the first mean value property if

$$
u(x) = \frac{1}{\omega_n} \int_{|w|=1} u(x + rw)dS_w \quad \text{for any } B_r(x) \subset \Omega;
$$

(ii) $u$ satisfies the second mean value property if

$$
u(x) = \frac{n}{\omega_n} \int_{|z| \le 1} u(x + rz)dz \quad \text{for any } B_r(x) \subset \Omega.
$$

Now we prove the maximum principle for the functions satisfying mean value properties.

PROPOSITION 1.4 If $u \in C(\bar{\Omega})$ satisfies the mean value property in $\Omega$, then $u$ assumes its maximum and minimum only on $\partial\Omega$ unless $u$ is constant.

PROOF: We only prove for the maximum. Set

$$
\Sigma = \{x \in \Omega : u(x) = M \equiv \max_{\bar{\Omega}} u\} \subset \Omega.
$$

It is obvious that $\Sigma$ is relatively closed. Next we show that $\Sigma$ is open. For any $x_0 \in \Sigma$, take $\bar{B}_r(x_0) \subset \Omega$ for some $r > 0$. By the mean value property we have

$$
M = u(x_0) = \frac{n}{\omega_n r^n} \int_{B_r(x_0)} u(y)dy \le M \frac{n}{\omega_n r^n} \int_{B_r(x_0)} dy = M.
$$

This implies $u = M$ in $B_r(x_0)$. Hence $\Sigma$ is both closed and open in $\Omega$. Therefore either $\Sigma = \emptyset$ or $\Sigma = \Omega$. $\square$

DEFINITION 1.5 A function $u \in C^2(\Omega)$ is harmonic if $\Delta u = 0$ in $\Omega$.

THEOREM 1.6 Let $u \in C^2(\Omega)$ be harmonic in $\Omega$. Then $u$ satisfies the mean value property in $\Omega$.

PROOF: Take any ball $B_r(x) \subset \Omega$. For $\rho \in (0, r)$, we apply the divergence theorem in $B_\rho(x)$ and get

$$
(*) \quad \int_{B_\rho(x)} \Delta u(y)dy = \int_{\partial B_\rho} \frac{\partial u}{\partial v} dS = \rho^{n-1} \int_{|w|=1} \frac{\partial u}{\partial \rho}(x + \rho w)dS_w \\ = \rho^{n-1} \frac{\partial}{\partial \rho} \int_{|w|=1} u(x + \rho w)dS_w.
$$