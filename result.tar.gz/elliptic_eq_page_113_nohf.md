Now we begin to prove Lemma 5.15. The following result is the key ingredient. It claims that if $u$ has a tangent paraboloid with opening 1 from below somewhere in $Q_3$, then the set where $u$ has a tangent paraboloid from below with opening $M$ in $Q_1$ is large. Compare it with Lemma 5.13.

LEMMA 5.16 Suppose that $\Omega$ is a bounded domain with $B_{6\sqrt{n}} \subset \Omega$ and that $u$ belongs to $S^+(\lambda, \Lambda, f)$ in $B_{6\sqrt{n}}$ for some $f \in C(B_{6\sqrt{n}})$. Then there exist constants $0 < \sigma < 1$, $\delta_0 > 0$, and $M > 1$, depending only on $n$, $\lambda$, and $\Lambda$, such that if $\|f\|_{L^n(B_{6\sqrt{n}})} \le \delta_0$ and $G_1^-(u, \Omega) \cap Q_3 \ne \emptyset$, then

$$
|G_M^-(u, \Omega) \cap Q_1| \ge 1 - \sigma.
$$

PROOF: Since $G_1^-(u, \Omega) \cap Q_3 \ne \emptyset$, there is an affine function $L_1$ such that

$$
v \ge P_1 \quad \text{in } \Omega \text{ with equality at some point in } Q_3
$$

where

$$
v(x) = \frac{u(x)}{2n} + L_1(x) \quad \text{and} \quad P_1(x) = 1 - \frac{|x|^2}{4n}.
$$

This implies $v \ge 0$ in $B_{2\sqrt{n}}$ and $\inf_{Q_3} \le 1$. Then as in the proof of Lemma 5.13, for $w = v + g$, where $g$ is the function constructed in Lemma 5.13, we have

$$
|\{w = \Gamma_w\} \cap Q_1| \ge 1 - \sigma
$$

for some $\sigma \in (0, 1)$ if $\delta_0$ is chosen small. Now we need to prove $\{w = \Gamma_w\} \cap Q_1 \subset G_M^-(u, \Omega) \cap Q_1$ for some $M > 1$. Let $x_0 \in \{w = \Gamma_w\} \cap Q_1$ and take an affine function $L_2$ with $L_2 < 0$ on $\partial B_{2\sqrt{n}}$ and

$$
L_2 \le \Gamma_w \le v + g \quad \text{in } B_{2\sqrt{n}} \text{ with equality at } x_0.
$$

It follows that

$$
(5.11) \qquad P_2 \le L_2 - g \le v \quad \text{in } B_{2\sqrt{n}} \text{ with equality at } x_0
$$

for a concave paraboloid $P_2$ of opening $M_0 = M_0(n, \lambda, \Lambda) > 0$.

Next we prove $P_2 \le v$ in $\Omega \setminus B_{2\sqrt{n}}$. Note that $P_2 < -g = 0 = P_1$ on $\partial B_{2\sqrt{n}}$ and that $P_2(x_0) = v(x_0) \ge P_1(x_0)$ with $x_0 \in Q_1 \subset B_{2\sqrt{n}}$. If we take $M_0 > \frac{1}{2n}$, then $\{P_2 - P_1 \ge 0\}$ is convex. We conclude that $P_2 - P_1 < 0$ in $\mathbb{R}^n \setminus B_{2\sqrt{n}}$. Hence we have $P_2 \le P_1 \le v$ in $\Omega \setminus B_{2\sqrt{n}}$. By (5.11) and the definition of $v$, we get $x_0 \in G_{2nM_0}^-(u, \Omega) \cap Q_1$ with $2nM_0 > 1$. $\square$

PROOF OF LEMMA 5.15: Recall $B_{6\sqrt{n}} \subset \Omega$, $u \in S^+(\lambda, \Lambda, f)$ in $B_{6\sqrt{n}}$ and

$$
(5.12) \qquad |u|_{L^\infty(\Omega)} \le 1, \quad \|f\|_{L^n(B_{6\sqrt{n}})} \le \delta_0.
$$

We will prove that there exist constants $M > 1$ and $0 < \gamma < 1$, depending only on $n$, $\lambda$, and $\Lambda$, such that

$$
|A_M^k(u, \Omega) \cap Q_1| \le \gamma^k \quad \text{for any } k = 0, 1, \dots
$$