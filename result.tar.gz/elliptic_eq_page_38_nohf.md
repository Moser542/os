PROOF: Set $L \equiv a_{ij} D_{ij} + b_i D_i$. We calculate $L(|Du|^2)$ first. Note

$$
(2.2) \qquad \begin{aligned} D_i (|Du|^2) &= 2D_k u D_{ki} u, \\ D_{ij} (|Du|^2) &= 2D_{ki} D_{kj} u + 2D_k u D_{kij} u. \end{aligned}
$$

Differentiating (2.1) with respect to $x_k$, multiplying by $D_k u$, and summing over $k$, we have by (2.2)

$$
\begin{aligned} & a_{ij} D_{ij} (|Du|^2) + b_i D_i (|Du|^2) \\ &= 2a_{ij} D_{ki} u D_{kj} u - 2D_k a_{ij} D_k u D_{ij} u \\ &\quad - 2D_k b_i D_k u D_i u + 2D_z f |Du|^2 + 2D_k f D_k u. \end{aligned}
$$

The ellipticity assumption implies

$$
\sum_{i,j,k} a_{ij} D_{ki} u D_{kj} u \geq \lambda |D^2 u|^2.
$$

By the Cauchy inequality, we have

$$
L(|Du|^2) \geq \lambda |D^2 u|^2 - C |Du|^2 - C
$$

with $C$ a positive constant depending only on $|f|_{C^1(\bar{\Omega} \times [-M, M])}$, $|a_{ij}, b_i|_{C^1(\bar{\Omega})}$, and $\lambda$.

We need to add another term $u^2$. We have by the ellipticity assumption

$$
\begin{aligned} L(u^2) &= 2a_{ij} D_i u D_j u + 2u\{a_{ij} D_{ij} u + b_i D_i u\} \\ &\geq 2\lambda |Du|^2 + 2uf. \end{aligned}
$$

Therefore we obtain

$$
\begin{aligned} L(|Du|^2 + \alpha u^2) &\geq \lambda |D^2 u|^2 + (2\lambda\alpha - C)|Du|^2 - C \\ &\geq \lambda |D^2 u|^2 + |Du|^2 - C \end{aligned}
$$

if we choose $\alpha > 0$ large, with $C$ depending in addition on $M$. In order to control the constant term we may consider another function $e^{\beta x_1}$ for $\beta > 0$. Hence we get

$$
\begin{aligned} L(|Du|^2 + \alpha u^2 + e^{\beta x_1}) &\geq \lambda |D^2 u|^2 + |Du|^2 \\ &\quad + \{\beta^2 a_{11} e^{\beta x_1} + \beta b_1 e^{\beta x_1} - C\}. \end{aligned}
$$

If we put the domain $\Omega \subset \{x_1 > 0\}$, then $e^{\beta x_1} \geq 1$ for any $x \in \Omega$. By choosing $\beta$ large, we may make the last term positive. Therefore, if we set $w = |Du|^2 + \alpha|u|^2 + e^{\beta x_1}$ for large $\alpha, \beta$ depending only on $\lambda$, $\text{diam}(\Omega)$, $|a_{ij}, b_i|_{C^1(\bar{\Omega})}$, $M = |u|_{L^\infty(\Omega)}$, and $|f|_{C^1(\bar{\Omega} \times [-M, M])}$, then we obtain

$$
Lw \geq 0 \quad \text{in } \Omega.
$$

By the maximum principle we have

$$
\sup_{\Omega} w \leq \sup_{\partial \Omega} w.
$$

This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAgCAIAAACKIl8oAAAAmElEQVR4nO2WMQoEIQxF/5jFEwmezdK7eBt7Eey8gb3RbbZYnKlGLARfZ/OQRyC5eu9Yg1jkPeo7n+HNzPNSIgKA/keMcd4LQCnVWluiBpBzfmhtra0TGGMAlFLG1gCI6BfrFUIIAMy8akJqrRuqT5CBE2TgBBnYM8ievz5B7uqH3eic896/loYQAEgplxwLWuuU0rXuCP4CRubBDgHpXBcAAAAASUVORK5CYII=)