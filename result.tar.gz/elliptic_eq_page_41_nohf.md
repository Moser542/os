Therefore we obtain by ellipticity

$$
\begin{aligned}
Lw &\le \psi'' a_{ij} D_i d D_j d + \psi' \left( \frac{n\Lambda - \lambda}{R} + |b| \right) \\
&\le \lambda \psi'' + \psi' \left( \frac{n\Lambda - \lambda}{R} + |b| \right)
\end{aligned}
$$

if we require $\psi'' < 0$. Hence in order to have $Lw \le -F$ we need

$$
\lambda \psi'' + \psi' \left( \frac{n\Lambda - \lambda}{R} + |b| \right) + F \le 0.
$$

To this end, we study the equation for some positive constants $a$ and $b$

$$
\psi'' + a\psi' + b = 0
$$

whose solution is given by

$$
\psi(d) = -\frac{b}{a}d + \frac{C_1}{a} - \frac{C_2}{a}e^{-ad}
$$

for some constants $C_1$ and $C_2$. For $\psi(0) = 0$, we need $C_1 = C_2$. Hence we have for some constant $C$

$$
\psi(d) = -\frac{b}{a}d + \frac{C}{a}(1 - e^{-ad}),
$$

which implies

$$
\psi'(d) = Ce^{-ad} - \frac{b}{a} = e^{-ad} \left( C - \frac{b}{a} e^{ad} \right)
$$

$$
\psi''(d) = -Cae^{-ad}.
$$

In order to have $\psi'(d) > 0$, we need $C \ge \frac{b}{a}e^{aD}$. Since $\psi'(d) > 0$ for $d > 0$, so $\psi(d) > \psi(0) = 0$ for any $d > 0$. Therefore we take

$$
\begin{aligned}
\psi(d) &= -\frac{b}{a}d + \frac{b}{a^2}e^{aD}(1 - e^{-ad}) \\
&= \frac{b}{a}\left\{\frac{1}{a}e^{aD}(1 - e^{-ad}) - d\right\}.
\end{aligned}
$$

Such $\psi$ satisfies all the requirements we imposed. This finishes the proof. $\square$

## 2.5. Alexandroff Maximum Principle

Suppose $\Omega$ is a bounded domain in $\mathbb{R}^n$ and consider a second-order elliptic operator $L$ in $\Omega$

$$
L \equiv a_{ij}(x) D_{ij} + b_i(x) D_i + c(x)
$$

where coefficients $a_{ij}, b_i, c$ are at least continuous in $\Omega$. Ellipticity means that the coefficient matrix $A = (a_{ij})$ is positive definite everywhere in $\Omega$. We set $D = \det(A)$ and $D^* = D^{1/n}$ so that $D^*$ is the geometric mean of the eigenvalues of $A$. Throughout this section we assume

$$
0 < \lambda \le D^* \le \Lambda
$$