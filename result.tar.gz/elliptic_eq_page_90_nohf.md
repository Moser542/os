Therefore we obtain

$$
\int_{B_1} \zeta^2 |w_m|^{2\beta} |Dw|^2 \le C \left\{ (2\beta)^{2\beta} \int_{B_1} \zeta^2 |Dw_m|^2 + \beta \int_{B_1} \zeta |w_m|^{2\beta} |Dw| |D\zeta| + \beta \int_{B_1} |\tilde{f}| \zeta^2 |w_m|^{2\beta} \right\}.
$$

Note that the first term in the right side is bounded in (4.11). Applying the Cauchy inequality to the second term in the right side we conclude

$$
\int_{B_1} \zeta^2 |w_m|^{2\beta} |Dw|^2 \le C \left\{ (2\beta)^{2\beta} \int_{B_1} \zeta^2 |Dw_m|^2 + \beta^2 \int_{B_1} |w_m|^{2\beta} |D\zeta|^2 + \beta \int_{B_1} |\tilde{f}| \zeta^2 |w_m|^{2\beta} \right\}.
$$

Note $Dw = Dw_m$ for $|w| < m$ and $Dw_m = 0$ for $|w| > m$. Hence we have

$$
\int_{B_1} \zeta^2 |w_m|^{2\beta} |Dw_m|^2 \le C \left\{ (2\beta)^{2\beta} \int_{B_1} \zeta^2 |Dw_m|^2 + \beta^2 \int_{B_1} |w_m|^{2\beta} |D\zeta|^2 + \beta \int_{B_1} |\tilde{f}| \zeta^2 |w_m|^{2\beta} \right\}.
$$

In the following, we write $w = w_m$ and then let $m \to +\infty$. By Young's inequality we obtain

$$
\begin{aligned} |D(\zeta|w|^\beta)|^2 &\le 2|D\zeta|^2|w|^{2\beta} + 2\beta^2\zeta^2|w|^{2\beta-2}|Dw|^2 \\ &\le 2|D\zeta|^2|w|^{2\beta} + 2\zeta^2|Dw|^2 \left( \frac{\beta-1}{\beta}|w|^{2\beta} + \frac{1}{\beta}\beta^{2\beta} \right) \end{aligned}
$$

and hence

$$
\int_{B_1} |D(\zeta|w|^\beta)|^2 \le C \left\{ (2\beta)^{2\beta} \int_{B_1} \zeta^2 |Dw|^2 + \beta^2 \int_{B_1} |D\zeta|^2 |w|^{2\beta} + \beta \int_{B_1} |\tilde{f}| \zeta^2 |w|^{2\beta} \right\}.
$$

The Hölder inequality implies

$$
\int_{B_1} |\tilde{f}| \zeta^2 |w|^{2\beta} \le \left( \int_{B_1} |\tilde{f}|^q \right)^{\frac{1}{q}} \left( \int_{B_1} (\zeta|w|^\beta)^{\frac{2q}{q-1}} \right)^{1-\frac{1}{q}}.
$$

By the interpolation and Sobolev inequalities with $2^* = \frac{2n}{n-2} > \frac{2q}{q-1} > 2$ if $q > \frac{n}{2}$, we have

$$
\begin{aligned} \|\zeta|w|^\beta\|_{L^{\frac{2q}{q-1}}} &\le \varepsilon \|\zeta|w|^\beta\|_{L^{2^*}} + C(n, q)\varepsilon^{-\frac{n}{2q-n}} \|\zeta|w|^\beta\|_{L^2} \\ &\le \varepsilon \|D(\zeta|w|^\beta)\|_{L^2} + C(n, q)\varepsilon^{-\frac{n}{2q-n}} \|\zeta|w|^\beta\|_{L^2} \end{aligned}
$$