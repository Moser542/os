PROOF: We prove this by direct computation. In fact, with $v = u - w$ we have for any $0 < \rho \le r$

$$
\begin{align*}
\int_{B_{\rho}(x_0)} |Du|^2 &\le 2 \int_{B_{\rho}(x_0)} |Dw|^2 + 2 \int_{B_{\rho}(x_0)} |Dv|^2 \\
&\le c \left(\frac{\rho}{r}\right)^n \int_{B_r(x_0)} |Dw|^2 + 2 \int_{B_r(x_0)} |Dv|^2 \\
&\le c \left(\frac{\rho}{r}\right)^n \int_{B_r(x_0)} |Du|^2 + c \left[1 + \left(\frac{\rho}{r}\right)^n\right] \int_{B_r(x_0)} |Dv|^2
\end{align*}
$$

and

$$
\begin{align*}
\int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 & \\
&\le 2 \int_{B_{\rho}(x_0)} |Du - (Dw)_{x_0, \rho}|^2 + 2 \int_{B_{\rho}(x_0)} |Dv|^2 \\
&\le 4 \int_{B_{\rho}(x_0)} |Dw - (Dw)_{x_0, \rho}|^2 + 6 \int_{B_{\rho}(x_0)} |Dv|^2 \\
&\le c \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Dw - (Dw)_{x_0, r}|^2 + 6 \int_{B_r(x_0)} |Dv|^2 \\
&\le c \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + c \left[1 + \left(\frac{\rho}{r}\right)^{n+2}\right] \int_{B_r(x_0)} |Dv|^2.
\end{align*}
$$

□

REMARK 3.12. The regularity of $u$ depends on how close $u$ is to $w$, the solution to the constant-coefficient equation.

PROOF OF THEOREM 3.8: We shall decompose $u$ into a sum $v + w$ where $w$ satisfies a homogeneous equation and $v$ has estimates in terms of nonhomogeneous terms.

For any $B_r(x_0) \subset B_1$ write the equation in the following form:

$$
\int_{B_1} a_{ij}(x_0) D_i u D_j \varphi = \int_{B_1} f \varphi - c u \varphi + (a_{ij}(x_0) - a_{ij}(x)) D_i u D_j \varphi.
$$

In $B_r(x_0)$ the Dirichlet problem

$$
\int_{B_r(x_0)} a_{ij}(x_0) D_i w D_j \varphi = 0 \quad \text{for any } \varphi \in H_0^1(B_r(x_0))
$$