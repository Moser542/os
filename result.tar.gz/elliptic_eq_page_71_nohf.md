METHOD 1: DE GIORGI'S APPROACH: Consider $v = (u - k)^+$ for $k \ge 0$ and $\zeta \in C_0^1(B_1)$. Set $\varphi = v\zeta^2$ as the test function. Note $v = u - k$, $Dv = Du$ a.e. in $\{u > k\}$ and $v = 0$, $Dv = 0$ a.e. in $\{u \le k\}$. Hence if we substitute such defined $\varphi$ in (*), we integrate in the set $\{u > k\}$.

By the Hölder inequality we have

$$
\begin{align*}
\int a_{ij} D_i u D_j \varphi &= \int a_{ij} D_i u D_j v \zeta^2 + 2a_{ij} D_i u D_j \zeta v \zeta \\
&\geq \lambda \int |Dv|^2 \zeta^2 - 2\Lambda \int |Dv| |D\zeta| v \zeta \\
&\geq \frac{\lambda}{2} \int |Dv|^2 \zeta^2 - \frac{2\Lambda^2}{\lambda} \int |D\zeta|^2 v^2.
\end{align*}
$$

Hence we obtain

$$
\int |Dv|^2 \zeta^2 \le C \left\{ \int v^2 |D\zeta|^2 + \int |c| v^2 \zeta^2 + k^2 \int |c| \zeta^2 + \int |f| v \zeta^2 \right\}
$$

from which the estimate

$$
\int |D(v\zeta)|^2 \le C \left\{ \int v^2 |D\zeta|^2 + \int |c| v^2 \zeta^2 + k^2 \int |c| \zeta^2 + \int |f| v \zeta^2 \right\}
$$

follows.

Recall the Sobolev inequality for $v\zeta \in H_0^1(B_1)$,

$$
\left( \int_{B_1} (v\zeta)^{2^*} \right)^{\frac{2}{2^*}} \le c(n) \int_{B_1} |D(v\zeta)|^2
$$

where $2^* = 2n/(n-2)$ for $n > 2$ and $2^* > 2$ is arbitrary if $n = 2$. The Hölder inequality implies that with $\delta > 0$ small and $\zeta \le 1$

$$
\begin{align*}
\int |f| v \zeta^2 &\le \left( \int |f|^q \right)^{\frac{1}{q}} \left( \int |v \zeta|^{2^*} \right)^{\frac{1}{2^*}} |\{v \zeta \ne 0\}|^{1-\frac{1}{2^*}-\frac{1}{q}} \\
&\le c(n) \|f\|_{L^q} \left( \int |D(v\zeta)|^2 \right)^{\frac{1}{2}} |\{v\zeta \ne 0\}|^{\frac{1}{2}+\frac{1}{n}-\frac{1}{q}} \\
&\le \delta \int |D(v\zeta)|^2 + c(n, \delta) \|f\|_{L^q}^2 |\{v\zeta \ne 0\}|^{1+\frac{2}{n}-\frac{2}{q}}.
\end{align*}
$$

Note $1 + \frac{2}{n} - \frac{2}{q} > 1 - \frac{1}{q}$ if $q > \frac{n}{2}$. Therefore we have the following estimate:

$$
\int |D(v\zeta)|^2 \le C \left\{ \int v^2 |D\zeta|^2 + \int |c| v^2 \zeta^2 + k^2 \int |c| \zeta^2 + F^2 |\{v\zeta \ne 0\}|^{1-\frac{1}{q}} \right\}
$$

where $F = \|f\|_{L^q(B_1)}$.

We claim that there holds

$$
(4.1) \quad \int |D(v\zeta)|^2 \le C \left\{ \int v^2 |D\zeta|^2 + (k^2 + F^2) |\{v\zeta \ne 0\}|^{1-\frac{1}{q}} \right\}
$$

if $|\{v\zeta \ne 0\}|$ is small.