and integrating with respect to $x$ in $B_{r_1}(x_0)$

$$
|u_{x_0, r_1} - u_{x_0, r_2}|^2 \le \frac{2}{\omega_n r_1^n} \left\{ \int_{B_{r_1}(x_0)} |u - u_{x_0, r_1}|^2 + \int_{B_{r_2}(x_0)} |u - u_{x_0, r_2}|^2 \right\}
$$

from which the estimate

$$
(3.1) \qquad |u_{x_0, r_1} - u_{x_0, r_2}|^2 \le c(n) M^2 r_1^{-n} \{r_1^{n+2\alpha} + r_2^{n+2\alpha}\}
$$

follows.

For any $R \le R_0$, with $r_1 = R/2^{i+1}$, $r_2 = R/2^i$, we obtain

$$
|u_{x_0, 2^{-(i+1)}R} - u_{x_0, 2^{-i}R}| \le c(n) 2^{-(i+1)\alpha} MR^{\alpha}
$$

and therefore for $h < k$

$$
|u_{x_0, 2^{-h}R} - u_{x_0, 2^{-k}R}| \le \frac{c(n)}{2^{(h+1)\alpha}} MR^{\alpha} \sum_{i=0}^{k-h-1} \frac{1}{2^{i\alpha}} \le \frac{c(n, \alpha)}{2^{h\alpha}} MR^{\alpha}.
$$

This shows that $\{u_{x_0, 2^{-i}R}\} \subset \mathbb{R}$ is a Cauchy sequence, hence a convergent one. Its limit $\hat{u}(x_0)$ is independent of the choice of $R$, since (3.1) can be applied with $r_1 = 2^{-i}R$ and $r_2 = 2^{-i}\bar{R}$ whenever $0 < R < \bar{R} \le R_0$. Thus we get

$$
\hat{u}(x_0) = \lim_{r \downarrow 0} u_{x_0, r}
$$

with

$$
(3.2) \qquad |u_{x_0, r} - \hat{u}(x_0)| \le c(n, \alpha) Mr^{\alpha}
$$

for any $0 < r \le R_0$.

Recall that $\{u_{x,r}\}$ converges, as $r \to 0+$, in $L^1(\Omega)$ to the function $u$, by the Lebesgue theorem, so we have $u = \hat{u}$ a.e. and (3.2) implies that $\{u_{x,r}\}$ converges uniformly to $u(x)$ in $\Omega'$. Since $x \mapsto u_{x,r}$ is continuous for any $r > 0$, $u(x)$ is continuous. By (3.2) we get

$$
|u(x)| \le CMR^{\alpha} + |u_{x,R}|
$$

for any $x \in \Omega'$ and $R \le R_0$. Hence $u$ is bounded in $\Omega'$ with the estimate

$$
\sup_{\Omega'} |u| \le c\{MR_0^{\alpha} + \|u\|_{L^2(\Omega)}\}.
$$

Finally, we prove that $u$ is Hölder-continuous. Let $x, y \in \Omega'$ with $R = |x - y| < R_0/2$. Then we have

$$
|u(x) - u(y)| \le |u(x) - u_{x,2R}| + |u(y) - u_{y,2R}| + |u_{x,2R} - u_{y,2R}|.
$$

The first two terms on the right sides are estimated in (3.2). For the last term we write

$$
|u_{x,2R} - u_{y,2R}| \le |u_{x,2R} - u(\zeta)| + |u_{y,2R} - u(\zeta)|
$$