Hence we have for such $x$ and $y$

$$
D_{y_i} G(x, y) = -\frac{1}{\omega_n} \left( \frac{x_i - y_i}{|x - y|^n} - \left(\frac{R}{|x|}\right)^{n-2} \cdot \frac{X_i - y_i}{|X - y|^n} \right) = \frac{y_i}{\omega_n R^2} \frac{R^2 - |x|^2}{|x - y|^n}
$$

by (1.5) in the proof of Proposition 1.22. We obtain with $n_i = \frac{y_i}{R}$ for $|y| = R$

$$
\frac{\partial G}{\partial n}(x, y) = \sum_{i=1}^{n} n_i D_{y_i} G(x, y) = \frac{1}{\omega_n R} \cdot \frac{R^2 - |x|^2}{|x - y|^n}.
$$

□

Denote by $K(x, y)$ the function in Corollary 1.23 for $x \in \Omega, y \in \partial\Omega$. It is called a Poisson kernel and has the following properties:

(i) $K(x, y)$ is smooth for $x \neq y$;

(ii) $K(x, y) > 0$ for $|x| < R$;

(iii) $\int_{|y|=R} K(x, y)dS_y = 1$ for any $|x| < R$.

The following result gives the existence of harmonic functions in balls with prescribed Dirichlet boundary value.

**THEOREM 1.24 (Poisson Integral Formula)** For $\varphi \in C(\partial B_R(0))$, the function $u$ defined by

$$
u(x) = \begin{cases} \int_{\partial B_R(0)} K(x, y)\varphi(y)dS_y, & |x| < R, \\ \varphi(x), & |x| = R, \end{cases}
$$

satisfies $u \in C(\bar{\Omega}) \cap C^\infty(\Omega)$ and

$$
\begin{cases} \Delta u = 0 & \text{in } \Omega, \\ u = \varphi & \text{on } \partial \Omega. \end{cases}
$$

For the proof, see [9, pp. 107–108].

**REMARK 1.25.** In the Poisson integral formula, by letting $x = 0$, we have

$$
u(0) = \frac{1}{\omega_n R^{n-1}} \int_{\partial B_R(0)} \varphi(y)dS_y,
$$

which is the mean value property.

**LEMMA 1.26 (Harnack's Inequality)** Suppose $u$ is harmonic in $B_R(x_0)$ and $u \ge 0$. Then there holds

$$
\left(\frac{R}{R+r}\right)^{n-2} \frac{R-r}{R+r} u(x_0) \le u(x) \le \left(\frac{R}{R-r}\right)^{n-2} \frac{R+r}{R-r} u(x_0)
$$

where $r = |x - x_0| < R$.

**PROOF:** We may assume $x_0 = 0$ and $u \in C(\bar{B}_R)$. Note that $u$ is given by the Poisson integral formula

$$
u(x) = \frac{1}{\omega_n R} \int_{\partial B_R} \frac{R^2 - |x|^2}{|y - x|^n} u(y) dS_y.
$$