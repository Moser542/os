THEOREM 4.9 (Density Theorem) Suppose $u$ is a positive supersolution in $B_2$ with

$$
|\{x \in B_1 : u \ge 1\}| \ge \varepsilon|B_1|.
$$

Then there exists a constant $C$ depending only on $\varepsilon$, $n$, and $\Lambda/\lambda$ such that

$$
\inf_{B_{1/2}} u \ge C.
$$

PROOF: We may assume that $u \ge \delta > 0$. Then let $\delta \to 0^+$. By Lemma 4.6, $v = (\log u)^{-}$ is a subsolution, bounded by $\log \delta^{-1}$. Then Theorem 4.1 yields

$$
\sup_{B_{1/2}} v \le C \left( \int_{B_1} |v|^2 \right)^{1/2}.
$$

Note $|\{x \in B_1 : v = 0\}| = |\{x \in B_1 : u \ge 1\}| \ge \varepsilon|B_1|$. Lemma 4.8 implies

$$
(4.7) \qquad \sup_{B_{1/2}} v \le C \left( \int_{B_1} |Dv|^2 \right)^{1/2}.
$$

We will prove that the right-hand side is bounded. To this end, set $\varphi = \frac{\zeta^2}{u}$ for $\zeta \in C_0^1(B_2)$ as the text function. Then we obtain

$$
0 \le \int a_{ij} D_i u D_j \left( \frac{\zeta^2}{u} \right) = - \int \zeta^2 \frac{a_{ij} D_i u D_j u}{u^2} + 2 \int \frac{\zeta a_{ij} D_i u D_j \zeta}{u},
$$

which implies

$$
\int \zeta^2 |D \log u|^2 \le C \int |D \zeta|^2.
$$

So for fixed $\zeta \in C_0^1(B_2)$ with $\zeta \equiv 1$ in $B_1$ we have

$$
\int_{B_1} |D \log u|^2 \le C.
$$

Combining this with (4.7) we obtain

$$
\sup_{B_{1/2}} v = \sup_{B_{1/2}} (\log u)^{-} \le C \quad \text{which gives} \quad \inf_{B_{1/2}} u \ge e^{-C} > 0.
$$

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAgCAIAAACKIl8oAAAAiElEQVR4nO3WMQ1EIQyA4RaOGQXYQAIGMIEMFJDKYCHoQBNDb2A6xiO85CX9BXw06VCQmeFO6pIr9KM08G9EZIzRZ1lrc86f7aUxxpzTe++c+3vc1lopZZ86xggAtVY+CAC01u9co9BCCy200ELfo/eLviKi3vuJq5TaL3pK6URcIWIIAe99gr/QEYW3EhRUiQAAAABJRU5ErkJggg==)

THEOREM 4.10 (Oscillation Theorem) Suppose that $u$ is a bounded solution of $Lu = 0$ in $B_2$. Then there exists a $\gamma = \gamma(n, \frac{\Lambda}{\lambda}) \in (0, 1)$ such that

$$
\operatorname{osc}_{B_{1/2}} u \le \gamma \operatorname{osc}_{B_1} u.
$$

PROOF: In fact, local boundedness is proved in the previous section. Set

$$
\alpha_1 = \sup_{B_1} u \quad \text{and} \quad \beta_1 = \inf_{B_1} u.
$$

Consider the solution

$$
\frac{u - \beta_1}{\alpha_1 - \beta_1} \quad \text{or} \quad \frac{\alpha_1 - u}{\alpha_1 - \beta_1}.
$$