Since $R - |x| \le |y - x| \le R + |x|$ for $|y| = R$, we have

$$
\frac{1}{\omega_n R} \cdot \frac{R - |x|}{R + |x|} \left( \frac{1}{R + |x|} \right)^{n-2} \int_{\partial B_R} u(y) dS_y \le u(x) \le \frac{1}{\omega_n R} \cdot \frac{R + |x|}{R - |x|} \left( \frac{1}{R - |x|} \right)^{n-2} \int_{\partial B_R} u(y) dS_y.
$$

The mean value property implies

$$
u(0) = \frac{1}{\omega_n R^{n-1}} \int_{\partial B_R} u(y) dS_y.
$$

This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAfCAIAAAB7+zptAAAAf0lEQVR4nO2TMQrAIAwA0xJw8w/Ogp/xQ37IF7n6CQdNl1bQqdQ4FHKTOhwciQcRATcnu1GkW6TYTzlnY8z6MjjngB5SSou6zpzvvacFQgiDlPEX/Gf6kn8j+fxSRiR/p1Ty+aWM4HSPMSLOj+9prQ1SrbVSqpRSa/0sBQBr7QWuy3Q0k9akIgAAAABJRU5ErkJggg==)

**COROLLARY 1.27** If harmonic function $u$ in $\mathbb{R}^n$ is bounded above or below, then $u \equiv \text{const.}$

PROOF: We assume $u \ge 0$ in $\mathbb{R}^n$. Take any point $x \in \mathbb{R}^n$ and apply Lemma 1.26 to any ball $B_R(0)$ with $R > |x|$. We obtain

$$
\left( \frac{R}{R + |x|} \right)^{n-2} \frac{R - |x|}{R + |x|} u(0) \le u(x) \le \left( \frac{R}{R - |x|} \right)^{n-2} \frac{R + |x|}{R - |x|} u(0),
$$

which implies $u(x) = u(0)$ by letting $R \to +\infty$.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAfCAIAAAB7+zptAAAAcUlEQVR4nO2TsQ3AIAwE7YQGidZrsBUbMwqU4JRBSTo/RSRf6eLgsGBVJTQH3OjSLVLShVLKaSalFNYDeu9jDOMtW2sf+bVWNUCPN0V9hP9s3/NvPB8vReH5m6Wej5eiCO9RzpmZYVIRIaI5p8UYY7wAv0JxCjtopJcAAAAASUVORK5CYII=)

Next we prove a result concerning the removable singularity.

**THEOREM 1.28** Suppose $u$ is harmonic in $B_R \setminus \{0\}$ and satisfies

$$
u(x) = \begin{cases} o(\log |x|), & n = 2, \\ o(|x|^{2-n}), & n \ge 3, \end{cases} \quad \text{as } |x| \to 0.
$$

Then $u$ can be defined at $0$ so that it is $C^2$ and harmonic in $B_R$.

PROOF: Assume $u$ is continuous in $0 < |x| \le R$. Let $v$ solve

$$
\begin{cases} \Delta v = 0 & \text{in } B_R, \\ v = u & \text{on } \partial B_R. \end{cases}
$$

We will prove $u = v$ in $B_R \setminus \{0\}$. Set $w = v - u$ in $B_R \setminus \{0\}$ and $M_r = \max_{\partial B_r} |w|$. We prove for $n \ge 3$. It is obvious that

$$
|w(x)| \le M_r \cdot \frac{r^{n-2}}{|x|^{n-2}} \quad \text{on } \partial B_r.
$$

Note $w$ and $\frac{1}{|x|^{n-2}}$ are harmonic in $B_R \setminus B_r$. Hence the maximum principle implies

$$
|w(x)| \le M_r \cdot \frac{r^{n-2}}{|x|^{n-2}} \quad \text{for any } x \in B_R \setminus B_r
$$