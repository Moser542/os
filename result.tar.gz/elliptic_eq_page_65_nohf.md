and

$$
(3.13) \qquad \int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le c \left\{ \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + \tau^2(r) \int_{B_r(x_0)} |Du|^2 + \left(\int_{B_r(x_0)} |c|^n\right)^{\frac{2}{n}} \int_{B_r(x_0)} u^2 + \left(\int_{B_r(x_0)} |f|^{\frac{2n}{n+2}}\right)^{\frac{n+2}{n}} \right\},
$$

where $c$ is a positive constant depending only on $\lambda$ and $\Lambda$.

By the Hölder inequality we have for any $B_r(x_0) \subset B_1$

$$
\begin{aligned} \left( \int_{B_r(x_0)} |f|^{\frac{2n}{n+2}} \right)^{\frac{n+2}{n}} &\le \left( \int_{B_r(x_0)} |f|^q \right)^{\frac{2}{q}} r^{n+2\alpha}, \\ \left( \int_{B_r(x_0)} |c|^n \right)^{\frac{2}{n}} &\le r^{2\alpha} \left( \int_{B_r(x_0)} |c|^q \right)^{\frac{2}{q}} \end{aligned}
$$

with $\alpha = 1 - \frac{n}{q}$.

CASE 1. $a_{ij} \equiv \text{const}$, $c \equiv 0$.

In this case $\tau(r) \equiv 0$. Hence by estimate (3.13) there holds for any $B_r(x_0) \subset B_1$ and $0 < \rho \le r$,

$$
\int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le C \left\{ \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + r^{n+2\alpha} \|f\|_{L^q(B_1)}^2 \right\}.
$$

By Lemma 1.4, we may replace $r^{n+2\alpha}$ by $\rho^{n+2\alpha}$ to get the result.

CASE 2. $c \equiv 0$.

By (3.12) and (3.13), we have for any $B_r(x_0) \subset B_1$ and any $\rho < r$

$$
(3.14) \qquad \int_{B_{\rho}(x_0)} |Du|^2 \le C \left\{ \left[ \left(\frac{\rho}{r}\right)^n + r^{2\alpha} \right] \int_{B_r(x_0)} |Du|^2 + r^{n+2\alpha} \|f\|_{L^q(B_1)}^2 \right\}
$$