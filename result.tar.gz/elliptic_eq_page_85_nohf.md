LEMMA 4.12 Suppose that $a_{ij} \in L^\infty(B_r)$ satisfies

$\lambda|\xi|^2 \le a_{ij}(x)\xi_i\xi_j \le \Lambda|\xi|^2$ for any $x \in B_r$, $\xi \in \mathbb{R}^n$,
for some $0 < \lambda \le \Lambda < +\infty$. Suppose $u \in H^1(B_r)$ satisfies

$$
\int_{B_r} a_{ij} D_i u D_j \varphi = 0 \quad \text{for any } \varphi \in H_0^1(B_r).
$$

Then there exists an $\alpha \in (0, 1)$ such that for any $\rho < r$ there holds

$$
\int_{B_\rho} |Du|^2 \le C \left(\frac{\rho}{r}\right)^{n-2+2\alpha} \int_{B_r} |Du|^2
$$

where $C$ and $\alpha$ depend only on $n$ and $\frac{\Lambda}{\lambda}$.

PROOF: By dilation, consider $r = 1$. We restrict our consideration to the range $\rho \in (0, \frac{1}{4}]$, since it is trivial for $\rho \in (\frac{1}{4}, 1]$. We may further assume that $\int_{B_1} u = 0$ since the function $u - |B_1|^{-1} \int_{B_1} u$ solves the same equation. The Poincaré inequality yields

$$
\int_{B_1} u^2 \le c(n) \int_{B_1} |Du|^2.
$$

Hence Theorem 4.11 implies for $|x| \le \frac{1}{2}$

$$
|u(x) - u(0)|^2 \le C |x|^{2\alpha} \int_{B_1} |Du|^2
$$

where $\alpha \in (0, 1)$ is determined in Theorem 4.11. For any $0 < \rho \le \frac{1}{4}$ take a cutoff function $\zeta \in C_0^\infty(B_{2\rho})$ with $\zeta \equiv 1$ in $B_\rho$ and $0 \le \rho \le 1$ and $|D\zeta| \le \frac{2}{\rho}$. Then set $\varphi = \zeta^2(u - u(0))$. Hence the equation yields

$$
\begin{aligned} 0 &= \int_{B_1} a_{ij} D_i u (\zeta^2 D_j u + 2\zeta D_j \zeta(u - u(0))) \\ &\ge \frac{\lambda}{2} \int_{B_{2\rho}} \zeta^2 |Du|^2 - C \sup_{B_{2\rho}} |u - u(0)|^2 \int_{B_{2\rho}} |D\zeta|^2. \end{aligned}
$$

Therefore we have

$$
\int_{B_\rho} |Du|^2 \le C \rho^{n-2} \sup_{B_{2\rho}} |u - u(0)|^2.
$$

The conclusion follows easily.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAfCAIAAACUOVFTAAAAaklEQVR4nGP8//8/Aw0AEy0MHTUXDliQOU+ePCkpKaHcUAsLC4b/SODKlSuUGwoBWMKhpaXlPwWgoaEBu7m0cu+ouaPmjpo7au6ouaPm0s1cFkyhFStWXL58mWwToZU6Lep5WVlZRhq1JwGJCW3bGBrD+AAAAABJRU5ErkJggg==)

Now we may prove the following result in the same way we proved Theorem 3.8, with Lemma 3.10 replaced by Lemma 4.12.