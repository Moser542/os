is solvable in $C^{2,\alpha}(\bar{\Omega})$ for any $f \in C^\alpha(\bar{\Omega})$. We take an $s \in I$ and let $u = L_s^{-1}f$ be the (unique) solution. The global $C^{2,\alpha}$-estimates and the maximum principle imply

$$
|L_s^{-1} f|_{C^{2,\alpha}(\Omega)} \le C |f|_{C^\alpha(\bar{\Omega})}.
$$

For any $t \in [0, 1]$ and $f \in C^\alpha(\bar{\Omega})$, we write $L_t u = f$ as

$$
L_s u = f + (L_s - L_t)u = f + (t - s)(\Delta u - Lu).
$$

Hence $u \in C^{2,\alpha}(\bar{\Omega})$ is a solution of

$$
\begin{aligned} L_t u &= f \quad \text{in } \Omega, \\ u &= 0 \quad \text{on } \partial\Omega, \end{aligned}
$$

if and only if

$$
u = L_s^{-1}(f + (t - s)(\Delta u - Lu)).
$$

For any $u \in \mathcal{X}$, set

$$
Tu = L_s^{-1}(f + (t - s)(\Delta u - Lu)).
$$

Then $T : \mathcal{X} \to \mathcal{X}$ is an operator and for any $u, v \in \mathcal{X}$

$$
\begin{aligned} |Tu - Tv|_{C^{2,\alpha}(\bar{\Omega})} &= |(t-s)L_s^{-1}((\Delta-L)(u-v))|_{C^{2,\alpha}(\bar{\Omega})} \\ &\le C|t-s||(\Delta-L)(u-v)|_{C^\alpha(\bar{\Omega})} \\ &\le C|t-s||u-v|_{C^{2,\alpha}(\bar{\Omega})}. \end{aligned}
$$

Therefore, $T : \mathcal{X} \to \mathcal{X}$ is a contraction if

$$
|t - s| < \delta = C^{-1}.
$$

Hence for any $t \in [0, 1]$ with $|t - s| < \delta$, there exists a $u \in \mathcal{X}$ such that $u = Tu$; i.e.,

$$
u = L_s^{-1}(f + (t - s)(\Delta u - Lu)).
$$

In other words, for any $t \in [0, 1]$ with $|t - s| < \delta$ and any $f \in C^\alpha(\bar{\Omega})$, there exists a solution $u \in C^{2,\alpha}(\bar{\Omega})$ of

$$
\begin{aligned} L_t u &= f \quad \text{in } \Omega, \\ u &= 0 \quad \text{on } \partial\Omega. \end{aligned}
$$

Thus if $s \in I$, then $t \in I$ for any $t \in [0, 1]$ with $|t - s| < \delta$. We now divide the interval $[0, 1]$ into subintervals of length less than $\delta$. By $0 \in I$, we conclude $1 \in I$. $\square$

## 6.4. Compactness Methods

In this section we discuss several methods to solve nonlinear elliptic differential equations. All these methods involve the compactness of the Hölder functions: A bounded sequence of Hölder functions has a subsequence convergent to a Hölder function.

We first consider a class of semilinear elliptic equations.