LEMMA 4.19 Let $\omega$ and $\sigma$ be nondecreasing functions in an interval $(0, R]$. Suppose there holds for all $r \le R$

$$
\omega(\tau r) \le \gamma\omega(r) + \sigma(r)
$$

for some $0 < \gamma, \tau < 1$. Then for any $\mu \in (0, 1)$ and $r \le R$ we have

$$
\omega(r) \le C \left\{ \left( \frac{r}{R} \right)^{\alpha} \omega(R) + \sigma(r^{\mu} R^{1-\mu}) \right\}
$$

where $C = C(\gamma, \tau)$ and $\alpha = \alpha(\gamma, \tau, \mu)$ are positive constants. In fact, $\alpha = (1 - \mu) \log \gamma / \log \tau$.

PROOF: Fix some number $r_1 \le R$. Then for any $r \le r_1$ we have

$$
\omega(\tau r) \le \gamma\omega(r) + \sigma(r_1)
$$

since $\sigma$ is nondecreasing. We now iterate this inequality to get for any positive integer $k$

$$
\omega(\tau^k r_1) \le \gamma^k \omega(r_1) + \sigma(r_1) \sum_{i=0}^{k-1} \gamma^i \le \gamma^k \omega(R) + \frac{\sigma(r_1)}{1-\gamma}.
$$

For any $r \le r_1$ we choose $k$ in such a way that

$$
\tau^k r_1 < r \le \tau^{k-1} r_1.
$$

Hence we have

$$
\omega(r) \le \omega(\tau^{k-1} r_1) \le \gamma^{k-1} \omega(R) + \frac{\sigma(r_1)}{1-\gamma} \le \frac{1}{\gamma} \left( \frac{r}{r_1} \right)^{\frac{\log \gamma}{\log \tau}} \omega(R) + \frac{\sigma(r_1)}{1-\gamma}.
$$

Now let $r_1 = r^{\mu} R^{1-\mu}$. We obtain

$$
\omega(r) \le \frac{1}{\gamma} \left( \frac{r}{R} \right)^{(1-\mu) \frac{\log \gamma}{\log \tau}} \omega(R) + \frac{\sigma(r^{\mu} R^{1-\mu})}{1-\gamma}.
$$

This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAdCAIAAAA2M5tmAAAAcElEQVR4nO3VMQ7AIAgF0E/j6CEdPY6jR2DjDp7JWZya2HbEoSb8DYcXiCSQqmJ3ru3iUWhYi9ZarXWMYRFjjNAlKSVTh3ce4/feATCzGvJGd63XOb/vqKOOOuroj9HwfSqliIhJXQ9hztlkAQCIaAKxa2v4zfL31wAAAABJRU5ErkJggg==)