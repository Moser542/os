LEMMA 6.5 Let $\varphi$ be a continuous function on $\partial\Omega$ and $u_\varphi$ be the function defined in (6.2). For some $x_0 \in \partial\Omega$, suppose $w_{x_0} \in C(\bar{\Omega})$ is a subharmonic function in $\Omega$ such that

$$
(6.3) \qquad w_{x_0}(x_0) = 0, \quad w_{x_0}(x) < 0 \text{ for any } x \in \partial\Omega \setminus \{x_0\}; \\ \text{then}
$$

$$
\lim_{x \to x_0} u_\varphi(x) = \varphi(x_0).
$$

PROOF: As in the proof of Lemma 6.4, we set

$$
S_\varphi = \{v : v \in C(\bar{\Omega}) \text{ is subharmonic in } \Omega \text{ and } v \le \varphi \text{ on } \partial\Omega\}.
$$

We simply write $w = w_{x_0}$ and set $M = \max_{\partial\Omega} |\varphi|$.

Let $\varepsilon$ be an arbitrary positive constant. By the continuity of $\varphi$ at $x_0$, there exists a positive constant $\delta$ such that

$$
|\varphi(x) - \varphi(x_0)| \le \varepsilon
$$

for any $x \in \partial\Omega \cap B_\delta(x_0)$. We then choose $K$ sufficiently large so that

$$
-Kw(x) \ge 2M
$$

for any $x \in \partial\Omega \setminus B_\delta(x_0)$; hence,

$$
|\varphi - \varphi(x_0)| \le \varepsilon - Kw \quad \text{on } \partial\Omega.
$$

Since $\varphi(x_0) - \varepsilon + Kw(x)$ is a subharmonic function in $\Omega$ with $\varphi(x_0) - \varepsilon + Kw \le \varphi$ on $\partial\Omega$, we have $\varphi(x_0) - \varepsilon + Kw \in S_\varphi$. The definition of $u_\varphi$ implies

$$
\varphi(x_0) - \varepsilon + Kw \le u_\varphi \quad \text{in } \Omega.
$$

On the other hand, $\varphi(x_0) + \varepsilon - Kw$ is a superharmonic in $\Omega$ with $\varphi(x_0) + \varepsilon - Kw \ge \varphi$ on $\Omega$. Hence for any $v \in S_\varphi$, we obtain by Lemma 6.2

$$
v \le \varphi(x_0) + \varepsilon - Kw \quad \text{in } \Omega.
$$

Again by the definition of $u_\varphi$, we have

$$
u_\varphi \le \varphi(x_0) + \varepsilon - Kw \quad \text{in } \Omega.
$$

Therefore,

$$
|u_\varphi - \varphi(x_0)| \le \varepsilon - Kw \quad \text{in } \Omega,
$$

which implies

$$
\limsup_{x \to x_0} |u_\varphi(x) - \varphi(x_0)| \le \varepsilon.
$$

We obtain the desired result by letting $\varepsilon \to 0$. $\square$

The function $w_{x_0}$ satisfying (6.3) is often called a *barrier function*. Barrier functions can be constructed for a large class of domains $\Omega$. Take, for example, the case where $\Omega$ satisfies an *exterior sphere condition* at $x_0 \in \partial\Omega$ in the sense that there exists a ball $B_{r_0}(y_0)$ such that

$$
\Omega \cap B_{r_0}(y_0) = \emptyset, \quad \bar{\Omega} \cap \bar{B}_{r_0}(y_0) = \{x_0\}.
$$

To construct a barrier function at $x_0$, we set

$$
w_{x_0}(x) = \Gamma(x - y_0) - \Gamma(x_0 - y_0) \quad \text{for any } x \in \bar{\Omega}
$$