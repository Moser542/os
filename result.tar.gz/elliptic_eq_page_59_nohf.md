The idea of the proof is to compare the solution $u$ with harmonic functions and use the perturbation argument.

LEMMA 3.10 (Basic Estimates for Harmonic Functions) Suppose $\{a_{ij}\}$ is a constant positive definite matrix with

$$
\lambda|\xi|^2 \le a_{ij}\xi_i\xi_j \le \Lambda|\xi|^2 \quad \text{for any } \xi \in \mathbb{R}^n
$$

for some $0 < \lambda \le \Lambda$. Suppose $w \in H^1(B_r(x_0))$ is a weak solution of

$$
(3.6) \qquad a_{ij} D_{ij} w = 0 \quad \text{in } B_r(x_0).
$$

Then for any $0 < \rho \le r$, there hold

$$
\int_{B_{\rho}(x_0)} |Dw|^2 \le c \left(\frac{\rho}{r}\right)^n \int_{B_r(x_0)} |Dw|^2,
$$

$$
\int_{B_{\rho}(x_0)} |Dw - (Dw)_{x_0, \rho}|^2 \le c \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Dw - (Dw)_{x_0, r}|^2,
$$

where $c = c(\lambda, \Lambda)$.

PROOF: Note that if $w$ is a solution of (3.6), so is any one of its derivatives. We may apply Lemma 1.41 to $Dw$. $\square$

COROLLARY 3.11 (Comparison with Harmonic Functions) Suppose $w$ is as in Lemma 3.10. Then for any $u \in H^1(B_r(x_0))$ there hold for any $0 < \rho \le r$

$$
\int_{B_{\rho}(x_0)} |Du|^2 \le c \left\{ \left(\frac{\rho}{r}\right)^n \int_{B_r(x_0)} |Du|^2 + \int_{B_r(x_0)} |D(u-w)|^2 \right\}
$$

and

$$
\int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le \left\{ \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + \int_{B_r(x_0)} |D(u-w)|^2 \right\}
$$

where $c$ is a positive constant depending only on $\lambda$ and $\Lambda$.