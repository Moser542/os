Hence one may prove (without using the mean value property)

$$
\sup_{B_{1/2}} |u| \le c \left( \int_{B_1} |u|^p \right)^{1/p} \quad \text{and} \quad \sup_{B_{1/2}} |Du| \le c \max_{B_1} |u|
$$

where $c$ is a constant depending only on $n$.

Now we begin to discuss the Green's functions. Suppose $\Omega$ is a bounded domain in $\mathbb{R}^n$. Let $u \in C^1(\bar{\Omega}) \cap C^2(\Omega)$. We have by Theorem 1.17 for any $x \in \Omega$

$$
u(x) = \int_{\Omega} \Gamma(x, y) \Delta u(y) dy - \int_{\partial \Omega} \left( \Gamma(x, y) \frac{\partial u}{\partial n_y}(y) - u(y) \frac{\partial \Gamma}{\partial n_y}(x, y) \right) dS_y.
$$

If $u$ solves the Dirichlet boundary value problem

$$
(*) \qquad \begin{cases} \Delta u = f & \text{in } \Omega, \\ u = \varphi & \text{on } \partial \Omega, \end{cases}
$$

for some $f \in C(\bar{\Omega})$ and $\varphi \in C(\partial\Omega)$, then $u$ can be expressed in terms of $f$ and $\varphi$, with one *unknown term*. We want to eliminate this term by adjusting $\Gamma$.

For any fixed $x \in \Omega$, consider

$$
\gamma(x, y) = \Gamma(x, y) + \Phi(x, y)
$$

for some $\Phi(x, \cdot) \in C^2(\bar{\Omega})$ with $\Delta_y \Phi(x, y) = 0$ in $\Omega$. Then Theorem 1.17 can be expressed as follows for any $x \in \Omega$

$$
u(x) = \int_{\Omega} \gamma(x, y) \Delta u(y) dy - \int_{\partial \Omega} \left( \gamma(x, y) \frac{\partial u}{\partial n_y}(y) - u(y) \frac{\partial \gamma}{\partial n_y}(x, y) \right) dS_y
$$

since the extra $\Phi(x, \cdot)$ is harmonic. Now by choosing $\Phi$ appropriately, we are led to the important concept of Green's function.

For each fixed $x \in \Omega$ choose $\Phi(x, \cdot) \in C^1(\bar{\Omega}) \cap C^2(\Omega)$ such that

$$
\begin{cases} \Delta_y \Phi(x, y) = 0 & \text{for } y \in \Omega, \\ \Phi(x, y) = -\Gamma(x, y) & \text{for } y \in \partial\Omega. \end{cases}
$$

Denote the resulting $\gamma(x, y)$ by $G(x, y)$, which is called Green's function. If such a $G$ exists, then the solution $u$ to the Dirichlet problem (*) can be expressed as

$$
u(x) = \int_{\Omega} G(x, y) f(y) dy + \int_{\partial \Omega} \varphi(y) \frac{\partial G}{\partial n_y}(x, y) dS_y.
$$

Note that Green's function $G(x, y)$ is defined as a function of $y \in \bar{\Omega}$ for each fixed $x \in \Omega$.

Now we discuss some properties of $G$ as a function of $x$ and $y$. Our first observation is that the Green's function is unique. This is proved by the maximum principle since the difference of two Green's functions are harmonic in $\Omega$ with zero boundary value. In fact, we have more.