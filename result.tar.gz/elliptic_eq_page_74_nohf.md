Therefore we have for $\ell = 0, 1, \dots$

$$
\begin{aligned}
\varphi(k_{\ell}, r_{\ell}) &\le C \left\{ \frac{2^{\ell}}{1-\tau} + \frac{2^{\ell}(k_0 + F + k)}{k} \right\} \frac{2^{\varepsilon\ell}}{k^{\varepsilon}} [\varphi(k_{\ell-1}, r_{\ell-1})]^{1+\varepsilon} \\
&\le \frac{C}{1-\tau} \cdot \frac{k_0 + F + k}{k^{1+\varepsilon}} \cdot 2^{(1+\varepsilon)\ell} \cdot [\varphi(k_{\ell-1}, r_{\ell-1})]^{1+\varepsilon}.
\end{aligned}
$$

Next we prove inductively for any $\ell = 0, 1, \dots$,

$$
(4.4) \qquad \varphi(k_{\ell}, r_{\ell}) \le \frac{\varphi(k_0, r_0)}{\gamma^{\ell}} \quad \text{for some } \gamma > 1
$$

if $k$ is sufficiently large. Obviously it is true for $\ell = 0$. Suppose it is true for $\ell - 1$. We write

$$
[\varphi(k_{\ell-1}, r_{\ell-1})]^{1+\varepsilon} \le \left\{ \frac{\varphi(k_0, r_0)}{\gamma^{\ell-1}} \right\}^{1+\varepsilon} = \frac{\varphi(k_0, r_0)^{\varepsilon}}{\gamma^{\ell\varepsilon-(1+\varepsilon)}} \cdot \frac{\varphi(k_0, r_0)}{\gamma^{\ell}}.
$$

Then we obtain

$$
\varphi(k_{\ell}, r_{\ell}) \le \frac{C\gamma^{1+\varepsilon}}{1-\tau} \cdot \frac{k_0 + F + k}{k^{1+\varepsilon}} \cdot [\varphi(k_0, r_0)]^{\varepsilon} \cdot \frac{2^{\ell(1+\varepsilon)}}{\gamma^{\ell\varepsilon}} \cdot \frac{\varphi(k_0, r_0)}{\gamma^{\ell}}.
$$

Choose $\gamma$ first such that $\gamma^\varepsilon = 2^{1+\varepsilon}$. Note $\gamma > 1$. Next, we need

$$
\frac{C\gamma^{1+\varepsilon}}{1-\tau} \cdot \left( \frac{\varphi(k_0, r_0)}{k} \right)^{\varepsilon} \cdot \frac{k_0 + F + k}{k} \le 1.
$$

Therefore we choose

$$
k = C_*\{k_0 + F + \varphi(k_0, r_0)\}
$$

for $C_*$ large. Let $\ell \to +\infty$ in (4.4). We conclude

$$
\varphi(k_0 + k, \tau) = 0.
$$

Hence we have

$$
\sup_{B_{1/2}} u^+ \le (C_* + 1)\{k_0 + F + \varphi(k_0, r_0)\}.
$$

Recall $k_0 = C \|u^+\|_{L^2(B_1)}$ and $\varphi(k_0, r_0) \le \|u^+\|_{L^2(B_1)}$. This finishes the proof. $\square$

Next we give the second proof of Theorem 4.1.

METHOD 2: MOSER'S APPROACH: First we explain the idea. By choosing the test function appropriately, we will estimate the $L^{p_1}$-norm of $u$ in a smaller ball by the $L^{p_2}$-norm of $u$ for $p_1 > p_2$ in a larger ball, that is,

$$
\|u\|_{L^{p_1}(B_{r_1})} \le C \|u\|_{L^{p_2}(B_{r_2})}
$$

for $p_1 > p_2$ and $r_1 < r_2$. This is a reversed Hölder inequality. As a sacrifice $C$ behaves like $\frac{1}{r_2-r_1}$. By iteration and a careful choice of $\{r_i\}$ and $\{p_i\}$, we will obtain the result.