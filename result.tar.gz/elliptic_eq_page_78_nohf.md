where

$$
\tilde{a}(y) = a(Ry), \quad \tilde{c}(y) = R^2 c(Ry), \quad \tilde{f}(y) = R^2 f(Ry),
$$

for any $y \in B_1$. Direct calculation shows

$$
|\tilde{a}_{ij}|_{L^{\infty}(B_1)} + \|\tilde{c}\|_{L^q(B_1)} = |a_{ij}|_{L^{\infty}(B_R)} + R^{2-\frac{n}{q}} \|c\|_{L^q(B_R)} \le \Lambda.
$$

We may apply what we just proved to $\tilde{u}$ in $B_1$ and rewrite the result in terms of $u$. Hence we obtain for $p \ge 2$

$$
\sup_{B_{R/2}} u^+ \le C \left\{ \frac{1}{R^{n/p}} \|u^+\|_{L^p(B_R)} + R^{2-\frac{n}{q}} \|f\|_{L^q(B_R)} \right\}
$$

where $C = C(n, \lambda, \Lambda, p, q)$ is a positive constant. The estimate in $B_{\theta R}$ can be obtained by applying the above result to $B_{(1-\theta)R}(y)$ for any $y \in B_{\theta R}$. Take $R = 1$. This is Theorem 4.1 for any $\theta \in (0, 1)$ and $p \ge 2$.

Now we prove the statement for $p \in (0, 2)$. We showed that for any $\theta \in (0, 1)$ and $0 < R \le 1$ there holds

$$
\begin{aligned} \|u^+\|_{L^{\infty}(B_{\theta R})} &\le C \left\{ \frac{1}{[(1-\theta)R]^{n/2}} \|u^+\|_{L^2(B_R)} + R^{2-\frac{n}{q}} \|f\|_{L^q(B_R)} \right\} \\ &\le C \left\{ \frac{1}{[(1-\theta)R]^{n/2}} \|u^+\|_{L^2(B_R)} + \|f\|_{L^q(B_1)} \right\}. \end{aligned}
$$

For $p \in (0, 2)$ we have

$$
\int_{B_R} (u^+)^2 \le \|u^+\|_{L^{\infty}(B_R)}^{2-p} \int_{B_R} (u^+)^p
$$

and hence by the Hölder inequality

$$
\begin{aligned} \|u^+\|_{L^{\infty}(B_{\theta R})} &\le C \left\{ \frac{1}{[(1-\theta)R]^{n/2}} \|u^+\|_{L^{\infty}(B_R)}^{1-p/2} \left( \int_{B_R} (u^+)^p dx \right)^{\frac{1}{2}} + \|f\|_{L^q(B_R)} \right\} \\ &\le \frac{1}{2} \|u^+\|_{L^{\infty}(B_R)} + C \left\{ \frac{1}{[(1-\theta)R]^{n/p}} \left( \int_{B_R} (u^+)^p \right)^{\frac{1}{p}} + \|f\|_{L^q(B_R)} \right\}. \end{aligned}
$$

Set $f(t) = \|u^+\|_{L^{\infty}(B_t)}$ for $t \in (0, 1]$. Then for any $0 < r < R \le 1$

$$
f(r) \le \frac{1}{2} f(R) + \frac{C}{(R-r)^{n/p}} \|u^+\|_{L^p(B_1)} + C \|f\|_{L^q(B_1)}.
$$

We apply the following lemma to get for any $0 < r < R < 1$

$$
f(r) \le \frac{C}{(R-r)^{\frac{n}{p}}} \|u^+\|_{L^p(B_1)} + C \|f\|_{L^q(B_1)}.
$$

Let $R \to 1^-$. We obtain for any $\theta < 1$

$$
\|u^+\|_{L^{\infty}(B_{\theta})} \le \frac{C}{(1-\theta)^{\frac{n}{p}}} \|u^+\|_{L^p(B_1)} + C \|f\|_{L^q(B_1)}.
$$

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAeCAIAAACwp+nIAAAAbUlEQVR4nO3WIQ7AIAyF4ZZwHBIkCadDcER6HHgTyxBkCjb3fkUQH8VVAcjXuc9Fon6ezCzGeC6mlARPrbVz8W79fq0VB5VSXtBfJiVKlChRokQ30rlLmVkIQVWd239pjAHAL7cAeu/7Q4rknC+XeWPQHJzRxwAAAABJRU5ErkJggg==)