We begin with a $g \in C(\partial\Omega)$ and let $u(x) = \mathcal{D}g(x)$ for $x \in \Omega$. It is clear from our previous discussion that $\Delta u = 0$ in $\Omega$ and $u \in C(\bar{\Omega})$; moreover, $u|_{\partial\Omega} = (\frac{1}{2}I+T)g$. Therefore, we need to solve for $g$ a given $f \in C(\partial\Omega)$, $f = (\frac{1}{2}I+T)g$. Since $T$ is compact, $(\frac{1}{2}I + T)$ is obviously a $1:1$ map on $C(\partial\Omega)$; hence it is also an onto map from $C(\partial\Omega)$ to $C(\partial\Omega)$. This last statement follows from the Leray-Schauder fixed-point theorem, which we will examine in the next section.

Finally, we shall state without proof the results corresponding to those for single-layer potentials (6.16). All of the proofs are similar to those for Lemmas 6.16 and 6.17 above.

Once again we assume $\partial\Omega$ to be class $C^2$ and $f \in C(\partial\Omega)$.

LEMMA 6.18 If $f \in C(\partial\Omega)$, then

$$
(i) \mathcal{D}_+ S(f) = \operatorname{grad} S(f) \in C(\overline{\Omega_{\delta_0}}) \text{ and}
$$

$$
(ii) \mathcal{D}_- S(f) = \operatorname{grad} S(f) \in C(\overline{\Omega_{\delta_0}^c}).
$$

Here $\overline{\Omega_{\delta_0}} = \{x \in \bar{\Omega} : \operatorname{dist}(x, \partial\Omega) \le \delta_0\}$ for some small $\delta_0 > 0$.

Let $K^*(P, Q) = K(Q, P)$ and define

$$
T^* f(P) = \int_{\partial\Omega} K^*(P, Q) f(Q) d\mathcal{H}^{n-1}(Q), \quad P \in \partial\Omega.
$$

LEMMA 6.19 (Jump Relations for $\mathcal{D}S(f)$)

$$
(i) \mathcal{D}_+ S(f) = -\frac{1}{2}I + T^* \text{ and}
$$

$$
(ii) \mathcal{D}_- S(f) = \frac{1}{2}I + T^*.
$$

Single-layer potentials can be used to solve the Neumann problem

$$
\begin{cases} \Delta u = 0 & \text{in } \Omega, \\ \frac{\partial u}{\partial n} = f & \text{on } \partial\Omega. \end{cases}
$$

Layer potentials can be used to solve more general elliptic equations (and systems) with constant coefficients on smooth domains. This method can be further generalized to $C^{1,\alpha}$-domains for general elliptic equations of second order with $C^\alpha$-coefficients (or general first-order elliptic systems with suitably smooth coefficients). The latter is often referred to as *ADN theory* due to Agmon, Douglis, and Nirenberg.*

## 6.6. Fixed-Point Theorems and Existence Results

The Brouwer fixed-point theorem asserts that a continuous mapping of a closed ball in $\mathbb{R}^n$ into itself has at least one fixed point. In this section we shall discuss a version of the fixed-point theorem in an infinite-dimensional Banach space due to Schauder and a special case of the Leray-Schauder theorem. As an application we shall discuss the existence of a class of quasi-linear elliptic equations for the

*Agmon, S.; Douglis, A.; Nirenberg, L. Estimates near the boundary for solutions of elliptic partial differential equations satisfying general boundary conditions. I, II. *Comm. Pure Appl. Math.* **12** (1959) 623–727; **17** (1964), 35–92.