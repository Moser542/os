Bibliography

[1] Berestycki, H., Nirenberg, L., and Varadhan, S. R. S. The principle eigenvalue and maximum principle for second-order elliptic operators in general domains. *Comm. Pure Appl. Math.* 47: 47–92, 1994.
[2] Caffarelli, L. A. Interior a priori estimates for solutions of fully nonlinear equations. *Ann. of Math.* 130: 189–213, 1989.
[3] Caffarelli, L. A. Interior $W^{2,p}$ estimates for solutions of the Monge-Ampère equation. *Ann. of Math.* 131: 135–150, 1990.
[4] Caffarelli, L. A., and Cabré, X. *Fully nonlinear elliptic equations*. AMS Colloquium Publications, 43. American Mathematical Society, Providence, R.I., 1995.
[5] Giaquinta, M. *Multiple integrals in the calculus of variations and nonlinear elliptic systems*. Annals of Mathematics Studies, 105. Princeton University Press, Princeton, N.J., 1983.
[6] Gidas, B., Ni, W. M., and Nirenberg, L. Symmetry and related properties via the maximum principle. *Comm. Math. Phys.* 68: 209–243, 1979.
[7] Gilbarg, D., and Serrin, J. On isolated singularities of solutions of second order elliptic differential equations. *J. Analyse Math.* 4: 309–340, 1955/56.
[8] Gilbarg, D., and Trudinger, N. S. *Elliptic partial differential equations of second order*. 2nd ed. Grundlehren der mathematischen Wissenschaften, 224. Springer, Berlin–New York, 1983.
[9] John, F. *Partial differential equations*. Reprint of the 4th ed. Applied Mathematical Sciences, 1, Springer, New York, 1991.
[10] John, F., and Nirenberg, L. On functions of bounded mean oscillation. *Comm. Pure Appl. Math.* 14: 415–426, 1961.
[11] Krylov, N. V. *Lectures on elliptic and parabolic partial differential equations in Hölder spaces*. Graduate Studies in Mathematics, 12. American Mathematical Society, Providence, R.I., 1996.
[12] Littman, W., Stampacchia, G., and Weinberger, H. F. Regular points for elliptic equations with discontinuous coefficients. *Ann. Scuola Norm. Sup. Pisa (3)* 17: 43–77, 1963.
[13] Protter, M. H., and Weinberger, H. F. *Maximum principles in differential equations*. Prentice-Hall, Englewood Cliffs, N.J., 1967.
[14] Serrin, J. A symmetry theorem in potential theory. *Arch. Rational Mech. Anal.* 43: 304–318, 1971.
[15] Stein, E. M. *Singular integrals and differentiability properties of functions*. Princeton Mathematical Series, 30. Princeton University Press, Princeton, N.J., 1970.