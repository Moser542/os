for $u \in C^2(\Omega) \cap C(\bar{\Omega})$. We assume that $a_{ij}, b_i$, and $c$ are continuous and hence bounded in $\bar{\Omega}$ and that $L$ is uniformly elliptic in $\Omega$, that is,

$$
a_{ij}(x)\xi_i\xi_j \geq \lambda|\xi|^2 \quad \text{for any } x \in \Omega \text{ and any } \xi \in \mathbb{R}^n
$$

where $\lambda$ is a positive number. We denote by $\Lambda$ the sup-norm of $a_{ij}$ and $b_i$, that is,

$$
\max_{\Omega} |a_{ij}| + \max_{\Omega} |b_i| \leq \Lambda.
$$

**PROPOSITION 2.15** Suppose $u \in C^2(\Omega) \cap C(\bar{\Omega})$ satisfies

$$
\begin{cases} Lu = f & \text{in } \Omega, \\ u = \varphi & \text{on } \partial\Omega, \end{cases}
$$

for some $f \in C(\bar{\Omega})$ and $\varphi \in C(\partial\Omega)$. If $c(x) \leq 0$, then there holds

$$
|u(x)| \leq \max_{\partial\Omega} |\varphi| + C \max_{\Omega} |f| \quad \text{for any } x \in \Omega
$$

where $C$ is a positive constant depending only on $\lambda$, $\Lambda$, and $\text{diam}(\Omega)$.

**PROOF:** We will construct a function $w$ in $\Omega$ such that

$$
(i) \quad L(w \pm u) = Lw \pm f \leq 0 \quad \text{or} \quad Lw \leq \mp f \quad \text{in } \Omega,
$$

$$
(ii) \quad w \pm u = w \pm \varphi \geq 0 \quad \text{or} \quad w \geq \mp \varphi \quad \text{on } \partial\Omega.
$$

Denote $F = \max_{\Omega} |f|$ and $\Phi = \max_{\partial\Omega} |\varphi|$. We need

$$
Lw \leq -F \quad \text{in } \Omega,
$$

$$
w \geq \Phi \quad \text{on } \partial\Omega.
$$

Suppose the domain $\Omega$ lies in the set $\{0 < x_1 < d\}$ for some $d > 0$. Set $w = \Phi + (e^{\alpha d} - e^{\alpha x_1})F$ with $\alpha > 0$ to be chosen later. Then we have by direct calculation

$$
\begin{aligned} -Lw &= (a_{11}\alpha^2 + b_1\alpha)Fe^{\alpha x_1} - c\Phi - c(e^{\alpha d} - e^{\alpha x_1})F \\ &\geq (a_{11}\alpha^2 + b_1\alpha)F \geq (\alpha^2\lambda + b_1\alpha)F \geq F \end{aligned}
$$

by choosing $\alpha$ large such that $\alpha^2\lambda + b_1(x)\alpha \geq 1$ for any $x \in \Omega$. Hence $w$ satisfies (i) and (ii). By Corollary 2.8 (the comparison principle) we conclude $-w \leq u \leq w$ in $\Omega$; in particular,

$$
\sup_{\Omega} |u| \leq \Phi + (e^{\alpha d} - 1)F
$$

where $\alpha$ is a positive constant depending only on $\lambda$ and $\Lambda$. $\square$

**PROPOSITION 2.16** Suppose $u \in C^2(\Omega) \cap C^1(\bar{\Omega})$ satisfies

$$
\begin{cases} Lu = f & \text{in } \Omega, \\ \frac{\partial u}{\partial n} + \alpha(x)u = \varphi & \text{on } \partial\Omega, \end{cases}
$$

where $\mathbf{n}$ is the outward normal direction to $\partial\Omega$. If $c(x) \leq 0$ in $\Omega$ and $\alpha(x) \geq \alpha_0 > 0$ on $\partial\Omega$, then there holds

$$
|u(x)| \leq C \left\{ \max_{\partial\Omega} |\varphi| + \max_{\Omega} |f| \right\} \quad \text{for any } x \in \Omega
$$