Hence $Du \in C_{\text{loc}}^{\alpha-\delta}$ for any $\delta > 0$ small. In particular, $Du \in L_{\text{loc}}^{\infty}$ and there holds

$$
(3.17) \qquad \sup_{B_{3/4}} |Du|^2 \le C\{\chi(F) + \|Du\|_{L^2(B_1)}^2\}.
$$

By combining (3.15) and (3.17), there holds for $0 < \rho < r \le r_1$ and any $x_0 \in B_{1/2}$

$$
\int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le C \left\{ \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + r^{n+2\alpha} [\chi(F) + \|Du\|_{L^2(B_1)}^2] \right\}.
$$

By Lemma 3.4 again, this implies

$$
\int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le C \left\{ \left(\frac{\rho}{r}\right)^{n+2\alpha} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + \rho^{n+2\alpha} [\chi(F) + \|Du\|_{L^2(B_1)}^2] \right\}.
$$

Choose $r = r_1$. We have for any $x_0 \in B_{1/2}$ and $r \le r_1$

$$
\int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 \le c r^{n+2\alpha} \{\chi(F) + \|Du\|_{L^2(B_1)}^2\}.
$$

### CASE 3. General case.

By (3.12) and (3.13) we have for any $B_r(x_0) \subset B_1$ and $\rho < r$

$$
(3.18) \qquad \int_{B_{\rho}(x_0)} |Du|^2 \le C \left\{ \left[ \left(\frac{\rho}{r}\right)^n + r^{2\alpha} \right] \int_{B_r(x_0)} |Du|^2 + \int_{B_r(x_0)} u^2 + r^{n+2\alpha} \chi(F) \right\}
$$

and

$$
(3.19) \qquad \int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le C \left\{ \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + r^{2\alpha} \left[ \int_{B_r(x_0)} u^2 + \int_{B_r(x_0)} |Du|^2 \right] + r^{n+2\alpha} \chi(F) \right\}
$$

where $\chi(F) = \|f\|_{L^q(B_1)}^2$.