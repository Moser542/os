$\frac{u}{w}$ assumes its nonnegative maximum at $x_0 \in \partial\Omega$ and $\frac{u}{w} \neq$ const, then for any outward direction $\mathbf{v}$ at $x_0$ to $\partial\Omega$ there holds

$$
\frac{\partial}{\partial \mathbf{v}} \left( \frac{u}{w} \right) (x_0) > 0
$$

if $\partial\Omega$ has the interior sphere property at $x_0$.

PROOF: Set $\mathbf{v} = \frac{u}{w}$. Then $\mathbf{v}$ satisfies

$$
a_{ij} D_{ij} \mathbf{v} + B_i D_i \mathbf{v} + \left( \frac{Lw}{w} \right) \mathbf{v} \geq 0
$$

where $B_i = b_i + \frac{2}{w}a_{ij}D_{ij}w$. We may apply Theorem 2.7 and Corollary 2.9 to $\mathbf{v}$. $\square$

REMARK 2.12. If the operator $L$ in $\Omega$ satisfies the condition of Theorem 2.11, then the comparison principle applies to $L$. In particular, the Dirichlet boundary value problem

$$
\begin{aligned} Lu &= f & \text{in } \Omega, \\ u &= \varphi & \text{on } \partial\Omega, \end{aligned}
$$

has at most one solution.

The next result is the so-called maximum principle for a *narrow domain*.

PROPOSITION 2.13 Let $d$ be a positive number and $\mathbf{e}$ be a unit vector such that $|(y - x) \cdot \mathbf{e}| < d$ for any $x, y \in \Omega$. Then there exists a $d_0 > 0$, depending only on $\lambda$ and the sup-norm of $b_i$ and $c^+$, such that the assumptions of Theorem 2.11 are satisfied if $d \le d_0$.

PROOF: By choosing $\mathbf{e} = (1, 0, \dots, 0)$ we suppose $\bar{\Omega}$ lies in $\{0 < x_1 < d\}$. Assume in addition $|b_i|, c^+ \le N$ for some positive constant $N$. We construct $w$ as follows. Set $w = e^{\alpha d} - e^{\alpha x_1} > 0$ in $\bar{\Omega}$. By direct calculation we have

$$
Lw = -(a_{11}\alpha^2 + b_1\alpha)e^{\alpha x_1} + c(e^{\alpha d} - e^{\alpha x_1}) \leq -(a_{11}\alpha^2 + b_1\alpha) + Ne^{\alpha d}.
$$

Choose $\alpha$ so large that

$$
a_{11}\alpha^2 + b_1\alpha \geq \lambda\alpha^2 - N\alpha \geq 2N.
$$

Hence $Lw \le -2N + Ne^{\alpha d} = N(e^{\alpha d} - 2) \le 0$ if $d$ is small such that $e^{\alpha d} \le 2$. $\square$

REMARK 2.14. Some results in this section, including Proposition 2.13, hold for unbounded domain. Compare Proposition 2.13 with Theorem 2.32.

## 2.3. A Priori Estimates

In this section we derive a priori estimates for solutions to the Dirichlet problem and the Neumann problem.

Suppose $\Omega$ is a bounded and connected domain in $\mathbb{R}^n$. Consider the operator $L$ in $\Omega$

$$
Lu \equiv a_{ij}(x)D_{ij}u + b_i(x)D_i u + c(x)u
$$