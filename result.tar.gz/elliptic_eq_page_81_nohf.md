Hence $\beta$ is required to be bounded, depending only on $n$ and $q$. Then we obtain

$$
\left( \int \eta^{2\chi} \bar{u}_m^{\beta\chi} \bar{u}^{2\chi} \right)^{1/\chi} \le C \left\{ \int (|D\eta|^2 + \eta^2) \bar{u}_m^{\beta} \bar{u}^2 + \|f\|_{L^q}^{\beta+2} \right\}.
$$

By setting $\gamma = \beta + 2$, we have by definition of $q^*$

$$
(4.5) \qquad 2 \le \gamma \le \frac{q(n-2)}{n-2q} = \frac{q^*}{\chi}.
$$

We conclude, as before, for any such $\gamma$ in (4.5) and any $0 < r < R \le 1$

$$
(4.6) \qquad \|\bar{u}\|_{L^{\chi\gamma}(B_r)} \le C \left\{ \frac{1}{(R-r)^{2/\gamma}} \|\bar{u}\|_{L^{\gamma}(B_R)} + \|f\|_{L^q(B_1)} \right\}
$$

provided $\|\bar{u}\|_{L^{\gamma}(B_R)} < +\infty$. Again this suggests the iteration $2, 2\chi, 2\chi^2, \dots$

For given $q \in [\frac{2n}{n+2}, \frac{n}{2})$, there exists a positive integer $k$ such that

$$
2\chi^{k-1} \le \frac{q(n-2)}{n-2q} < 2\chi^k.
$$

Hence for such $k$ we get by finitely many iterations of (4.6)

$$
\|\bar{u}\|_{L^{2\chi^k}(B_{3/4})} \le C\{\|\bar{u}\|_{L^2(B_1)} + \|f\|_{L^q(B_1)}\};
$$

in particular,

$$
\|\bar{u}\|_{L^{\frac{q^*}{\chi}}(B_{3/4})} \le C\{\|\bar{u}\|_{L^2(B_1)} + \|f\|_{L^q(B_1)}\},
$$

while with $\gamma = q^*/\chi$ in (4.6) we obtain

$$
\|\bar{u}\|_{L^{q^*}(B_{1/2})} \le C\{\|\bar{u}\|_{L^{q^*/\chi}(B_{3/4})} + \|f\|_{L^q(B_1)}\}.
$$

This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAiCAIAAADH6v4jAAAAoUlEQVR4nO2WsQkEIRBF/+j1YboV2IQVGdqB5WlqB+YOs8FesHgbrXgg+DKThzwEP4kI5qAmebf6r+pPd2bmcanWGgDkRkpp3AvAWisiU9QASikPrUMIbQDvPYBaa98agNb6G+sVSikAzDzrhbTWFlTvIB07SMcO0rFmkDVvvYP8qum+VHPOx3EQ0fW/veNaMjHGh29XRAaHjjHGOUdL7usTsxy6a1y63uYAAAAASUVORK5CYII=)

### 4.3. Hölder Continuity

We first discuss homogeneous equations with no lower-order terms. Consider

$$
Lu \equiv -D_i(a_{ij}(x)D_j u) \quad \text{in } B_1(0) \subset \mathbb{R}^n
$$

where $a_{ij} \in L^\infty(B_1)$ satisfies

$$
\lambda|\xi|^2 \le a_{ij}(x)\xi_i\xi_j \le \Lambda|\xi|^2 \quad \text{for all } x \in B_1(0) \text{ and } \xi \in \mathbb{R}^n
$$

for some positive constants $\lambda$ and $\Lambda$.

**DEFINITION 4.5** The function $u \in H_{\text{loc}}^1(B_1)$ is called a *subsolution (supersolution)* of the equation $Lu = 0$ if

$$
\int_{B_1} a_{ij} D_i u D_j \varphi \le 0 \ (\ge 0) \quad \text{for all } \varphi \in H_0^1(B_1) \text{ and } \varphi \ge 0.
$$

**LEMMA 4.6** Let $\Phi \in C_{\text{loc}}^{0,1}(\mathbb{R})$ be convex. Then:

(i) If $u$ is a subsolution and $\Phi' \ge 0$, then $v = \Phi(u)$ is also a subsolution provided $v \in H_{\text{loc}}^1(B_1)$.