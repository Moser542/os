## 6.5. Single- and Double-Layer Potentials Methods

We begin with the Dirichlet problem for a half-space:

$$
(6.10) \qquad \begin{cases} \Delta u = 0 & \text{in } \mathbb{R}_+^{n+1} = \{x \in \mathbb{R}^{n+1} : x_{n+1} > 0\}, \\ u = f & \text{on } \partial \mathbb{R}_+^{n+1} = \mathbb{R}^n \times \{\underline{0}\}. \end{cases}
$$

Using the Poisson integral formula, we can represent a solution as

$$
(6.11) \qquad u(x, y) = P_y * f(x), \quad (x, y) \in \mathbb{R}_+^{n+1} = \mathbb{R}^n \times \mathbb{R}_+,
$$

where

$$
P_y(x) = \frac{\Gamma(\frac{n+1}{2})}{\pi^{\frac{n+1}{2}}} \frac{y}{(|x|^2 + |y|^2)^{\frac{n+1}{2}}}, \quad f \in C_0(\mathbb{R}^{n+1}).
$$

The estimates for convolutions imply that

$$
(6.12) \qquad \sup_{y>0} \|u(\cdot, y)\|_{L^p(\mathbb{R}^n)} \le \|f\|_{L^p(\mathbb{R}^n)} \quad \text{for all } 1 \le p \le \infty.
$$

(Note that for $p = +\infty$, (6.12) is also a consequence of the maximum principle; and for $p = 1$, $\|u(\cdot, y)\|_{L^1(\mathbb{R}^n)} \le \|P_y\|_{L^1(\mathbb{R}^n)} \cdot \|f\|_{L^1(\mathbb{R}^n)} = \|f\|_{L^1(\mathbb{R}^n)}$.)

We can also reverse the implication of (6.12) in the following sense (via Fa-tou's theorem): if a harmonic function $u$ in $\mathbb{R}_+^{n+1}$ satisfies (6.12), then $u$ has a nontangential limit a.e. on $\partial \mathbb{R}_+^{n+1}$, and the limit function $u_0 = u(\cdot, 0) \in L^p(\mathbb{R}^n)$ (if $p > 1$; if $p = 1$, then $u_0$ is a Radon measure) with $u(x, y) = P_y * u_0(x)$.

SKETCH OF PROOF: (See [15] for details.) Suppose $u$ is harmonic in $\mathbb{R}_+^{n+1}$ with

$$
(6.13) \qquad \sup_{y>0} \|u(\cdot, y)\|_{L^p(\mathbb{R}^n)} < \infty.
$$

Note $u(x, y+\rho) = P_y * u_\rho(x)$ where $u_\rho(x) = u(x, \rho)$, $y > 0$, $\rho > 0$. Statement (6.13) implies that $u_{\rho_n} \to v$ in $L^p(\mathbb{R}^n)$ for a sequence of $\rho_n \downarrow 0$. It is then easy to see that $P_y * u_{\rho_n}(x) \to P_y * v(x)$ for all $y > 0$ as $\rho_n \to 0^+$.

On the other hand, $P_y * u_{\rho_n}(x) = u(x, y + \rho_n)$. Thus $P_y * v(x) = u(x, y)$ where $v \in L^p(\mathbb{R}^n)$, and when $p = 1$ we naturally replace $v$ by a Radon measure.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAeCAIAAACwp+nIAAAAbUlEQVR4nO3WIQ7AIAyF4ZZwHBIkCadDcER6HHgTyxBkCjb3fkUQH8VVAcjXuc9Fon6ezCzGeC6mlARPrbVz8W79fq0VB5VSXtBfJiVKlChRokQ30rlLmVkIQVWd239pjAHAL7cAeu/7Q4rknC+XeWPQHJzRxwAAAABJRU5ErkJggg==)

Now we assume that $\Omega$ is a bounded, connected domain in $\mathbb{R}^n$, $n \ge 3$, with a $C^2$-boundary. (Here we assume $n \ne 2$ to simplify matters and avoid technicalities.) Consider the Dirichlet problem

$$
(6.14) \qquad \begin{cases} \Delta u = 0 & \text{in } \Omega, \\ u|_{\partial \Omega} = f & \in C(\partial \Omega). \end{cases}
$$

Let $\gamma(x) = \frac{C_n}{|x|^{n-2}}$ be the fundamental solution of the Laplace operator in $\mathbb{R}^n$; here

$$
C_n = -\frac{1}{(n-2)\omega_n} = \frac{-1}{(n-2)} \frac{\Gamma(\frac{n}{2})}{2\pi^{n/2}}.
$$