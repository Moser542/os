PROOF: We only need to prove $Du \in L_{\text{loc}}^{\infty}$. Then the Hölder continuity is implied by Theorem 3.13. For any $B_r(x_0) \subset B_1$ solve for $w$ such that

$$
\int_{B_r(x_0)} a_{ij}(x_0) D_i w D_j \varphi = 0 \quad \text{for any } \varphi \in H_0^1(B_r(x_0))
$$

with $w - u \in H_0^1(B_r(x_0))$. Then the maximum principle implies

$$
\inf_{B_r(x_0)} u \le w \le \sup_{B_r(x_0)} u \quad \text{in } B_r(x_0)
$$

or

$$
(4.17) \qquad \sup_{B_r(x_0)} |u - w| \le \operatorname{osc}_{B_r(x_0)} u.
$$

By Lemma 3.10, we have for any $0 < \rho \le r$,

$$
(4.18) \qquad \int_{B_{\rho}(x_0)} |Du|^2 \le c \left\{ \left(\frac{\rho}{r}\right)^n \int_{B_r(x_0)} |Du|^2 + \int_{B_r(x_0)} |D(u-w)|^2 \right\}
$$

and

$$
(4.19) \qquad \int_{B_{\rho}(x_0)} |Du - (Du)_{x_0, \rho}|^2 \le c \left\{ \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r(x_0)} |Du - (Du)_{x_0, r}|^2 + \int_{B_r(x_0)} |D(u-w)|^2 \right\}.
$$

Note that the function $v = u - w \in H_0^1(B_r(x_0))$ satisfies

$$
\int_{B_r(x_0)} a_{ij}(x_0) D_i v D_j \varphi = \int_{B_r(x_0)} b(x, u, Du) \varphi \\ + \int_{B_r(x_0)} (a_{ij}(x_0) - a_{ij}(x)) D_i u D_j \varphi, \\ \varphi \in H_0^1(B_r(x_0)) \cap L^\infty(B_r(x_0)).
$$

Taking $\varphi = v$ and using the Sobolev inequality we obtain

$$
\int_{B_r(x_0)} |Dv|^2 \le C \left\{ \int_{B_r(x_0)} |Du|^2 |v| + r^{2\alpha} \int_{B_r(x_0)} |Du|^2 + r^{n+2\alpha} \|f\|_{L^q(B_1)}^2 \right\}.
$$

Hence with (4.17) we conclude

$$
(4.20) \qquad \int_{B_r(x_0)} |Dv|^2 \le C \left\{ (r^{2\alpha} + \operatorname{osc}_{B_r(x_0)} u) \int_{B_r(x_0)} |Du|^2 + r^{n+2\alpha} \|f\|_{L^q}^2 \right\}.
$$