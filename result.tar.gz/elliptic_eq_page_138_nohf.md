THEOREM 6.13 Let $\Omega$ be a bounded $C^{2,\alpha}$-domain in $\mathbb{R}^n$ and $f$ be a $C^1$-function in $\bar{\Omega} \times \mathbb{R}$. Suppose $\underline{u}, \bar{u} \in C^{2,\alpha}(\bar{\Omega})$ satisfy $\underline{u} \le \bar{u}$,

$$
\Delta \underline{u} \ge f(x, \underline{u}) \text{ in } \Omega, \quad \underline{u} \le 0 \text{ on } \partial\Omega,
$$

$$
\Delta \bar{u} \le f(x, \bar{u}) \text{ in } \Omega, \quad \bar{u} \ge 0 \text{ on } \partial\Omega.
$$

Then there exists a solution $u \in C^{2,\alpha}(\bar{\Omega})$ of

$$
\Delta u = f(x, u) \text{ in } \Omega, \quad u = 0 \text{ on } \partial\Omega, \quad \underline{u} \le u \le \bar{u} \text{ in } \Omega.
$$

We note that $\underline{u}$ and $\bar{u}$ are subsolutions and supersolutions, respectively.

PROOF: Set

$$
m = \inf_{\Omega} \underline{u}, \quad M = \sup_{\Omega} \bar{u}.
$$

We take $\lambda > 0$ large so that

$$
\lambda > f_z(x, z) \quad \text{for any } (x, z) \in \bar{\Omega} \times [m, M].
$$

Now we write $u_0 = \underline{u}$. For any $u_k, k = 0, 1, \dots$, we suppose $u_{k+1} \in C^{2,\alpha}(\bar{\Omega})$ solve

$$
(6.9) \qquad \begin{aligned} \Delta u_{k+1} - \lambda u_{k+1} &= f(x, u_k) - \lambda u_k \quad \text{in } \Omega, \\ u_{k+1} &= 0 \quad \text{on } \partial\Omega. \end{aligned}
$$

We first prove

$$
\underline{u} \le u_k \le \bar{u} \quad \text{in } \Omega.
$$

This is obviously true for $k = 0$. Suppose it holds for some $k \ge 0$. We now consider $u_{k+1}$. First, we note

$$
\Delta(u_{k+1} - \underline{u}) - \lambda(u_{k+1} - \underline{u}) \le (f(x, u_k) - f(x, \underline{u})) - \lambda(u_k - \underline{u}).
$$

By the mean value theorem, we have

$$
(f(x, u_k) - f(x, \underline{u})) - \lambda(u_k - \underline{u}) = -(\lambda - f_z(x, \theta))(u_k - \underline{u})
$$

where $\theta$ is between $u_k(x)$ and $\underline{u}(x)$. Therefore, we obtain

$$
\begin{aligned} \Delta(u_{k+1} - \underline{u}) - \lambda(u_{k+1} - \underline{u}) &\le 0 \quad \text{in } \Omega, \\ u_{k+1} - \underline{u} &\ge 0 \quad \text{on } \partial\Omega. \end{aligned}
$$

By the maximum principle, we have $u_{k+1} \ge \underline{u}$ in $\Omega$. Similarly, we have $u_{k+1} \le \bar{u}$ in $\Omega$. In particular, we have

$$
m \le u_k(x) \le M \quad \text{for any } x \in \Omega \text{ and } k = 0, 1, \dots
$$

Similarly, we can prove

$$
\underline{u} \le u_1 \le u_2 \le \dots \le \bar{u}.
$$

In other words, $\{u_k\}$ is an increasing sequence. Therefore, there exists a function $u$ in $\Omega$ such that $u_k(x) \to u(x)$ as $k \to \infty$ for each $x \in \Omega$.

Next, the right-hand side expression in (6.9) is uniformly bounded independent of $k$. By the global $C^{1,\alpha}$-estimate, we have

$$
\|u_k\|_{C^{1,\alpha}(\bar{\Omega})} \le C
$$