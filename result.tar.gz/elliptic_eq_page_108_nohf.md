Set $w = u + g$ in $B_{2\sqrt{n}}$. We will show by choosing $\beta$ large that

$$
(5.5) \qquad w \in S^+(\lambda, \Lambda, f) \quad \text{in } B_{2\sqrt{n}} \setminus Q_1.
$$

Suppose $\varphi$ is a quadratic polynomial with the property that $w - \varphi$ has a local minimum at $x_0 \in B_{2\sqrt{n}}$. Then $u - (\varphi - g)$ has a local minimum at $x_0 \in B_{2\sqrt{n}}$. By definitions of $S^+(\lambda, \Lambda, f)$ and the Pucci extremal operator $\mathcal{M}^-$ we have

$$
\mathcal{M}^{-}(\lambda, \Lambda, D^2\varphi(x_0) - D^2g(x_0)) \leq f(x_0)
$$

or

$$
\mathcal{M}^{-}(\lambda, \Lambda, D^2\varphi(x_0)) + \mathcal{M}^{-}(\lambda, \Lambda, -D^2g(x_0)) \leq f(x_0)
$$

where we used the property of $\mathcal{M}^-$. We will choose $\beta$ large such that

$$
\mathcal{M}^{-}(\lambda, \Lambda, -D^2g(x_0)) \geq 0 \quad \text{for any } x_0 \in B_{2\sqrt{n}} \setminus B_{1/4}.
$$

We need to calculate the Hessian matrix of $g$. Note

$$
D_{ij}g(x) = \frac{M}{2n} \beta \left(1 - \frac{|x|^2}{4n}\right)^{\beta-1} \delta_{ij} - \frac{M}{(2n)^2} \beta(\beta-1) \left(1 - \frac{|x|^2}{4n}\right)^{\beta-2} x_i x_j.
$$

If we choose $x = (|x|, 0, \dots, 0)$ then the eigenvalues of $-D^2g(x)$ are given by

$$
\frac{M}{2n} \beta \left(1 - \frac{|x|^2}{4n}\right)^{\beta-2} \left(\frac{2\beta - 1}{4n} |x|^2 - 1\right) \quad \text{with multiplicity 1,} \\ -\frac{M}{2n} \beta \left(1 - \frac{|x|^2}{4n}\right)^{\beta-1} \quad \text{with multiplicity } n-1.
$$

We choose $\beta$ large such that for $|x| \ge \frac{1}{4}$ the first eigenvalue is positive and the rest negative, denoted by $e^+(x)$ and $e^-(x)$, respectively. Therefore for $|x| \ge \frac{1}{4}$ we have

$$
\begin{aligned} \mathcal{M}^{-}(\lambda, \Lambda, -D^2g(x)) \\ &= \lambda e^{+}(x) + (n-1)\Lambda e^{-}(x) \\ &= \frac{M}{2n} \beta \left(1 - \frac{|x|^2}{4n}\right)^{\beta-2} \left\{ \lambda \left(\frac{2\beta - 1}{4n} |x|^2 - 1\right) - (n-1)\Lambda \left(1 - \frac{|x|^2}{4n}\right) \right\} \\ &\ge 0 \end{aligned}
$$

if we choose $\beta$ large, depending only on $n$, $\lambda$, and $\Lambda$. This finishes the proof of (5.5). In fact, we obtain

$$
w \in S^+(\lambda, \Lambda, f + \eta) \quad \text{in } B_{2\sqrt{n}}
$$

for some $\eta \in C_0^\infty(Q_1)$ and $0 \le \eta \le C(n, \lambda, \Lambda)$.