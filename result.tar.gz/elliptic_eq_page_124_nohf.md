In fact, we have

$$
\begin{aligned}
\sum_{k \ge 1} M^{pk} \alpha_k &\le \sum_{k \ge 1} (\varepsilon_0 M^p)^k + \sum_{k \ge 1} \sum_{i=0}^{k-1} \varepsilon_0^{k-i} M^{p(k-i)} M^{pi} \beta_i \\
&\le \sum_{k \ge 1} 2^{-k} + \left( \sum_{i \ge 0} M^{pi} \beta_i \right) \left( \sum_{j \ge 1} 2^{-j} \right) \le C.
\end{aligned}
$$

This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAhCAIAAACqSTeOAAAAlUlEQVR4nO3WrQ0EIRAF4MdlE4qgAzRt4ZEIiqEFelgHFSCROAxz4v6SVZcjiEvmKTBfJs/MCCLChtx2oOz+rXu8X713a+0YY4UTQmitnXOgV0opy1M+k1K69hBCoIV47wGc57ml3znnFpeI2AX3yy677LL7RY7LP8aYc/6Zeyx1pdRnz9dapZRLQwIAjDGtNbHp/r0D9VCtCRzrpBEAAAAASUVORK5CYII=)

5.6. Global Estimates

In the previous two sections, we derived interior Schauder estimates and $W^{2,p}$-estimates for viscosity solutions. In fact, these estimates hold globally. In this section, we state these results without proof for classical solutions of Dirichlet problems for general linear elliptic equations. These results will be needed in the next chapter.

Let $\Omega$ be a bounded domain in $\mathbb{R}^n$, $a_{ij}$ be continuous functions in $\Omega$, and $b_i$ and $c$ be bounded functions in $\Omega$. For some bounded function $f$ in $\Omega$ and continuous function $\varphi$ on $\partial\Omega$, consider

$$
(5.29) \qquad \begin{aligned} a_{ij} D_{ij} u + b_i D_i u + c u &= f \quad \text{in } \Omega, \\ u &= \varphi \quad \text{on } \partial \Omega. \end{aligned}
$$

We always assume

$$
a_{ij}(x)\xi_i\xi_j \ge \lambda|\xi|^2 \quad \text{for any } x \in \Omega \text{ and } \xi \in \mathbb{R}^n
$$

for some constant $\lambda > 0$. In the following, we may require that $\varphi$ be defined in $\Omega$.
We first state the global Schauder estimate.

THEOREM 5.26 For some constant $\alpha \in (0, 1)$, let $\Omega$ be a bounded $C^{2,\alpha}$-domain in $\mathbb{R}^n$, and $a_{ij}$, $b_i$, and $c$ be $C^\alpha(\bar{\Omega})$-functions. Suppose $u \in C^{2,\alpha}(\bar{\Omega})$ is a solution of (5.29) for some $f \in C^\alpha(\bar{\Omega})$ and $\varphi \in C^{2,\alpha}(\bar{\Omega})$. Then

$$
\|u\|_{C^{2,\alpha}(\bar{\Omega})} \le C\{\|u\|_{L^{\infty}(\Omega)} + \|f\|_{C^{\alpha}(\bar{\Omega})} + \|\varphi\|_{C^{2,\alpha}(\bar{\Omega})}\},
$$

where $C$ is a positive constant depending only on $n, \alpha, \lambda, \Omega$, and the $C^\alpha(\bar{\Omega})$-norms of $a_{ij}$, $b_i$, and $c$.

Next, we state the global $W^{2,p}$-estimate.

THEOREM 5.27 Let $\Omega$ be a bounded $C^{1,1}$-domain in $\mathbb{R}^n$, $a_{ij}$ be continuous functions in $\Omega$, and $b_i$ and $c$ be bounded functions in $\Omega$. For some constant $p > 1$, suppose $u \in W^{2,p}(\Omega)$ is a solution of (5.29) for some $f \in L^p(\Omega)$ and $\varphi \in W^{2,p}(\Omega)$. Then

$$
\|u\|_{W^{2,p}(\Omega)} \le C\{\|u\|_{L^p(\Omega)} + \|f\|_{L^p(\Omega)} + \|\varphi\|_{W^{2,p}(\Omega)}\},
$$

where $C$ is a positive constant depending only on $n, p, \lambda, \Omega$, the moduli of continuity of $a_{ij}$, and the $L^\infty(\Omega)$-norms of $a_{ij}$, $b_i$, and $c$.

By Sobolev embedding, we have the following result on $C^{1,\alpha}$-norms.