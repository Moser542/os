COROLLARY 5.28 Let $\Omega$ be a bounded $C^{1,1}$-domain in $\mathbb{R}^n$, $a_{ij}$ be continuous functions in $\Omega$, and $b_i, c$ be bounded functions in $\Omega$. For some constant $p > n$, suppose $u \in W^{2,p}(\Omega)$ is a solution of (5.29) for some $f \in L^p(\Omega)$ and $\varphi \in W^{2,p}(\Omega)$. Then

$$
\|u\|_{C^{1,1-\frac{n}{p}}(\Omega)} \le C\{\|u\|_{L^p(\Omega)} + \|f\|_{L^p(\Omega)} + \|\varphi\|_{W^{2,p}(\Omega)}\},
$$

where $C$ is a positive constant depending only on $n, p, \lambda, \Omega$, the moduli of continuity of $a_{ij}$ and the $L^\infty(\Omega)$-norms of $a_{ij}, b_i$, and $c$.

We need to point out that Corollary 5.28 can be proved directly, without using Theorem 5.27.