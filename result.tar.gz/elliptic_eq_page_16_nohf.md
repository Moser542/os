PROPOSITION 1.20 Green's function $G(x, y)$ is symmetric in $\Omega \times \Omega$; that is, $G(x, y) = G(y, x)$ for $x \neq y \in \Omega$.

PROOF: Pick $x_1, x_2 \in \Omega$ with $x_1 \neq x_2$. Choose $r > 0$ small such that $B_r(x_1) \cap B_r(x_2) = \emptyset$. Set $G_1(y) = G(x_1, y)$ and $G_2(y) = G(x_2, y)$. We apply Green's formula in $\Omega \setminus B_r(x_1) \cup B_r(x_2)$ and get

$$
\int_{\Omega \setminus B_r(x_1) \cup B_r(x_2)} (G_1 \Delta G_2 - G_2 \Delta G_1) = \int_{\partial \Omega} \left( G_1 \frac{\partial G_2}{\partial n} - G_2 \frac{\partial G_1}{\partial n} \right) dS \\ - \int_{\partial B_r(x_1)} \left( G_1 \frac{\partial G_2}{\partial n} - G_2 \frac{\partial G_1}{\partial n} \right) dS \\ - \int_{\partial B_r(x_2)} \left( G_1 \frac{\partial G_2}{\partial n} - G_2 \frac{\partial G_1}{\partial n} \right) dS.
$$

Since $G_i$ is harmonic for $y \neq x_i, i = 1, 2$, and vanishes on $\partial\Omega$, we have

$$
\int_{\partial B_r(x_1)} \left( G_1 \frac{\partial G_2}{\partial n} - G_2 \frac{\partial G_1}{\partial n} \right) dS + \int_{\partial B_r(x_2)} \left( G_1 \frac{\partial G_2}{\partial n} - G_2 \frac{\partial G_1}{\partial n} \right) dS = 0.
$$

Note the left side has the same limit as the left side in the following as $r \to 0$:

$$
\int_{\partial B_r(x_1)} \left( \Gamma \frac{\partial G_2}{\partial n} - G_2 \frac{\partial \Gamma}{\partial n} \right) dS + \int_{\partial B_r(x_2)} \left( G_1 \frac{\partial \Gamma}{\partial n} - \Gamma \frac{\partial G_1}{\partial n} \right) dS = 0.
$$

Since

$$
\int_{\partial B_r(x_1)} \Gamma \frac{\partial G_2}{\partial n} dS \to 0, \quad \int_{\partial B_r(x_2)} \Gamma \frac{\partial G_1}{\partial n} dS \to 0 \quad \text{as } r \to 0, \\ \int_{\partial B_r(x_1)} G_2 \frac{\partial \Gamma}{\partial n} dS \to G_2(x_1), \quad \int_{\partial B_r(x_2)} G_1 \frac{\partial \Gamma}{\partial n} dS \to G_1(x_2) \quad \text{as } r \to 0,
$$

we obtain $G_2(x_1) - G_1(x_2) = 0$ or equivalently $G(x_2, x_1) = G(x_1, x_2)$. $\square$

PROPOSITION 1.21 There holds for $x, y \in \Omega$ with $x \neq y$

$$
0 > G(x, y) > \Gamma(x, y) \quad \text{for } n \ge 3 \\ 0 > G(x, y) > \Gamma(x, y) - \frac{1}{2\pi} \log \operatorname{diam}(\Omega) \quad \text{for } n = 2.
$$

PROOF: Fix $x \in \Omega$ and write $G(y) = G(x, y)$. Since $\lim_{y \to x} G(y) = -\infty$ then there exists an $r > 0$ such that $G(y) < 0$ in $B_r(x)$. Note that $G$ is harmonic in $\Omega \setminus B_r(x)$ with $G = 0$ on $\partial\Omega$ and $G < 0$ on $\partial B_r(x)$. The maximum principle implies $G(y) < 0$ in $\Omega \setminus B_r(x)$ for such $r > 0$. Next, consider the other part of the inequality. Recall the definition of the Green's function

$$
G(x, y) = \Gamma(x, y) + \Phi(x, y) \quad \text{where} \quad \begin{cases} \Delta\Phi = 0 & \text{in } \Omega, \\ \Phi = -\Gamma & \text{on } \partial\Omega. \end{cases}
$$