Suppose $f \in L^q(\Omega)$ for some $q > \frac{n}{2}$. Then $u \in C^\alpha(\Omega)$ for some $\alpha \in (0, 1)$ depending only on $n, q, \lambda$, and $\Lambda$. Moreover, there holds for any $B_R \subset \Omega$

$$
|u(x) - u(y)| \le C \left( \frac{|x - y|}{R} \right)^\alpha \left\{ \left( \frac{1}{R^n} \int_{B_R} u^2 \right)^{1/2} + R^{2-\frac{n}{q}} \|f\|_{L^q(B_R)} \right\}
$$

for any $x, y \in B_{R/2}$ where $C = C(n, \lambda, \Lambda, q)$ is a positive constant.

PROOF: We prove the estimate for $R = 1$. Let $M(r) = \max_{B_r} u$ and $m(r) = \min_{B_r} u$ for $r \in (0, 1)$. Then $M(r) < +\infty$ and $m(r) > -\infty$. It suffices to show that

$$
\omega(r) \triangleq M(r) - m(r) \le C r^{\alpha} \left\{ \left( \int_{B_1} u^2 \right)^{1/2} + \|f\|_{L^q(B_1)} \right\} \quad \text{for any } r < \frac{1}{2}.
$$

Set $\delta = 2 - \frac{n}{q}$. Apply Theorem 4.17 to $M(r) - u \ge 0$ in $B_r$ to get

$$
\sup_{B_{r/2}} (M(r) - u) \le C \left\{ \inf_{B_{r/2}} (M(r) - u) + r^{\delta} \|f\|_{L^q(B_r)} \right\},
$$

that is,

$$
(4.14) \qquad M(r) - m\left(\frac{r}{2}\right) \le C \left\{ \left( M(r) - M\left(\frac{r}{2}\right) \right) + r^{\delta} \|f\|_{L^q(B_r)} \right\}.
$$

Similarly, apply Harnack to $u - m(r) \ge 0$ in $B_r$ to get

$$
(4.15) \qquad M\left(\frac{r}{2}\right) - m(r) \le C \left\{ \left( m\left(\frac{r}{2}\right) - m(r) \right) + r^{\delta} \|f\|_{L^q(B_r)} \right\}.
$$

Then by adding (4.14) and (4.15) together we get

$$
\omega(r) + \omega\left(\frac{r}{2}\right) \le C \left\{ \left( \omega(r) - \omega\left(\frac{r}{2}\right) \right) + r^{\delta} \|f\|_{L^q(B_r)} \right\}
$$

or

$$
\omega\left(\frac{r}{2}\right) \le \gamma\omega(r) + C r^{\delta} \|f\|_{L^q(B_r)}
$$

for some $\gamma = \frac{C-1}{C+1} < 1$.

Apply Lemma 4.19 below with $\mu$ chosen such that $\alpha = (1 - \mu) \log \gamma / \log \tau < \mu\delta$. We obtain

$$
\omega(\rho) \le C \rho^{\alpha} \left\{ \omega\left(\frac{1}{2}\right) + \|f\|_{L^q(B_1)} \right\} \quad \text{for any } \rho \in (0, \frac{1}{2}].
$$

While Theorem 4.14 implies

$$
\omega\left(\frac{1}{2}\right) \le C \left\{ \left( \int_{B_1} u^2 \right)^{1/2} + \|f\|_{L^q(B_1)} \right\}.
$$

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAeCAIAAABSe/KxAAAAXklEQVR4nO3VoQ3AQAgFUNrcPqyIuGHYBxiHUNOcOFkwl/IVmBcIgisioDR3LfdbcazKzBCxUgQAd8+L+9ZzzkiEiE64TIsttthii+eKY+uZWUQ+c6oK642pam64Nw+S7Fpwr5tEBQAAAABJRU5ErkJggg==)