This property will be needed in Section 5.4.

Next we derive the Alexandroff maximum principle for viscosity solutions. It replaces the energy inequality for solutions to equations of divergence forms. Let $v$ be a continuous function in an open convex set $\Omega$. Recall that the convex envelope of $v$ in $\Omega$ is defined by

$$
\Gamma(v)(x) = \sup_L \{L(x) : L \le v \text{ in } \Omega, L \text{ an affine function}\}
$$

for any $x \in \Omega$. It is easy to see that $\Gamma(v)$ is a convex function in $\Omega$. The set $\{v = \Gamma(v)\} = \{x \in \Omega : v(x) = \Gamma(v)(x)\}$ is called the (lower) contact set of $v$. The points in the contact set are called contact points.

The following is the classical version of the Alexandroff maximum principle. We do not require that functions be solutions to elliptic equations. See Lemma 2.24.

LEMMA 5.7 Suppose $u$ is a $C^{1,1}$-function in $B_1$ with $u \ge 0$ on $\partial B_1$. Then there holds

$$
\sup_{B_1} u^- \le c(n) \left( \int_{B_1 \cap \{u = \Gamma_u\}} \det D^2 u \right)^{\frac{1}{n}}
$$

where $\Gamma_u$ is the convex envelope of $-u^- = \min\{u, 0\}$.

Now we state the viscosity version.

THEOREM 5.8 Suppose $u$ belongs to $S^+(\lambda, \Lambda, f)$ in $B_1$ with $u \ge 0$ on $\partial B_1$ for some $f \in C(\Omega)$. Then there holds

$$
\sup_{B_1} u^- \le c(n, \lambda, \Lambda) \left( \int_{B_1 \cap \{u = \Gamma_u\}} (f^+)^n \right)^{\frac{1}{n}}
$$

where $\Gamma_u$ is the convex envelope of $-u^- = \min\{u, 0\}$.

PROOF: We will prove that $\Gamma_u$ is a $C^{1,1}$-function in $B_1$ and that at contact point $x_0$ there hold

$$
(5.1) \qquad f(x_0) \ge 0
$$

and

$$
(5.2) \qquad L(x) \le \Gamma_u(x) \le L(x) + C\{f(x_0) + \varepsilon(x)\}|x - x_0|^2
$$

for some affine function $L$ and any $x$ close to $x_0$, where $\varepsilon(x) \to 0$ as $x \to x_0$ and $C$ is a positive constant depending only on $n, \lambda$, and $\Lambda$. We obtain by (5.2)

$$
\det D^2 \Gamma_u(x) \le C(n, \lambda, \Lambda) (f(x))^n \quad \text{for a.e. } x \in \{u = \Gamma_u\}.
$$

We may apply Lemma 5.7 to function $\Gamma_u$ to get the result.

Suppose $x_0$ is a contact point, that is, $u(x_0) = \Gamma_u(x_0)$. We may assume $x_0 = 0$. We also assume, by subtracting a supporting plane at $x_0 = 0$, that $u \ge 0$ in $B_1$ and that $u(0) = 0$.