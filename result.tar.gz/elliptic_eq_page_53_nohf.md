and integrating with respect to $\zeta$ over $B_{2R}(x) \cap B_{2R}(y)$, which contains $B_R(x)$, yields

$$
\begin{aligned}
|u_{x,2R} - u_{y,2R}|^2 &\le \frac{2}{|B_R(x)|} \left\{ \int_{B_{2R}(x)} |u - u_{x,2R}|^2 + \int_{B_{2R}(y)} |u - u_{y,2R}|^2 \right\} \\
&\le c(n, \alpha) M^2 R^{2\alpha}.
\end{aligned}
$$

Therefore we have

$$
|u(x) - u(y)| \le c(n, \alpha) M |x - y|^{\alpha}.
$$

For $|x - y| > R_0/2$ we obtain

$$
|u(x) - u(y)| \le 2 \sup_{\Omega'} |u| \le c \left\{ M + \frac{1}{R_0^{\alpha}} \|u\|_{L^2} \right\} |x - y|^{\alpha}.
$$

This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAgCAIAAABhFeQrAAAApklEQVR4nO2WMQrEIBBFJyFgIdjaeSIvJJ7CzjOlttDOA9jaOlssLBt3O51AwN/NFG8+Dws3RASC7BTQxSXnHt+Dc857P/hClFLW2gv3PM8Y4wgUAFJKtdY/HkIIOBAAKKWQ+EXEvZuncFtrJH177qy+vYdZWR7eeZoHqr53+V0ePndIuLNyl98HeDh+t1prxtgIVwhx4UopASDnPALlnBtjNqJ/6guuSa/xmaFpfQAAAABJRU5ErkJggg==)

A special case of the Sobolev theorem is an easy consequence of Theorem 3.1. In fact, we have the following result due to Morrey.

COROLLARY 3.2 Suppose $u \in H_{\text{loc}}^1(\Omega)$ satisfies

$$
\int_{B_r(x)} |Du|^2 \le M^2 r^{n-2+2\alpha} \quad \text{for any } B_r(x) \subset \Omega
$$

for some $\alpha \in (0, 1)$. Then $u \in C^\alpha(\Omega)$ and for any $\Omega' \Subset \Omega$ there holds

$$
\sup_{\Omega'} |u| + \sup_{\substack{x,y \in \Omega' \\ x \neq y}} \frac{|u(x) - u(y)|}{|x - y|^{\alpha}} \le c\{M + \|u\|_{L^2(\Omega)}\}
$$

where $c = c(n, \alpha, \Omega, \Omega') > 0$.

PROOF: By the Poincaré inequality, we obtain

$$
\int_{B_r(x)} |u - u_{x,r}|^2 \le c(n)r^2 \int_{B_r(x)} |Du|^2 \le c(n)M^2r^{n+2\alpha}.
$$

By applying Theorem 3.1, we have the result.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAfCAIAAACUOVFTAAAAq0lEQVR4nO2WIRKEIBhGPx2KhXOQvATBA3AhI1diOAqRQCFh59+wu+5qFHCGGV9Cw/ObV3AgIjRgbCHt0Mv2U0pJSrltW5GOsWVZtNagL8654pUfrLXnDkopKmBdVwAxxiZ9iWj8f6jlzTk32XvwVtx76FCRp8Ob3jq02ntL36fD/pEm3orc0rePDuz0yhgjhLhsjDEC4Jz/7nnv/TRNRTsBAPM8hxCGzv77XmBhwvJgq4SpAAAAAElFTkSuQmCC)

The following result will be needed in Section 3.3.

LEMMA 3.3 Suppose $u \in H^1(\Omega)$ satisfies

$$
\int_{B_r(x_0)} |Du|^2 \le M r^\mu \quad \text{for any } B_r(x_0) \subset \Omega
$$

for some $\mu \in [0, n)$. Then for any $\Omega' \Subset \Omega$ there holds for any $B_r(x_0) \subset \Omega$ with $x_0 \in \Omega'$

$$
\int_{B_r(x_0)} |u|^2 \le c(n, \lambda, \mu, \Omega, \Omega') \left\{ M + \int_{\Omega} u^2 \right\} r^{\lambda}
$$

where $\lambda = \mu + 2$ if $\mu < n - 2$ and $\lambda$ is any number in $[0, n)$ if $n - 2 \le \mu < n$.