PROOF OF PROPOSITION 2.27: We prove for subsolutions. Assume $Qu \ge 0$ in $\Omega$. Then we have

$$
-a_{ij} D_{ij} u \le b \quad \text{in } \Omega.
$$

Note that $\{D_{ij}u\}$ is nonpositive in $\Gamma^+$. Hence $-a_{ij} D_{ij} u \ge 0$, which implies $b(x, u, Du) \ge 0$ in $\Gamma^+$. Then in $\Gamma^+ \cap \Omega^+$ there holds

$$
\frac{b(x, z, Du)}{nD^*} \le \frac{h(x)}{g(Du)}.
$$

We may apply Lemma 2.24 to $g^n$ and get

$$
\begin{aligned} \int_{B_{\tilde{M}}(0)} g^n &\le \int_{\Gamma^+ \cap \Omega^+} g^n(Du) \left( \frac{-a_{ij} D_{ij} u}{nD^*} \right)^n \\ &\le \int_{\Gamma^+ \cap \Omega^+} g^n(Du) \left( \frac{b}{nD^*} \right)^n \le \int_{\Gamma^+ \cap \Omega^+} h^n \le \int_{\Omega} h^n \left( < \int_{\mathbb{R}^n} g^n \right). \end{aligned}
$$

Therefore there exists a positive constant $C$, depending only on $g$ and $h$, such that $\tilde{M} \le C$. This implies

$$
\sup_{\Omega} u \le \sup_{\partial \Omega} u^+ + C \operatorname{diam}(\Omega).
$$

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAeCAIAAABfZYL2AAAAcElEQVR4nO3WMQrAIAyF4UQ8juAoeDoHj2iOo69DoQh1qtjp/VsQPoOTCkAO5E6gdJ/8PJhZjHEfTSkJplpr++jd4h1qrdiolLJ2T+1Lly5dunTp/ubq/D8zsxCCqjr3/b4xBgD/PgDQe//sikjO+QLRrWbNSxaOkgAAAABJRU5ErkJggg==)

Next we discuss Monge-Ampère equations.

COROLLARY 2.29 Suppose $u \in C(\bar{\Omega}) \cap C^2(\Omega)$ satisfies

$$
\det(D^2 u) = f(x, u, Du) \quad \text{in } \Omega
$$

for some $f \in C(\Omega \times \mathbb{R} \times \mathbb{R}^n)$. Suppose there exist nonnegative functions $g \in L_{\text{loc}}^1(\mathbb{R}^n)$ and $h \in L^1(\Omega)$ such that

$$
\begin{aligned} |f(x, z, p)| &\le \frac{h(x)}{g(p)} \quad \text{for any } (x, z, p) \in \Omega \times \mathbb{R} \times \mathbb{R}^n, \\ \int_{\Omega} h(x) dx &< \int_{\mathbb{R}^n} g(p) dp \equiv g_{\infty}. \end{aligned}
$$

Then there holds

$$
\sup_{\Omega} |u| \le \sup_{\partial \Omega} |u| + C \operatorname{diam}(\Omega)
$$

where $C$ is a positive constant depending only on $g$ and $h$.

The proof is similar to that of Proposition 2.27. There are two special cases. The first case is given by $f = f(x)$. We may take $g \equiv 1$ and hence $g_{\infty} = \infty$. So we obtain the following:

COROLLARY 2.30 Let $u \in C(\bar{\Omega}) \cap C^2(\Omega)$ satisfy

$$
\det(D^2 u) = f(x) \quad \text{in } \Omega
$$