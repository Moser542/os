where $\Gamma$ is the fundamental solution of the Laplace operator. It is easy to see that $w_{x_0}$ is a harmonic function in $\Omega$ and satisfies (6.3). We note that the exterior sphere condition always holds for $C^2$-domains.

**THEOREM 6.6** Let $\Omega$ be a bounded domain in $\mathbb{R}^n$ satisfying the exterior sphere condition at every boundary point. Then for any $\varphi \in C(\partial\Omega)$, (6.1) admits a solution $u \in C^\infty(\Omega) \cap C(\bar{\Omega})$.

## 6.2. Variational Method

In this section we discuss the Dirichlet problem for elliptic differential equations of divergence form and prove the existence of weak solutions.

Let $\Omega$ be a bounded domain in $\mathbb{R}^n$ and $a_{ij}$, $b_i$, and $c$ be bounded functions in $\Omega$. Consider the differential operator

$$
Lu = -D_j(a_{ij}D_i u) + b_i D_i u + cu.
$$

We always assume that

$$
\lambda|\xi|^2 \le a_{ij}(x)\xi_i\xi_j \le \Lambda|\xi|^2
$$

for any $x \in \Omega$ and $\xi \in \mathbb{R}^n$.

**DEFINITION 6.7** Let $f \in L^2(\Omega)$ and $u \in H_{\text{loc}}^1(\Omega)$. Then $u$ is a weak solution of $Lu = f$ in $\Omega$ if

$$
(6.4) \qquad \int_{\Omega} (a_{ij} D_i u D_j \varphi + b_i D_i u \varphi + cu \varphi) dx = \int_{\Omega} f \varphi dx
$$

for any $\varphi \in H_0^1(\Omega)$.

Next, we define

$$
a(u, v) = \int_{\Omega} (a_{ij} D_i u D_j v + b_i D_i u v + cu v) dx
$$

for any $u, v \in H_0^1(\Omega)$. We call $a$ the bilinear form associated with the operator $L$. If $a_{ij} = a_{ji}$ and $c = 0$, then $a$ is symmetric, i.e.,

$$
a(u, v) = a(v, u) \quad \text{for any } u, v \in H_0^1(\Omega).
$$

We now solve the Dirichlet problem in the weak sense for a special class of elliptic operators. We recall that the standard $H_0^1(\Omega)$ inner product is defined by

$$
(u, v)_{H_0^1(\Omega)} = \int_{\Omega} \nabla u \cdot \nabla v \, dx.
$$

**THEOREM 6.8** Let $a_{ij}$, $b_i$, and $c$ be bounded functions in $\Omega$ and $f \in L^2(\Omega)$. Assume the bilinear form $a$ associated with $L$ is coercive; i.e.,

$$
a(u, u) \ge c_0 \|u\|_{H_0^1(\Omega)}^2
$$

for any $u \in H_0^1(\Omega)$. Then there exists a unique weak solution $u \in H_0^1(\Omega)$ of $Lu = f$.