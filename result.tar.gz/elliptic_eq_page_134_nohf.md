for any $x \in \Omega$ and $\xi \in \mathbb{R}^n$. Suppose $f \in L^2(\Omega)$. Define

$$
(6.5) \qquad J(u) = \frac{1}{2} \int_{\Omega} (a_{ij} D_i u D_j u + cu^2) dx + \int_{\Omega} uf \, dx.
$$

THEOREM 6.10 Let $a_{ij}$ and $c$ be bounded functions in $\Omega$ with $a_{ij} = a_{ji}$ and $c \ge 0$, and $f \in L^2(\Omega)$. Then $J$ admits a minimizer $u \in H_0^1(\Omega)$.

It is easy to check that the minimizer $u$ is a weak solution of

$$
-D_j(a_{ij} D_i u) + cu = f \quad \text{in } \Omega.
$$

PROOF: We first prove that $J$ has a lower bound in $H_0^1(\Omega)$. By the Poincaré inequality, we have for any $u \in \mathcal{H}_0^1(\Omega)$

$$
\int_{\Omega} u^2 \, dx \le C \int_{\Omega} |\nabla u|^2 \, dx,
$$

where $C$ is a positive constant depending only on $\Omega$. Then

$$
\begin{aligned} \int_{\Omega} |uf| \, dx &\le \left( \int_{\Omega} u^2 \, dx \right)^{\frac{1}{2}} \left( \int_{\Omega} f^2 \, dx \right)^{\frac{1}{2}} \\ &\le \sqrt{C} \left( \int_{\Omega} |\nabla u|^2 \, dx \right)^{\frac{1}{2}} \left( \int_{\Omega} f^2 \, dx \right)^{\frac{1}{2}} \\ &\le \frac{1}{4\lambda} \int_{\Omega} |\nabla u|^2 \, dx + C\lambda \int_{\Omega} f^2 \, dx. \end{aligned}
$$

Hence for any $u \in H_0^1(\Omega)$,

$$
(6.6) \qquad J(u) \ge \frac{1}{4\lambda} \int_{\Omega} |\nabla u|^2 \, dx - C\lambda \int_{\Omega} f^2 \, dx
$$

and in particular

$$
J(u) \ge -C \int_{\Omega} f^2 \, dx.
$$

Therefore, $J$ has a lower bound in $H_0^1(\Omega)$. We set

$$
J_0 = \inf\{J(u) : u \in \mathcal{H}_0^1(\Omega)\}.
$$

Next, we prove that $J_0$ is attained by some $u \in H_0^1(\Omega)$. We consider a minimizing sequence $\{u_k\} \subset H_0^1(\Omega)$ with $J(u_k) \to J_0$ as $k \to \infty$. By (6.6) we have

$$
\int_{\Omega} |\nabla u_k|^2 \, dx \le 4\lambda J(u_k) + 4C\lambda^2 \int_{\Omega} f^2 \, dx.
$$