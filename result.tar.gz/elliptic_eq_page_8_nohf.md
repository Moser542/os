Hence for harmonic function $u$ we have for any $\rho \in (0, r)$

$$
\frac{\partial}{\partial \rho} \int_{|w|=1} u(x + \rho w) dS_w = 0.
$$

Integrating from 0 to $r$ we obtain

$$
\int_{|w|=1} u(x + rw) dS_w = \int_{|w|=1} u(x) dS_w = u(x) \omega_n
$$

or

$$
u(x) = \frac{1}{\omega_n} \int_{|w|=1} u(x + rw) dS_w = \frac{1}{\omega_n r^{n-1}} \int_{\partial B_r(x)} u(y) dS_y.
$$

□

REMARK 1.7. For a function $u$ satisfying the mean value property, $u$ is not required to be smooth. However a harmonic function is required to be $C^2$. We prove these two are equivalent.

THEOREM 1.8 If $u \in C(\Omega)$ has mean value property in $\Omega$, then $u$ is smooth and harmonic in $\Omega$.

PROOF: Choose $\varphi \in C_0^\infty(B_1(0))$ with $\int_{B_1(0)} \varphi = 1$ and $\varphi(x) = \psi(|x|)$; i.e.,

$$
\omega_n \int_0^1 r^{n-1} \psi(r) dr = 1.
$$

We define $\varphi_\varepsilon(z) = \frac{1}{\varepsilon^n} \varphi(\frac{z}{\varepsilon})$ for $\varepsilon > 0$. Now for any $x \in \Omega$ consider $\varepsilon < \text{dist}(x, \partial\Omega)$. Then we have

$$
\begin{align*}
\int_{\Omega} u(y) \varphi_{\varepsilon}(y-x) dy &= \int u(x+y) \varphi_{\varepsilon}(y) dy \\
&= \frac{1}{\varepsilon^n} \int_{|y|<\varepsilon} u(x+y) \varphi\left(\frac{y}{\varepsilon}\right) dy \\
&= \int_{|y|<1} u(x+\varepsilon y) \varphi(y) dy \\
&= \int_0^1 r^{n-1} dr \int_{\partial B_1(0)} u(x+\varepsilon rw) \varphi(rw) dS_w \\
&= \int_0^1 \psi(r) r^{n-1} dr \int_{|w|=1} u(x+\varepsilon rw) dS_w \\
&= u(x) \omega_n \int_0^1 \psi(r) r^{n-1} dr = u(x)
\end{align*}
$$