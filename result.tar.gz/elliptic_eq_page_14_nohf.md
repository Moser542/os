THEOREM 1.17 Suppose $\Omega$ is a bounded domain in $\mathbb{R}^n$ and that $u \in C^1(\bar{\Omega}) \cap C^2(\Omega)$. Then for any $a \in \Omega$ there holds

$$
u(a) = \int_{\Omega} \Gamma(a, x) \Delta u(x) dx - \int_{\partial \Omega} \left( \Gamma(a, x) \frac{\partial u}{\partial n_x}(x) - u(x) \frac{\partial \Gamma}{\partial n_x}(a, x) \right) dS_x.
$$

REMARK 1.18.

(i) For any $a \in \Omega$, $\Gamma(a, \cdot)$ is integrable in $\Omega$ although it has a singularity.

(ii) For $a \notin \bar{\Omega}$, the expression in the right side gives 0.

(iii) By letting $u = 1$ we have $\int_{\partial \Omega} \frac{\partial \Gamma}{\partial n_x}(a, x) dS_x = 1$ for any $a \in \Omega$.

PROOF: We apply Green's formula to $u$ and $\Gamma(a, \cdot)$ in the domain $\Omega \setminus B_r(a)$ for small $r > 0$ and get

$$
\int_{\Omega \setminus B_r(a)} (\Gamma \Delta u - u \Delta \Gamma) dx = \int_{\partial \Omega} \left( \Gamma \frac{\partial u}{\partial n} - u \frac{\partial \Gamma}{\partial n} \right) dS_x - \int_{\partial B_r(a)} \left( \Gamma \frac{\partial u}{\partial n} - u \frac{\partial \Gamma}{\partial n} \right) dS_x.
$$

Note $\Delta \Gamma = 0$ in $\Omega \setminus B_r(a)$. Then we have

$$
\int_{\Omega} \Gamma \Delta u \, dx = \int_{\partial \Omega} \left( \Gamma \frac{\partial u}{\partial n} - u \frac{\partial \Gamma}{\partial n} \right) dS_x - \lim_{r \to 0} \int_{\partial B_r(a)} \left( \Gamma \frac{\partial u}{\partial n} - u \frac{\partial \Gamma}{\partial n} \right) dS_x.
$$

For $n \ge 3$, we get by definition of $\Gamma$

$$
\begin{aligned} \left| \int_{\partial B_r(a)} \Gamma \frac{\partial u}{\partial n} dS \right| &= \left| \frac{1}{(2-n)\omega_n} r^{2-n} \int_{\partial B_r(a)} \frac{\partial u}{\partial n} dS \right| \\ &\le \frac{r}{n-2} \sup_{\partial B_r(a)} |Du| \to 0 \quad \text{as } r \to 0, \end{aligned}
$$

$$
\int_{\partial B_r(a)} u \frac{\partial \Gamma}{\partial n} dS = \frac{1}{\omega_n r^{n-1}} \int_{\partial B_r(a)} u dS \to u(a) \quad \text{as } r \to 0.
$$

We get the same conclusion for $n = 2$ in the same way. $\square$

REMARK 1.19. We may employ the local version of the Green's identity to get gradient estimates without using the mean value property. Suppose $u \in C(\bar{B}_1)$ is harmonic in $B_1$. For any fixed $0 < r < R < 1$ choose a cutoff function $\varphi \in C_0^\infty(B_R)$ such that $\varphi = 1$ in $B_r$ and $0 \le \varphi \le 1$. Apply the Green's formula to $u$ and $\varphi \Gamma(a, \cdot)$ in $B_1 \setminus B_\rho(a)$ for $a \in B_r$ and $\rho$ small enough. We proceed as in the proof of Theorem 1.17 and obtain

$$
u(a) = - \int_{r < |x| < R} u(x) \Delta_x (\varphi(x) \Gamma(a, x)) dx \quad \text{for any } a \in B_r(0).
$$