## 2.6. Moving Plane Method

In this section we will use the moving plane method to discuss the symmetry of solutions. The following result was first proved by Gidas, Ni, and Nirenberg.

THEOREM 2.34 Suppose $u \in C(\bar{B}_1) \cap C^2(B_1)$ is a positive solution of

$$
\begin{aligned}
\Delta u + f(u) &= 0 && \text{in } B_1, \\
u &= 0 && \text{on } \partial B_1,
\end{aligned}
$$

where $f$ is locally Lipschitz in $\mathbb{R}$. Then $u$ is radially symmetric in $B_1$ and $\frac{\partial u}{\partial r}(x) < 0$ for $x \neq 0$.

The original proof requires that solutions be $C^2$ up to the boundary. Here we give a method that does not depend on the smoothness of domains nor the smoothness of solutions up to the boundary.

LEMMA 2.35 Suppose that $\Omega$ is a bounded domain that is convex in the $x_1$-direction and symmetric with respect to the plane $\{x_1 = 0\}$. Suppose $u \in C(\bar{\Omega}) \cap C^2(\Omega)$ is a positive solution of

$$
\begin{aligned}
\Delta u + f(u) &= 0 && \text{in } \Omega, \\
8u &= 0 && \text{on } \partial \Omega,
\end{aligned}
$$

where $f$ is locally Lipschitz in $\mathbb{R}$. Then $u$ is symmetric with respect to $x_1$ and $D_{x_1}u(x) < 0$ for any $x \in \Omega$ with $x_1 > 0$.

PROOF: Write $x = (x_1, y) \in \Omega$ for $y \in \mathbb{R}^{n-1}$. We will prove

$$
(2.4) \qquad u(x_1, y) < u(x_1^*, y)
$$

for any $x_1 > 0$ and $x_1^* < x_1$ with $x_1^* + x_1 > 0$. Then by letting $x_1^* \to -x_1$, we get $u(x_1, y) \le u(-x_1, y)$ for any $x_1$. Then by changing the direction $x_1 \to -x_1$, we get the symmetry.

Let $a = \sup x_1$ for $(x_1, y) \in \Omega$. For $0 < \lambda < a$, define

$$
\begin{aligned}
\Sigma_{\lambda} &= \{x \in \Omega : x_1 > \lambda\}, \\
T_{\lambda} &= \{x_1 = \lambda\}, \\
\Sigma'_{\lambda} &= \text{reflection of } \Sigma_{\lambda} \text{ with respect to } T_{\lambda}, \\
x_{\lambda} &= (2\lambda - x_1, \dots, x_n) \quad \text{for } x = (x_1, \dots, x_n).
\end{aligned}
$$

In $\Sigma_{\lambda}$ we define

$$
w_{\lambda}(x) = u(x) - u(x_{\lambda}) \quad \text{for } x \in \Sigma_{\lambda}.
$$

Then we have by the mean value theorem

$$
\begin{aligned}
\Delta w_{\lambda} + c(x, \lambda)w_{\lambda} &= 0 && \text{in } \Sigma_{\lambda}, \\
w_{\lambda} &\le 0 \text{ and } w_{\lambda} \ne 0 && \text{on } \partial \Sigma_{\lambda},
\end{aligned}
$$

where $c(x, \lambda)$ is a bounded function in $\Sigma_{\lambda}$.