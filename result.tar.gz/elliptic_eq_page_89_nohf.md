for any $\tau' \in (\tau, 1)$.

Next we will estimate $\int_{B_\tau} |w|^\beta$ for any $\beta \ge 2$. Choose $\varphi = \zeta^2 |w_m|^{2\beta} \in H_0^1(B_1) \cap L^\infty(B_1)$ with

$$
w_m = \begin{cases} -m, & w \le -m, \\ w, & |w| < m, \\ m, & w \ge m. \end{cases}
$$

Substitute such $\varphi$ in (4.9) to get

$$
\int_{B_1} \zeta^2 |w_m|^{2\beta} a_{ij} D_i w D_j w \le (2\beta) \int_{B_1} \zeta^2 a_{ij} D_i w D_j |w_m| |w_m|^{2\beta-1} \\ + \int_{B_1} 2\zeta |w_m|^{2\beta} a_{ij} D_i w D_j \zeta + \int_{B_1} |\tilde{f}| \zeta^2 |w_m|^{2\beta}.
$$

Note $a_{ij} D_i w D_j |w_m| = a_{ij} D_i w_m D_j |w_m| \le a_{ij} D_i w_m D_j w_m$ a.e. in $B_1$. Young's inequality implies

$$
(2\beta)|w_m|^{2\beta-1} \le \frac{2\beta-1}{2\beta} |w_m|^{2\beta} + \frac{1}{2\beta} (2\beta)^{2\beta} \\ = \left(1 - \frac{1}{2\beta}\right) |w_m|^{2\beta} + (2\beta)^{2\beta-1}.
$$

Hence we obtain

$$
\int_{B_1} \zeta^2 |w_m|^{2\beta} a_{ij} D_i w D_j w \le \left(1 - \frac{1}{2\beta}\right) \int_{B_1} \zeta^2 |w_m|^{2\beta} a_{ij} D_i w_m D_j w_m \\ + (2\beta)^{2\beta-1} \int_{B_1} \zeta^2 a_{ij} D_i w_m D_j w_m \\ + \int_{B_1} 2\zeta |w_m|^{2\beta} a_{ij} D_i w D_j \zeta + \int_{B_1} |\tilde{f}| \zeta^2 |w_m|^{2\beta}
$$

and hence

$$
\int_{B_1} \zeta^2 |w_m|^{2\beta} a_{ij} D_i w D_j w \\ \le (2\beta)^{2\beta} \int_{B_1} \zeta^2 a_{ij} D_i w_m D_j w_m \\ + (4\beta) \int_{B_1} \zeta |w_m|^{2\beta} a_{ij} D_i w D_j \zeta + 2\beta \int_{B_1} |\tilde{f}| \zeta^2 |w_m|^{2\beta}.
$$