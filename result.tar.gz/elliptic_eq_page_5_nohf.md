# Preface

In the fall of 1992, the second author gave a course called “Intermediate PDEs” at the Courant Institute. The purpose of that course was to present some basic methods for obtaining various a priori estimates for second-order partial differential equations of elliptic type with particular emphasis on maximal principles, Harnack inequalities, and their applications. The equations one deals with are always linear, although they also obviously apply to nonlinear problems. Students with some knowledge of real variables and Sobolev functions should be able to follow the course without much difficulty.

In 1992, the lecture notes were taken by the first author. In 1995 at the University of Notre Dame, the first author gave a similar course. The original notes were then much extended, resulting in their present form.

It is not our intention to give a complete account of the related theory. Our goal is simply to provide these notes as a bridge between the elementary book of F. John [9], which also studies equations of other types, and the somewhat advanced book of D. Gilbarg and N. Trudinger [8], which gives a relatively complete account of the theory of elliptic equations of second order. We also hope our notes can serve as a bridge between the recent elementary book of N. Krylov [11] on the classical theory of elliptic equations developed before and around the 1960s and the book by Caffarelli and Cabré [4], which studies fully nonlinear elliptic equations, the theory obtained in the 1980s.

The authors wish to thank Karen Jacobs, Cheryl Huff, Joan Hoerstman, and Daisy Calderon for the wonderful typing job. The work was also supported by National Science Foundation Grants DMS No. 9401546 and DMS No. 9501122.

July 1997

In the new edition, we add a final chapter on the existence of solutions. In it we discuss several methods for proving the existence of solutions of primarily the Dirichlet problem for various types of elliptic equations. All these existence results are based on a priori estimates established in previous chapters.

December 2010