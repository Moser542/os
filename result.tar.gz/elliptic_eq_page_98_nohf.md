for some positive constant $C$ depending only on $n$, $\lambda$, $\Lambda$, and $M$. Observe that $u$ and $v$ are compatible. Therefore by Theorem 4.14 we obtain for any $p > 0$

$$
\begin{aligned}
\sup_{B_{R/2}} u \le C(M, \alpha) \sup_{B_{R/2}} v &\le C \left\{ \left( \frac{1}{R^n} \int_{B_R} v^p \right)^{\frac{1}{p}} + R^{2-\frac{n}{q}} \left( \int_{B_R} f^q \right)^{\frac{1}{q}} \right\} \\
&\le C \left\{ \left( \frac{1}{R^n} \int_{B_R} u^p \right)^{\frac{1}{p}} + R^{2-\frac{n}{q}} \left( \int_{B_R} f^q \right)^{\frac{1}{q}} \right\}.
\end{aligned}
$$

For the lower bound, we let $w = \frac{1}{\alpha}(1 - e^{-\alpha u})$. As before, by choosing $\alpha > 0$ large we have

$$
\int a_{ij} D_i w D_j \varphi \ge C \int f(x) \varphi \quad \text{for any } \varphi \in H_0^1(B_1) \cap L^\infty(B_1) \text{ with } \varphi \ge 0.
$$

Hence by Theorem 4.15, we obtain for any $p \in (0, \frac{n}{n-2})$

$$
\left( \frac{1}{R^n} \int_{B_R} u^p \right)^{\frac{1}{p}} \le C \left\{ \inf_{B_{R/2}} u + R^{2-\frac{n}{q}} \left( \int_{B_R} f^q \right)^{\frac{1}{q}} \right\}.
$$

Combining the above inequalities we prove Lemma 4.21.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAhCAIAAACqSTeOAAAAu0lEQVR4nO2WsQ3DIBBFjwCtO65jExq2ofEa3oBhPBFCbmx6RIqTIjtORYIVS/wKCelxPAQHK6VAgzxaQDv3tlwouzjn+NcZhsF7L/ZrpJRyzlJKrTVjrKLKEEJKaZomcZ6b59laW7f7ZVkQMcZ48Et3DxHroACglCJOk3O7ivvDN+hWHuCt3n/3cBW3e6B0D5TugdLWw7qu1bht22jwoW8aYzjnddycMwAIIQ5c6nqv6bog4jiOrNH/9wkZwVudtZwgqgAAAABJRU5ErkJggg==)

REMARK 4.22. In estimate (4.16) in the above proof, take $\varphi = (u + M)\eta^2$ for some $\eta \in C_0^1(B_1)$. Then by the Hölder inequality we conclude

$$
\int |Du|^2 \eta^2 \le C \left\{ \int (|D\eta|^2 + |f|\eta^2) \right\}
$$

for some positive constant $C$ depending only on $n$, $\lambda$, $\Lambda$, and $M$. This implies the interior $L^2$-estimate of gradient $Du$ in terms of these constants together with $\|f\|_{L^1(B_1)}$. This fact will be used in the proof of Theorem 4.24.

COROLLARY 4.23 Suppose $u \in H^1(B_1)$ is a bounded solution of (*) and that $b$ satisfies the natural growth condition with $f(x) \in L^q(B_1)$ for some $q > \frac{n}{2}$. Then $u \in C_{\text{loc}}^\alpha(B_1)$ with $\alpha = \alpha(n, \lambda, \Lambda, q, |u|_{L^\infty})$. Moreover, there holds

$$
|u(x) - u(y)| \le C |x - y|^\alpha \quad \text{for any } x, y \in B_{1/2}
$$

where $C$ is a positive constant depending only on $n$, $\lambda$, $\Lambda$, $q$, $|u|_{L^\infty(B_1)}$, and $\|f\|_{L^q(B_1)}$.

PROOF: The proof is identical to that of Corollary 4.18 with Theorem 4.17 replaced by Lemma 4.21.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAgCAIAAABhFeQrAAAAy0lEQVR4nO2WMQ6EIBBFP6wJhbHFg1hzIA/ieTwBR/AC2hlao52hYbYgymZLkU3c8CoSks/PH2aAERESwFOIZt0AHRhjhBCvaJqmWZalOA/Y991aC0BKWVXVBYvWWmPMMAx93we/0zQBUEpRBG3bAui6LuTrL7KUMibVuq69VJK6/UT33oZ+VA749HtjDqn8OudyDp7cF8jz4eAP5sO2bTGK67r6RfG1obXmnHN+JR8ics4BKMsyvMfzPAshYswCYIwppcZxZA/7T74BpajHYzntCI4AAAAASUVORK5CYII=)

THEOREM 4.24 Suppose $u \in H^1(B_1)$ is a bounded solution of (*) and that $b$ satisfies the natural growth condition with $f \in L^q(B_1)$ for some $q > n$. Assume further that $a_{ij} \in C^\alpha(B_1)$ for $\alpha = 1 - \frac{n}{q}$. Then $Du \in C_{\text{loc}}^\alpha(B_1)$. Moreover, there holds

$$
|Du|_{C^\alpha(B_{1/2})} \le C(n, \lambda, \Lambda, q, |u|_{L^\infty(B_1)}, \|f\|_{L^q(B_1)}).
$$