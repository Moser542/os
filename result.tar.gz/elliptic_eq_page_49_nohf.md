We need to show $w_\lambda < 0$ in $\Sigma_\lambda$ for any $\lambda \in (0, a)$. This implies in particular that $w_\lambda$ assumes along $\partial\Sigma_\lambda \cap \Omega$ its maximum in $\Sigma_\lambda$. By Theorem 2.5 (the Hopf lemma) we have for any such $\lambda \in (0, a)$

$$
D_{x_1} w_\lambda|_{x_1=\lambda} = 2D_{x_1} u|_{x_1=\lambda} < 0.
$$

For any $\lambda$ close to $a$, we have $w_\lambda < 0$ by Proposition 2.13 (the maximum principle for a narrow domain) or Theorem 2.32. Let $(\lambda_0, a)$ be the largest interval of values of $\lambda$ such that $w_\lambda < 0$ in $\Sigma_\lambda$. We want to show $\lambda_0 = 0$. If $\lambda_0 > 0$, by continuity, $w_{\lambda_0} \le 0$ in $\Sigma_{\lambda_0}$ and $w_{\lambda_0} \not\equiv 0$ on $\partial\Sigma_{\lambda_0}$. Then Theorem 2.7 (the strong maximum principle) implies $w_{\lambda_0} < 0$ in $\Sigma_{\lambda_0}$. We will show that for any small $\varepsilon > 0$

$$
w_{\lambda_0-\varepsilon} < 0 \quad \text{in } \Sigma_{\lambda_0-\varepsilon}.
$$

Fix $\delta > 0$ (to be determined). Let $K$ be a closed subset in $\Sigma_{\lambda_0}$ such that $|\Sigma_{\lambda_0} \setminus K| < \frac{\delta}{2}$. The fact that $w_{\lambda_0} < 0$ in $\Sigma_{\lambda_0}$ implies

$$
w_{\lambda_0}(x) \le -\eta < 0 \quad \text{for any } x \in K.
$$

By continuity we have

$$
w_{\lambda_0-\varepsilon} < 0 \quad \text{in } K.
$$

For $\varepsilon > 0$ small, $|\Sigma_{\lambda_0-\varepsilon} \setminus K| < \delta$. We choose $\delta$ in such a way that we may apply Theorem 2.32 (the maximum principle for a domain with small volume) to $w_{\lambda_0-\varepsilon}$ in $\Sigma_{\lambda_0-\varepsilon} \setminus K$. Hence we get

$$
w_{\lambda_0-\varepsilon}(x) \le 0 \quad \text{in } \Sigma_{\lambda_0-\varepsilon} \setminus K
$$

and then by Theorem 2.10

$$
w_{\lambda_0-\varepsilon}(x) < 0 \quad \text{in } \Sigma_{\lambda_0-\varepsilon} \setminus K.
$$

Therefore we obtain for any small $\varepsilon > 0$

$$
w_{\lambda_0-\varepsilon}(x) < 0 \quad \text{in } \Sigma_{\lambda_0-\varepsilon}.
$$

This contradicts the choice of $\lambda_0$.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAeCAIAAABfZYL2AAAAcElEQVR4nO3WMQrAIAyF4UQ8juAoeDoHj2iOo69DoQh1qtjp/VsQPoOTCkAO5E6gdJ/8PJhZjHEfTSkJplpr++jd4h1qrdiolLJ2T+1Lly5dunTp/ubq/D8zsxCCqjr3/b4xBgD/PgDQe//sikjO+QLRrWbNSxaOkgAAAABJRU5ErkJggg==)