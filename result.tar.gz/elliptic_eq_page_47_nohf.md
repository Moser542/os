for some $f \in C(\bar{\Omega})$. Then there holds

$$
\sup_{\Omega} |u| \le \sup_{\partial \Omega} |u| + \frac{\operatorname{diam}(\Omega)}{\omega_n^{1/n}} \left( \int_{\Omega} |f|^n \right)^{1/n}.
$$

The second case is about the prescribed Gaussian curvature equations.

COROLLARY 2.31 Let $u \in C(\bar{\Omega}) \cap C^2(\Omega)$ satisfy

$$
\det(D^2u) = K(x)(1 + |Du|^2)^{\frac{n+2}{2}} \quad \text{in } \Omega
$$

for some $K \in C(\bar{\Omega})$. Then if

$$
K_0 \equiv \int_{\Omega} |K(x)| < \omega_n
$$

we have

$$
\sup_{\Omega} |u| \le \sup_{\partial \Omega} |u| + C \operatorname{diam}(\Omega)
$$

where $C$ is a positive constant depending only on $n$ and $K_0$.

We finish this section by proving a maximum principle in a domain with small volume that is due to Varadhan.

Consider

$$
Lu \equiv a_{ij} D_{ij} u + b_i D_i u + c u \quad \text{in } \Omega
$$

where $\{a_{ij}\}$ is positive definite pointwise in $\Omega$ and

$$
|b_i| + |c| \le \Lambda \quad \text{and} \quad \det(a_{ij}) \ge \lambda
$$

for some positive constants $\lambda$ and $\Lambda$.

THEOREM 2.32 Suppose $u \in C(\bar{\Omega}) \cap C^2(\Omega)$ satisfies $Lu \ge 0$ in $\Omega$ with $u \le 0$ on $\partial\Omega$. Assume $\operatorname{diam}(\Omega) \le d$. Then there is a positive constant $\delta = \delta(n, \lambda, \Lambda, d) > 0$ such that if $|\Omega| \le \delta$ then $u \le 0$ in $\Omega$.

PROOF: If $c \le 0$, then $u \le 0$ by Theorem 2.21. In general, write $c = c^+ - c^-$.
Then

$$
a_{ij} D_{ij} u + b_i D_i u - c^- u \ge -c^+ u \quad (\equiv f).
$$

By Theorem 2.21 we have

$$
\begin{aligned} \sup_{\Omega} u &\le c(n, \lambda, \Lambda, d) \|c^+ u^+\|_{L^n(\Omega)} \\ &\le c(n, \lambda, \Lambda, d) \|c^+\|_{L^\infty} |\Omega|^{1/n} \cdot \sup_{\Omega} u \le \frac{1}{2} \sup_{\Omega} u \end{aligned}
$$

if $|\Omega|$ is small. Hence we get $u \le 0$ in $\Omega$.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAhCAIAAABBfoyNAAAAh0lEQVR4nO3WsQnAIBCF4TtJ6QjO4xxi5TiWjmDnDk7jANZeikAg114SCLm/s/kKUXhIRPBM5iFX6VfpjZ1776WUtZYEtdbGGIGuhRAk6Jlzjl/InBMAaq0kCADGGJy+6wcR0TdfiNJKK6200r+n+Vg4yjm31iSuMYaPhZSSRDxCRO89fnIE78mJfP265uD1AAAAAElFTkSuQmCC)

REMARK 2.33. Compare this with Proposition 2.13, the maximum principle for a narrow domain.