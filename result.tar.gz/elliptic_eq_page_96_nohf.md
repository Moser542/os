COROLLARY 4.20 (Liouville Theorem) Suppose $u$ is a solution to a homogeneous equation in $\mathbb{R}^n$

$$
\int_{\mathbb{R}^n} a_{ij} D_i u D_j \varphi = 0 \quad \text{for any } \varphi \in H_0^1(\mathbb{R}^n).
$$

If $u$ is bounded, then $u$ is a constant.

PROOF: We showed that there exists a $\gamma < 1$ such that

$$
\omega(r) \le \gamma\omega(2r).
$$

By iteration we have

$$
\omega(r) \le \gamma^k \omega(2^k r) \to 0 \quad \text{as } k \to \infty
$$

since $\omega(2^k r) \le C$ if $u$ is bounded. Hence for any $r > 0$, $\omega(r) = 0$. $\square$

## 4.5. Nonlinear Equations

Up to now, we have been discussing linear equations of the form

$$
-D_j (a_{ij}(x) D_i u) = f(x) \quad \text{in } B_1.
$$

It is natural to ask how they generalize to nonlinear equations. To answer this question, let us consider the equation for a solution $v$ with the form

$$
v(x) = \Phi(u(x))
$$

for some smooth function $\Phi : \mathbb{R} \to \mathbb{R}$ with $\Phi' \ne 0$. Any estimates for $u$ can be translated to those for $v$. To find the equation for $v$, we write

$$
u = \Psi(v)
$$

with $\Psi = \Phi^{-1}$. Then by setting $\eta = \Psi'(v)\xi$ for $\xi \in C_0^\infty(B_1)$ we have

$$
\begin{aligned} \int a_{ij} D_i u D_j \xi &= \int a_{ij} \Psi'(v) D_i v D_j \xi \\ &= \int a_{ij} D_i v D_j \eta - \int \frac{\Psi''(v)}{\Psi'(v)} a_{ij} D_i v D_j v \eta. \end{aligned}
$$

Therefore, if $u$ is a solution

$$
\int a_{ij} D_i u D_j \xi = \int f(x) \xi \quad \text{for any } \xi \in H_0^1(B_1),
$$

then $v$ satisfies

$$
\int a_{ij} D_i v D_j \eta = \int \left( \frac{\Psi''(v)}{\Psi'(v)} a_{ij} D_i v D_j v + \frac{1}{\Psi'(v)} f \right) \eta \quad \text{for any } \eta \in C_0^\infty(B_1).
$$

Note that the nonlinear term has quadratic growth in terms of $Dv$. Hence we may extend the space of test functions to $H_0^1(B_1) \cap L^\infty(B_1)$. It turns out that $H^1(B_1) \cap L^\infty(B_1)$ is also the right space for the solution. The following example illustrates that the boundedness of solutions is essential: