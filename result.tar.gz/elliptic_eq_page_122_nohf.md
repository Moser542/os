where $C > 0$ and $\gamma \in (0, 1)$, as in Lemma 5.18, depend only on $n$, $\lambda$, and $\Lambda$. Consider $h|_{\bar{B}_{6\sqrt{n}}}$.
Extend $h$ outside $\bar{B}_{6\sqrt{n}}$ continuously such that $h = u$ in $\Omega \setminus B_{7\sqrt{n}}$ and $|u - h|_{L^\infty(\Omega)} = |u - h|_{L^\infty(B_{6\sqrt{n}})}$. Note $|h| \le 1$ in $\Omega$. It follows that $|u - h|_{L^\infty(\Omega)} \le 2$ and hence with (5.24)

$$
-2 - |x|^2 \le h(x) \le 2 + |x|^2 \quad \text{for any } x \in \Omega \setminus \bar{B}_{6\sqrt{n}}.
$$

Then there exists an $N > 1$, depending only on $n$, $\lambda$, and $\Lambda$, such that

$$
(5.27) \qquad Q_1 \subset G_N(h, \Omega).
$$

Consider

$$
w = \frac{\min\{1, \delta_0\}}{2C\varepsilon^\gamma} (u - h)
$$

where $\delta_0$ is the constant in Lemma 5.15 and $C$ and $\gamma$ are constants in (5.25) and (5.26). It is easy to check that $w$ satisfies the hypotheses of Lemma 5.15 in $\Omega$. We may apply Lemma 5.15 to get

$$
|A_t(w, \Omega) \cap Q_1| \le Ct^{-\mu} \quad \text{for any } t > 0.
$$

Therefore we have

$$
|A_s(u - h, \Omega) \cap Q_1| \le C\varepsilon^{\gamma\mu}s^{-\mu} \quad \text{for any } s > 0.
$$

It follows that

$$
|G_N(u - h, \Omega) \cap Q_1| \ge 1 - C_1\varepsilon^{\gamma\mu} \ge 1 - \varepsilon_0
$$

if we choose $\varepsilon = \varepsilon(n, \lambda, \Lambda, \varepsilon_0) \in (0, 1)$ small. With (5.27) we get

$$
|G_{2N}(u, \Omega) \cap Q_1| \ge 1 - \varepsilon_0.
$$

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAdCAIAAADZ8fBYAAAAZUlEQVR4nGP8//8/Aw0AEy0MHYLmsiBznjx5UlJSQrmhFhYWDP+RwJUrVyg3FAKwhENLS8t/CkBDQwN2c2nl3lFzR80dNXfU3FFzR82lm7ksmEIrVqy4fPky2SZCK3Va1POysrIArdpq2yknn5cAAAAASUVORK5CYII=)

**REMARK 5.25.** In fact, we prove Lemma 5.24 with assumption (5.22) replaced by (5.23).

**PROOF OF THEOREM 5.23:** Our proof has three steps.

*Step 1.* For any $\varepsilon_0 \in (0, 1)$ there exist an $M > 1$, depending only on $n$, $\lambda$, and $\Lambda$, and an $\varepsilon \in (0, 1)$, depending only on $n$, $\lambda$, $\Lambda$, and $\varepsilon_0$, such that under the assumptions of Theorem 5.23 there holds

$$
(5.28) \qquad |G_M(u, B_{8\sqrt{n}}) \cap Q_1| \ge 1 - \varepsilon_0.
$$

We remark that $M$ does not depend on $\varepsilon_0$. In fact, we have $|u| \le 1 \le |x|^2$ in $B_{8\sqrt{n}} \setminus B_{6\sqrt{n}}$. We may apply Lemma 5.24 to get (5.28) with $\Omega = B_{8\sqrt{n}}$ (see Remark 5.25).

*Step 2.* We set, for $k = 0, 1, \dots$,

$$
A = A_{M^{k+1}}(u, B_{8\sqrt{n}}) \cap Q_1,
$$

$$
B = (A_{M^k}(u, B_{8\sqrt{n}}) \cap Q_1) \cup \{x \in Q_1 : m(f^n)(x) \ge (c_1 M^k)^n\},
$$