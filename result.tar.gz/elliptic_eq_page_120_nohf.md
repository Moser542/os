5.5. $W^{2,p}$ Estimates

In this section we will prove the $W^{2,p}$-estimates for viscosity solutions. We always assume throughout this section that $a_{ij} \in C(B_1)$ satisfies

$$
\lambda|\xi|^2 \le a_{ij}(x)\xi_i\xi_j \le \Lambda|\xi|^2 \quad \text{for any } x \in B_1 \text{ and any } \xi \in \mathbb{R}^n
$$

for some positive constants $\lambda$ and $\Lambda$ and that $f$ is a continuous function in $B_1$.

The main result in this section is the following theorem.

THEOREM 5.22 Suppose $u \in C(B_1)$ is a viscosity solution of

$$
a_{ij} D_{ij} u = f \quad \text{in } B_1.
$$

Then for any $p \in (n, \infty)$ there exists an $\varepsilon > 0$, depending only on $n$, $\lambda$, $\Lambda$, and $p$, such that if

$$
\left( \frac{1}{|B_r(x_0)|} \int_{B_r(x_0)} |a_{ij} - a_{ij}(x_0)|^n \right)^{\frac{1}{n}} \le \varepsilon \quad \text{for any } B_r(x_0) \subset B_1,
$$

then $u \in W_{\text{loc}}^{2,p}(B_1)$. Moreover, there holds

$$
\|u\|_{W^{2,p}(B_{1/2})} \le C\{|u|_{L^{\infty}(B_1)} + \|f\|_{L^p(B_1)}\}
$$

where $C$ is a positive constant depending only on $n$, $\lambda$, $\Lambda$, and $p$.

As before we prove the following result instead.

THEOREM 5.23 Suppose $u \in C(B_{8\sqrt{n}})$ is a viscosity solution of

$$
a_{ij} D_{ij} u = f \quad \text{in } B_{8\sqrt{n}}.
$$

Then for any $p \in (n, \infty)$ there exist positive constants $\varepsilon$ and $C$, depending only on $n$, $\lambda$, $\Lambda$, and $p$, such that if

$$
\|u\|_{L^{\infty}(B_{8\sqrt{n}})} \le 1, \quad \|f\|_{L^p(B_{8\sqrt{n}})} \le \varepsilon,
$$

and

$$
\left( \frac{1}{|B_r(x_0)|} \int_{B_r(x_0)} |a_{ij} - a_{ij}(x_0)|^n \right)^{\frac{1}{n}} \le \varepsilon \quad \text{for any } B_r(x_0) \subset B_{8\sqrt{n}},
$$

then $u \in W^{2,p}(B_1)$ and $\|u\|_{W^{2,p}(B_1)} \le C$.

Before the proof we first describe the strategy. Let $\Omega$ be a bounded domain and $u$ be a continuous function in $\Omega$. As in Section 2, we define for $M > 0$

$$
G_M(u, \Omega) = \{x_0 \in \Omega : \text{there exists an affine function } L \text{ such that} \\ L(x) - \frac{M}{2}|x - x_0|^2 \le u(x) \le L(x) + \frac{M}{2}|x - x_0|^2 \\ \text{for } x \in \Omega \text{ with equality at } x_0\},
$$

$$
A_M(u, \Omega) = \Omega \setminus G_M(u, \Omega).
$$

We consider the function

$$
\theta(x) = \theta(u, \Omega)(x) = \inf\{M : x \in G_M(u, \Omega)\} \in [0, \infty] \quad \text{for } x \in \Omega.
$$