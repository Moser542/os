Dirichlet problem. We shall end the section with a brief mention of the minimal surface equation.

**THEOREM 6.20 (Schauder's Fixed-Point Theorem)** Let $\mathcal{G}$ be a compact, convex set in a Banach space $X$, and let $T$ be a continuous mapping of $\mathcal{G}$ into itself. Then $T$ has a fixed point; that is, for some $x \in \mathcal{G}$, $Tx = x$.

**PROOF:** Let $k \in N$. Since $\mathcal{G}$ is compact, there is a finite set $\{x_1, x_2, \dots, x_n\}$ where $n = n(k)$ such that the balls $B_i = B_{i/k}(x_i)$, $i = 1, 2, \dots, n$, cover $\mathcal{G}$. Let $\mathcal{G}_k$ be the convex hull of $\{x_1, x_2, \dots, x_n\}$ and let $J_k : \mathcal{G} \to \mathcal{G}_k$ be defined by

$$
(6.21) \qquad J_k(x) = \frac{\sum_i \text{dist}(x, \mathcal{G} - B_i)x_i}{\sum_i \text{dist}(x, \mathcal{G} - B_i)}.
$$

It is easy to see that $J_k$ is continuous on $\mathcal{G}$; furthermore,

$$
\|J_k(x) - x\| \le \frac{\sum_i \text{dist}(x, \mathcal{G} - B_i)\|x - x_i\|}{\sum_i \text{dist}(x, \mathcal{G} - B_i)} < \frac{1}{k}.
$$

The mapping $J_k \circ T : \mathcal{G}_k \to \mathcal{G}_k$. Thus by the Brouwer fixed-point theorem, there exist $y_k \in \mathcal{G}_k$ such that $J_k \circ T(y_k) = y_k$, $k = 1, 2, \dots$. Since $\mathcal{G}$ is compact, one may assume, without loss of generality, that $y_k \to x \in \mathcal{G}$. Since

$$
\|y_k - T(y_k)\| = \|J_k \circ T(y_k) - T(y_k)\| < \frac{1}{k},
$$

and since $T$ is continuous, we have

$$
\lim_{k \to \infty} y_k = x = Tx \quad \text{for some } x \in \mathcal{G}.
$$

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAIAAAC0Ujn1AAAAi0lEQVR4nO3WvQ0DIQwF4GebFRgLOhpGYhM2pOAnBVKkkKsgV5ziV4L0gWwkQ2MM3BO+yX0sbb6Xeu+HDSAiZsb4TErpBH3He7/SMcaf0MaYtdatNQA557qbUgqAWutFrQGIiIgcXvyZj09ppZVWWum/p69nYwiBefPU+Ydh5pW21s7tOdr3QkTOuRcQ6XjiAUbMagAAAABJRU5ErkJggg==)

**COROLLARY 6.21** Let $\mathcal{G}$ be a closed, convex set in a Banach space $X$. Suppose $T$ is a map from $\mathcal{G}$ into $\mathcal{G}$ such that $TG$ is precompact. Then $T$ has a fixed point in $\mathcal{G}$.

Note that a continuous mapping between two Banach spaces is called *compact* (or *completely continuous*) if the images of bounded sets are precompact; that is, their closures are compact.

**THEOREM 6.22 (Leray-Schauder Theorem)** Let $T$ be a compact mapping of a Banach space $X$ into itself, and suppose there is a constant $M$ such that

$$
(6.22) \qquad \|x\| < M
$$

for all $x \in X$ and $\sigma \in [0, 1]$ satisfying $x = \sigma Tx$. Then $T$ has a fixed point.

**PROOF:** Define a new mapping $T^*$ by

$$
(6.23) \qquad \begin{cases} T^*x = Tx & \text{if } \|Tx\| \le M, \\ T^*x = M \frac{Tx}{\|Tx\|} & \text{if } \|Tx\| \ge M. \end{cases}
$$

$T^*$ is clearly a continuous mapping of the closed ball $\overline{B}_M$ into $\overline{B}_M \subset X$ itself. Since $T(\overline{B}_M)$ is precompact, the same is true for $T^*(\overline{B}_M)$. Hence by Corollary 6.21, the mapping $T^*$ has a fixed point $x$. We claim $x$ is also a fixed point of $T$. Indeed, if $\|Tx\| \ge M$, then $x = T^*x = \frac{M}{\|Tx\|}Tx = \sigma Tx$ where $\sigma = \frac{M}{\|Tx\|} \in (0, 1]$. By