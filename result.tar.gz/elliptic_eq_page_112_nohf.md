Let $\Omega$ be a bounded domain and $u$ be a continuous function in $\Omega$. We define for $M > 0$

$$
G_M^{-}(u, \Omega) = \{x_0 \in \Omega : \text{there exists an affine function } L \text{ such that} \\ L(x) - \frac{M}{2}|x - x_0|^2 \le u(x) \text{ for } x \in \Omega \\ \text{with equality at } x_0\},
$$

$$
G_M^{+}(u, \Omega) = \{x_0 \in \Omega : \text{there exists an affine function } L \text{ such that} \\ L(x) + \frac{M}{2}|x - x_0|^2 \ge u(x) \text{ for } x \in \Omega \\ \text{with equality at } x_0\},
$$

$$
G_M(u, \Omega) = G_M^{+}(u, \Omega) \cap G_M^{-}(u, \Omega).
$$

We also define

$$
\begin{aligned} A_M^{-}(u, \Omega) &= \Omega \setminus G_M^{-}(u, \Omega), \\ A_M^{+}(u, \Omega) &= \Omega \setminus G_M^{+}(u, \Omega), \\ A_M(u, \Omega) &= \Omega \setminus G_M(u, \Omega). \end{aligned}
$$

In other words, $G_M^{-}(u, \Omega)$ (respectively, $G_M^{+}(u, \Omega)$) consists of points where there is a concave (respectively, convex) paraboloid of opening $M$ touching $u$ from below (respectively, above). Intuitively $|A_M(u, \Omega)|$ behaves like the distribution function of $D^2u$. Hence for integrability of $D^2u$ we need to study the decay of $|A_M(u, \Omega)|$.

LEMMA 5.15 Suppose that $\Omega$ is a bounded domain with $B_{6\sqrt{n}} \subset \Omega$ and that $u$ belongs to $S^+(\lambda, \Lambda, f)$ in $B_{6\sqrt{n}}$ for some $f \in C(B_{6\sqrt{n}})$. Then there exist positive constants $\delta_0$, $\mu$, and $C$, depending only on $n$, $\lambda$, and $\Lambda$, such that if $|u| \le 1$ in $\Omega$ and $\|f\|_{L^n(B_{6\sqrt{n}})} \le \delta_0$ there holds

$$
|A_t^{-}(u, \Omega) \cap Q_1| \le Ct^{-\mu} \quad \text{for any } t > 0.
$$

If, in addition, $u \in S(\lambda, \Lambda, f)$ in $B_{6\sqrt{n}}$, then

$$
|A_t(u, \Omega) \cap Q_1| \le Ct^{-\mu} \quad \text{for any } t > 0.
$$

In the proof of Lemma 5.15 we need the *maximal functions* of local integrable functions. For $g \in L_{\text{loc}}^1(\mathbb{R}^n)$ we define

$$
m(g)(x) = \sup_{r>0} \frac{1}{|Q_r(x)|} \int_{Q_r(x)} |g|.
$$

The maximal operator $m$ is of weak type $(1, 1)$ and of strong type $(p, p)$ for $1 < p \le \infty$, that is,

$$
\begin{aligned} |\{x \in \mathbb{R}^n : m(g)(x) \ge t\}| &\le \frac{c_1(n)}{t} \|g\|_{L^1(\mathbb{R}^n)} \quad \text{for any } t > 0, \\ \|m(g)\|_{L^p(\mathbb{R}^n)} &\le c_2(n, p) \|g\|_{L^p(\mathbb{R}^n)} \quad \text{for } 1 < p \le \infty. \end{aligned}
$$