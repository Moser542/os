hypothesis, we would have $\|x\| < M$. On the other hand, $\|x\| = \|T^*x\| = M$; a contradiction. Thus $\|Tx\| < M$ must be true and consequently $T^*x = x = Tx$.

REMARK. Suppose $T$ is a compact mapping of a Banach space $X$ into itself. Then for some $\sigma \in (0, 1]$, the map $\sigma T$ possesses a fixed point. Indeed, since $T(\overline{B_1})$ is compact in $X$, there is an $A \ge 1$ such that $\|Tx\| \le A$ for all $x \in \overline{B_1}$. Thus the mapping $\sigma T$ with $\sigma = \frac{1}{A}$ maps $\overline{B_1}$ into itself and our conclusion follows. Also, note that if (6.22) is valid, then for any $\sigma \in [0, 1]$, the mapping $\sigma T$ has a fixed point as well.

Next we shall describe a situation in which Theorem 6.22 can be applied. For $\beta \in (0, 1)$, we consider the Banach space $X = C^{1,\beta}(\overline{\Omega})$ where $\Omega$ is a $C^{2,\alpha}$, bounded domain in $\mathbb{R}^n$. Let $L$ be an operator given by

$$
(6.24) \qquad Lu = a^{ij}(x, u, \nabla u)u_{x_i x_j} + b(x, u, \nabla u).
$$

We assume that $L$ is elliptic in $\overline{\Omega}$; i.e., $(a^{ij}(x, \zeta, p))$ is positive definite for all $(x, \zeta, p) \in \overline{\Omega} \times \mathbb{R} \times \mathbb{R}^n$. We also assume, for some $\alpha \in (0, 1)$, that $a^{ij}, b \in C^\alpha(\overline{\Omega} \times \mathbb{R} \times \mathbb{R}^n)$. Let $\phi \in C^{2,\alpha}(\partial\Omega)$. For all $v \in C^{1,\beta}(\overline{\Omega}) = X$, we let $u = Tv$ be the unique solution in $C^{2,\alpha\beta}(\overline{\Omega})$ of the linear Dirichlet problem

$$
(6.25) \qquad \begin{cases} a^{ij}(x, v, Dv)u_{x_i x_j} + b(x, v, Dv) = 0 & \text{in } \Omega, \\ u|_{\partial\Omega} = \phi & \text{on } \partial\Omega. \end{cases}
$$

We note that the solvability of $Lu = 0$ in $\Omega$ with $u = \phi$ on $\partial\Omega$ in the space $C^{2,\alpha}(\overline{\Omega})$ is equivalent to the solvability of $Tu = u$ in $X$.

Let

$$
(6.26) \qquad L_{\sigma}u = a^{ij}(x, u, Du)u_{x_i x_j} + \sigma b(x, u, \nabla u).
$$

Then $u = \sigma Tu$ in $X$ is the same as $L_{\sigma}u = 0$ in $\Omega$ and $u = \sigma\phi$ on $\partial\Omega$. As a consequence of the Leray-Schauder theorem, we have the following:

THEOREM 6.23 Let $\Omega, \phi$, and $L$ be as above. If, for some $\beta > 0$, there is a constant $M$ independent of $u$ and $\sigma$ such that every $C^{2,\alpha}(\overline{\Omega})$-solution of the Dirichlet problem

$$
(6.27) \qquad \begin{cases} L_{\sigma}u = 0 & \text{in } \Omega, \\ u = \sigma\phi & \text{on } \partial\Omega, \end{cases}
$$

satisfies

$$
(6.28) \qquad \|u\|_{C^{1,\beta}(\overline{\Omega})} < M,
$$

then it follows that the Dirichlet problem $Lu = 0$ in $\Omega$ with $u = \phi$ on $\partial\Omega$ is solvable in $C^{2,\alpha}(\overline{\Omega})$.

PROOF: From the preceding discussion, it suffices to verify that $T$ is continuous and compact. Again, this is simply a consequence of the Schauder estimates. We note that $C^{2,\alpha\beta}(\overline{\Omega})$ is precompact in $C^{1,\beta}(\overline{\Omega})$. $\square$