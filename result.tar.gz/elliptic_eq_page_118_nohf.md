We claim that there exist $0 < \mu < 1$, depending only on $n$, $\lambda$, $\Lambda$, and $\alpha$, and a sequence of polynomials of degree 2

$$
P_k(x) = a_k + b_k \cdot x + \frac{1}{2} x^\top C_k x
$$

such that for any $k = 0, 1, \dots$,

$$
(5.19) \qquad a_{ij}(0) D_{ij} P_k = 0, \quad |u - P_k|_{L^\infty(B_{\mu^k})} \le \mu^{k(2+\alpha)},
$$

$$
(5.20) \qquad \begin{aligned} & |a_k - a_{k-1}| + \mu^{k-1} |b_k - b_{k-1}| + \mu^{2(k-1)} |C_k - C_{k-1}| \\ & \le C \mu^{(k-1)(2+\alpha)} \end{aligned}
$$

where $P_0 = P_{-1} \equiv 0$ and $C$ is a positive constant depending only on $n$, $\lambda$, $\Lambda$, and $\alpha$.

We first prove that Theorem 5.20 follows from (5.19) and (5.20). It is easy to see that $a_k$, $b_k$, and $C_k$ converge and that the limiting polynomial

$$
p(x) = a_\infty + b_\infty \cdot x + \frac{1}{2} x^\top C_\infty x
$$

satisfies

$$
|P_k(x) - p(x)| \le C \{|x|^2 \mu^{\alpha k} + |x| \mu^{(\alpha+1)k} + \mu^{(\alpha+2)k}\} \le C \mu^{(2+\alpha)k}
$$

for any $|x| \le \mu^k$. Hence we have for $|x| \le \mu^k$

$$
|u(x) - p(x)| \le |u(x) - P_k(x)| + |P_k(x) - p(x)| \le C \mu^{(2+\alpha)k},
$$

which implies that

$$
|u(x) - p(x)| \le C |x|^{2+\alpha} \quad \text{for any } x \in B_1.
$$

Now we prove (5.19) and (5.20). Clearly (5.19) and (5.20) hold for $k = 0$. Assume they hold for $k = 0, 1, \dots, l$. We prove for $k = l + 1$. Consider the function

$$
\tilde{u}(y) = \frac{1}{\mu^{l(2+\alpha)}} (u - P_l)(\mu^l y) \quad \text{for } y \in B_1.
$$

Then $\tilde{u} \in C(B_1)$ is a viscosity solution of

$$
\tilde{a}_{ij} D_{ij} \tilde{u} = \tilde{f} \quad \text{in } B_1
$$

with

$$
\tilde{a}_{ij}(y) = \frac{1}{\mu^{l\alpha}} a_{ij}(\mu^l y),
$$

$$
\tilde{f}(y) = \frac{1}{\mu^{l\alpha}} \{f(\mu^l y) - a_{ij}(\mu^l y) D_{ij} P_k\}.
$$

Now we check that $\tilde{u}$ satisfies the assumptions of Lemma 5.18. For that we calculate

$$
\|\tilde{a}_{ij} - \tilde{a}_{ij}(0)\|_{L^n(B_1)} \le \frac{1}{\mu^{l\alpha}} \|a_{ij} - a_{ij}(0)\|_{L^n(B_{\mu^l})} \le [a_{ij}]_{C_{L^n}^{\alpha}}(0) \le \delta
$$