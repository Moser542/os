Then for any $0 < \rho \le r$, there hold

$$
(1.9) \qquad \int_{B_{\rho}} |u|^2 \le c \left(\frac{\rho}{r}\right)^n \int_{B_r} |u|^2,
$$

$$
(1.10) \qquad \int_{B_{\rho}} |u - u_{\rho}|^2 \le c \left(\frac{\rho}{r}\right)^{n+2} \int_{B_r} |u - u_r|^2,
$$

where $c = c(\lambda, \Lambda)$ is a positive constant and $u_r$ denotes the average of $u$ in $B_r$.

PROOF: By dilation, consider $r = 1$. We restrict our consideration to the range $\rho \in (0, \frac{1}{2}]$, since (1.9) and (1.10) are trivial for $\rho \in (\frac{1}{2}, 1]$. $\square$

CLAIM.

$$
|u|_{L^{\infty}(B_{1/2})}^2 + |Du|_{L^{\infty}(B_{1/2})}^2 \le c(\lambda, \Lambda) \int_{B_1} |u|^2.
$$

Therefore for $\rho \in (0, \frac{1}{2}]$

$$
\int_{B_{\rho}} |u|^2 \le \rho^n |u|_{L^{\infty}(B_{1/2})}^2 \le c \rho^n \int_{B_1} |u|^2
$$

and

$$
\int_{B_{\rho}} |u - u_{\rho}|^2 \le \int_{B_{\rho}} |u - u(0)|^2 \le \rho^{n+2} |Du|_{L^{\infty}(B_{1/2})}^2 \le c \rho^{n+2} \int_{B_1} |u|^2.
$$

If $u$ is a solution of (1.8), so is $u - u_1$. With $u$ replaced by $u - u_1$ in the above inequality, there holds

$$
\int_{B_{\rho}} |u - u_{\rho}|^2 \le c \rho^{n+2} \int_{B_1} |u - u_1|^2.
$$

PROOF: We present two methods.

METHOD 1. By rotation, we may assume $\{a_{ij}\}$ is a diagonal matrix. Hence (1.8) becomes

$$
\sum_{i=1}^{n} \lambda_i D_{ii} u = 0
$$

with $0 < \lambda \le \lambda_i \le \Lambda$ for $i = 1, \dots, n$. It is easy to see there exists an $r_0 = r_0(\lambda, \Lambda) \in (0, \frac{1}{2})$ such that for any $x_0 \in B_{1/2}$ the rectangle

$$
\left\{ x : \frac{|x_i - x_{0i}|}{\sqrt{\lambda_i}} < r_0 \right\}
$$

is contained in $B_1$. Change the coordinate

$$
x_i \mapsto y_i = \frac{x_i}{\sqrt{\lambda_i}} \quad \text{and set} \quad v(y) = u(x).
$$