where $\lambda$ and $\Lambda$ are two positive constants, which denote, respectively, the minimal and maximal eigenvalues of $A$.

Before stating the main theorem, we first introduce the concept of contact sets. For $u \in C^2(\Omega)$ we define

$$
\Gamma^+ = \{y \in \Omega : u(x) \le u(y) + Du(y) \cdot (x - y) \text{ for any } x \in \Omega\}.
$$

The set $\Gamma^+$ is called the upper contact set of $u$, and the Hessian matrix $D^2u = (D_{ij}u)$ is nonpositive on $\Gamma^+$. In fact, the upper contact set can also be defined for continuous function $u$ by the following:

$$
\Gamma^+ = \{y \in \Omega : u(x) \le u(y) + p \cdot (x - y) \text{ for any } x \in \Omega \text{ and some } p = p(y) \in \mathbb{R}^n\}.
$$

Clearly, $u$ is concave if and only if $\Gamma^+ = \Omega$. If $u \in C^1(\Omega)$, then $p(y) = Du(y)$, and any support hyperplane must then be a tangent plane to the graph.

Now we consider the equation of the form

$$
Lu = f \quad \text{in } \Omega
$$

for some $f \in C(\Omega)$.

THEOREM 2.21 Suppose $u \in C(\bar{\Omega}) \cap C^2(\Omega)$ satisfies $Lu \ge f$ in $\Omega$ with the following conditions:

$$
\frac{|\mathbf{b}|}{D^*}, \frac{f}{D^*} \in L^n(\Omega) \quad \text{and} \quad c \le 0 \text{ in } \Omega.
$$

Then there holds

$$
\sup_{\Omega} u \le \sup_{\partial \Omega} u^+ + C \left\| \frac{f^-}{D^*} \right\|_{L^n(\Gamma^+)}
$$

where $\Gamma^+$ is the upper contact set of $u$ and $C$ is a constant depending only on $n$, $\text{diam}(\Omega)$, and $\|\frac{\mathbf{b}}{D^*}\|_{L^n(\Gamma^+)}$. In fact, $C$ can be written as

$$
d \cdot \left\{ \exp \left\{ \frac{2^{n-2}}{\omega_n n^n} \left( \left\| \frac{\mathbf{b}}{D^*} \right\|_{L^n(\Gamma^+)}^n + 1 \right) \right\} - 1 \right\}
$$

with $\omega_n$ as the volume of the unit ball in $\mathbb{R}^n$. Here $\mathbf{b} = (b_1, b_2, \dots, b_n)$.

REMARK 2.22. The integral domain $\Gamma^+$ can be replaced by

$$
\Gamma^+ \cap \{x \in \Omega : u(x) > \sup_{\partial \Omega} u^+\}.
$$

REMARK 2.23. There is no assumption on uniform ellipticity. Compare with Hopf's maximum principle in Section 1.

We need a lemma first.

LEMMA 2.24 Suppose $g \in L_{\text{loc}}^1(\mathbb{R}^n)$ is nonnegative. Then for any $u \in C(\bar{\Omega}) \cap C^2(\Omega)$ there holds

$$
\int_{B_{\tilde{M}}(0)} g \le \int_{\Gamma^+} g(Du) |\det D^2 u|
$$