PROOF: We define a linear functional $F$ on $H_0^1(\Omega)$ by

$$
F(\varphi) = \int_{\Omega} f\varphi \, dx
$$

for any $\varphi \in H_0^1(\Omega)$. By the Cauchy inequality and the Poincaré inequality, we have

$$
|F(\varphi)| \le \|f\|_{L^2(\Omega)} \|\varphi\|_{L^2(\Omega)} \le C \|f\|_{L^2(\Omega)} \|\varphi\|_{H_0^1(\Omega)}.
$$

Hence $F$ is a bounded linear functional on $H_0^1(\Omega)$.

We first consider a special case where $a$ is symmetric. (This includes the case $a_{ij} = a_{ji}$ and $c \ge 0$.) It is easy to see that $a(u, v)$ is an inner product in $H_0^1(\Omega)$ that is equivalent to the standard $H_0^1(\Omega)$ inner product. By the Riesz representation theorem, there exists a $u \in H_0^1(\Omega)$ such that

$$
a(u, \varphi) = F(\varphi)
$$

for any $\varphi \in H_0^1(\Omega)$. Therefore, $u$ is the desired solution.

We now consider the general case where $a$ is not necessarily symmetric. We first note that

$$
|a(u, v)| \le C \|u\|_{H_0^1(\Omega)} \|v\|_{H_0^1(\Omega)}
$$

for any $u, v \in H_0^1(\Omega)$.

For each fixed $u \in H_0^1(\Omega)$, the mapping $v \mapsto a(u, v)$ is a bounded linear functional on $H_0^1(\Omega)$. By the Riesz representation theorem, there exists a unique $w \in H_0^1(\Omega)$ such that

$$
a(u, v) = (w, v)_{H_0^1(\Omega)}
$$

for any $v \in H_0^1(\Omega)$. Now we write $w = Au$; i.e.,

$$
a(u, v) = (Au, v)_{H_0^1(\Omega)}
$$

for any $u, v \in H_0^1(\Omega)$. It is straightforward to check that $A$ is a linear operator on $H_0^1(\Omega)$.

Next,

$$
\|Au\|_{H_0^1(\Omega)}^2 = (Au, Au)_{H_0^1(\Omega)} = a(u, Au) \le C \|u\|_{H_0^1(\Omega)} \|Au\|_{H_0^1(\Omega)}
$$

and hence

$$
\|Au\|_{H_0^1(\Omega)} \le C \|u\|_{H_0^1(\Omega)} \quad \text{for any } u \in H_0^1(\Omega).
$$

Therefore, $A : H_0^1(\Omega) \to H_0^1(\Omega)$ is a bounded linear operator. By the coerciveness, we have

$$
c_0 \|u\|_{H_0^1(\Omega)}^2 \le a(u, u) = (Au, u)_{H_0^1(\Omega)} \le \|u\|_{H_0^1(\Omega)} \|Au\|_{H_0^1(\Omega)}
$$

and hence

$$
c_0 \|u\|_{H_0^1(\Omega)} \le \|Au\|_{H_0^1(\Omega)}
$$

for any $u \in H_0^1(\Omega)$. It follows that $A$ is one-to-one and the range $R(A)$ of $A$ is closed in $H_0^1(\Omega)$.