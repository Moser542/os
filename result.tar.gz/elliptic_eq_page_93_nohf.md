for some $C = C(n, q, \lambda, \Lambda, r_1, r_2, p_1, p_2) > 0$. A similar calculation may be found in Section 4.2 (Method 2). Here we just point out some key steps.

Take $\varphi = \bar{u}^{-\beta}\eta^2$ for $\beta \in (0, 1)$ as the test function in $(*)$. Then we have

$$
\int_{B_1} |D\bar{u}|^2 \bar{u}^{-\beta-1} \eta^2 \le C \left\{ \frac{1}{\beta^2} \int_{B_1} |D\eta|^2 \bar{u}^{1-\beta} + \frac{1}{\beta} \int_{B_1} \frac{|f|}{k} \eta^2 \bar{u}^{1-\beta} \right\}.
$$

Set $\gamma = 1 - \beta \in (0, 1)$ and $w = \bar{u}^{\gamma/2}$. Then we have

$$
\int |Dw|^2 \eta^2 \le \frac{C}{(1-\gamma)^\alpha} \int w^2 (|D\eta|^2 + \eta^2)
$$

or

$$
\int |D(w\eta)|^2 \le \frac{C}{(1-\gamma)^\alpha} \int w^2 (|D\eta|^2 + \eta^2)
$$

for some positive $\alpha > 0$. The Sobolev embedding theorem and an appropriate choice for the cutoff function imply, with $\chi = \frac{n}{n-2}$, that for any $0 < r < R < 1$

$$
\left( \int_{B_r} w^2 \chi \right)^{\frac{1}{\chi}} \le \frac{C}{(1-\gamma)^\alpha} \cdot \frac{1}{(R-r)^2} \int_{B_R} w^2
$$

or

$$
\left( \int_{B_r} \bar{u}^{\gamma \chi} \right)^{\frac{1}{\gamma \chi}} \le \left( \frac{C}{(1-\gamma)^\alpha} \frac{1}{(R-r)^2} \right)^{\frac{1}{\gamma}} \left( \int_{B_R} \bar{u}^{\gamma} \right)^{\frac{1}{\gamma}}.
$$

This holds for any $\gamma \in (0, 1)$. Now (4.13) follows after finitely many iterations. $\square$

Now the Harnack inequality is an easy consequence of the above results.

**THEOREM 4.17 (Moser's Harnack Inequality)** Let $u \in H^1(\Omega)$ be a nonnegative solution in $\Omega$

$$
\int_{\Omega} a_{ij} D_i u D_j \varphi = \int_{\Omega} f \varphi \quad \text{for any } \varphi \in H_0^1(\Omega).
$$

Suppose $f \in L^q(\Omega)$ for some $q > \frac{n}{2}$. Then there holds for any $B_R \subset \Omega$

$$
\max_{B_R} u \le C \left\{ \min_{B_{R/2}} u + R^{2-\frac{n}{q}} \|f\|_{L^q(B_R)} \right\}
$$

where $C = C(n, \lambda, \Lambda, q)$ is a positive constant.

**COROLLARY 4.18 (Hölder Continuity)** Let $u \in H^1(\Omega)$ be a solution in $\Omega$

$$
\int_{\Omega} a_{ij} D_i u D_j \varphi = \int_{\Omega} f \varphi \quad \text{for any } \varphi \in H_0^1(\Omega).
$$