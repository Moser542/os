Suppose the domain $\Omega$ lies in $\{0 < x_1 < d\}$. Choose $z(x) = A + e^{\beta d} - e^{\beta x_1}$ for $x \in \Omega$ for some positive $A$ and $\beta$ to be determined. Direct calculation shows

$$
\begin{aligned}
-\frac{1}{z}(a_{ij} D_{ij} z + b_i D_i z) &= \frac{(\beta^2 a_{11} + \beta b_1)e^{\beta x_1}}{A + e^{\beta d} - e^{\beta x_1}} \\
&\geq \frac{\beta^2 a_{11} + \beta b_1}{A + e^{\beta d}} \geq \frac{1}{A + e^{\beta d}} > 0
\end{aligned}
$$

if $\beta$ is chosen such that $\beta^2 a_{11} + \beta b_1 \geq 1$. Then we have

$$
\left| \frac{1}{z} \frac{\partial z}{\partial n} \right| \leq \frac{\beta}{A} e^{\beta d} \leq \frac{1}{2} \alpha_0
$$

if $A$ is chosen large. This reduces to the special case we just discussed. The new extra first-order term does not change the result. We may apply the special case to $w$. $\square$

REMARK 2.17. The result fails if we just assume $\alpha(x) \geq 0$ on $\partial\Omega$. In fact, we cannot even get the uniqueness.

## 2.4. Gradient Estimates

The basic idea in the treatment of gradient estimates, due to Bernstein, involves differentiation of the equation with respect to $x_k$, $k = 1, \dots, n$, followed by multiplication by $D_k u$ and summation over $k$. The maximum principle is then applied to the resulting equation in the function $v = |Du|^2$, possibly with some modification. There are two kinds of gradient estimates, global gradient estimates and interior gradient estimates. We will use semilinear equations to illustrate the idea.

Suppose $\Omega$ is a bounded and connected domain in $\mathbb{R}^n$. Consider the equation

$$
a_{ij}(x) D_{ij} u + b_i(x) D_i u = f(x, u) \quad \text{in } \Omega
$$

for $u \in C^2(\Omega)$ and $f \in C(\Omega \times \mathbb{R})$. We always assume that $a_{ij}$ and $b_i$ are continuous and hence bounded in $\bar{\Omega}$ and that the equation is uniformly elliptic in $\Omega$ in the following sense:

$$
a_{ij}(x) \xi_i \xi_j \geq \lambda |\xi|^2 \quad \text{for any } x \in \Omega \text{ and any } \xi \in \mathbb{R}^n
$$

for some positive constant $\lambda$.

PROPOSITION 2.18 Suppose $u \in C^3(\Omega) \cap C^1(\bar{\Omega})$ satisfies

$$
(2.1) \qquad a_{ij}(x) D_{ij} u + b_i(x) D_i u = f(x, u) \quad \text{in } \Omega
$$

for $a_{ij}, b_i \in C^1(\bar{\Omega})$ and $f \in C^1(\bar{\Omega} \times \mathbb{R})$. Then there holds

$$
\sup_{\Omega} |Du| \leq \sup_{\partial \Omega} |Du| + C
$$

where $C$ is a positive constant depending only on $\lambda$, $\text{diam}(\Omega)$, $|a_{ij}, b_i|_{C^1(\bar{\Omega})}$, $M = |u|_{L^\infty(\Omega)}$, and $|f|_{C^1(\bar{\Omega} \times [-M, M])}$.