It is obvious if $c \equiv 0$. In fact, in this special case there is no restriction on the set $\{v\zeta \neq 0\}$. In general, the Hölder inequality implies that

$$
\begin{aligned}
\int |c|v^2\zeta^2 &\le \left(\int |c|^q\right)^{\frac{1}{q}} \left(\int (v\zeta)^{2*}\right)^{\frac{2}{2*}} |\{v\zeta \neq 0\}|^{1-\frac{2}{2*}-\frac{1}{q}} \\
&\le c(n) \int |D(v\zeta)|^2 \left(\int |c|^q\right)^{\frac{1}{q}} |\{v\zeta \neq 0\}|^{\frac{2}{n}-\frac{1}{q}}
\end{aligned}
$$

and

$$
\int |c|\zeta^2 \le \left(\int |c|^q\right)^{\frac{1}{q}} |\{v\zeta \neq 0\}|^{1-\frac{1}{q}}.
$$

Therefore we have

$$
\int |D(v\zeta)|^2 \le C \left\{ \int v^2 |D\zeta|^2 + \int |D(v\zeta)|^2 |\{v\zeta \neq 0\}|^{\frac{2}{n}-\frac{1}{q}} + (k^2 + F^2) |\{v\zeta \neq 0\}|^{1-\frac{1}{q}} \right\}.
$$

This implies (4.1) if $|\{v\zeta \neq 0\}|$ is small. To continue, we obtain by the Sobolev inequality

$$
\begin{aligned}
\int (v\zeta)^2 &\le \left(\int (v\zeta)^{2*}\right)^{\frac{2}{2*}} |\{v\zeta \neq 0\}|^{1-\frac{2}{2*}} \\
&\le c(n) \int |D(v\zeta)|^2 |\{v\zeta \neq 0\}|^{\frac{2}{n}}.
\end{aligned}
$$

Therefore we have

$$
\int (v\zeta)^2 \le C \left\{ \int v^2 |D\zeta|^2 |\{v\zeta \neq 0\}|^{\frac{2}{n}} + (k + F)^2 |\{v\zeta \neq 0\}|^{1+\frac{2}{n}-\frac{1}{q}} \right\}
$$

if $|\{v\zeta \neq 0\}|$ is small. Hence there exists an $\varepsilon > 0$ such that

$$
\int (v\zeta)^2 \le C \left\{ \int v^2 |D\zeta|^2 |\{v\zeta \neq 0\}|^{\varepsilon} + (k + F)^2 |\{v\zeta \neq 0\}|^{1+\varepsilon} \right\}
$$

if $|\{v\zeta \neq 0\}|$ is small. Choose the cutoff function in the following way. For any fixed $0 < r < R \le 1$ choose $\zeta \in C_0^\infty(B_R)$ such that $\zeta \equiv 1$ in $B_r$ and $0 \le \zeta \le 1$ and $|D\zeta| \le 2(R-r)^{-1}$ in $B_1$. Set

$$
A(k, r) = \{x \in B_r : u \ge k\}.
$$

We conclude that for any $0 < r < R \le 1$ and $k > 0$

$$
(4.2) \quad \int_{A(k,r)} (u-k)^2 \le C \left\{ \frac{1}{(R-r)^2} |A(k,R)|^\varepsilon \int_{A(k,R)} (u-k)^2 + (k+F)^2 |A(k,R)|^{1+\varepsilon} \right\}
$$