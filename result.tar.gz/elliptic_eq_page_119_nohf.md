and

$$
\|\tilde{f}\|_{L^n(B_1)} \le \frac{1}{\mu^{l\alpha}} \|f\|_{L^n(B_{\mu l})} + \frac{1}{\mu^{l\alpha}} \sup |D^2 P_l| \|a_{ij} - a_{ij}(0)\|_{L^n(B_{\mu l})} \le \delta + C\delta
$$

where we used

$$
|D^2 P_l| \le \sum_{k=1}^{l} |D^2 P_k - D^2 P_{k-1}| \le \sum_{k=1}^{l} \mu^{(k-1)\alpha} \le C.
$$

Hence we take $\varepsilon = C(n, \lambda, \Lambda)\delta$ in Lemma 5.18. Then by Lemma 5.18 there exists a function $h \in C(\bar{B}_{3/4})$ with $\tilde{a}_{ij}(0)D_{ij}h = 0$ in $B_{3/4}$ and $|h| \le 1$ in $B_{3/4}$ such that

$$
|\tilde{u} - h|_{L^{\infty}(B_{1/2})} \le C\{\varepsilon^{\gamma} + \varepsilon\} \le 2C\varepsilon^{\gamma}.
$$

Write $\tilde{P}(y) = h(0) + Dh(0) + y^T D^2 h(0) y/2$. Then by interior estimates for $h$ we have

$$
|\tilde{u} - \tilde{P}|_{L^{\infty}(B_{\mu})} \le |\tilde{u} - h|_{L^{\infty}(B_{\mu})} + |h - \tilde{P}|_{L^{\infty}(B_{\mu})} \le 2C\varepsilon^{\gamma} + C\mu^3 \le \mu^{2+\alpha}
$$

by choosing $\mu$ small and then $\varepsilon$ small accordingly. Rescaling back, we have

$$
|u(x) - P_l(x) - \mu^{l(2+\alpha)} \tilde{P}(\mu^{-l}x)| \le \mu^{(l+1)(2+\alpha)} \quad \text{for any } x \in B_{\mu^{l+1}}.
$$

This implies (5.19) for $k = l + 1$ if we define

$$
P_{k+1}(x) = \bar{P}_k(x) + \mu^{l(2+\alpha)} \tilde{P}(\mu^{-l}x).
$$

Estimate (5.20) follows easily.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAgCAIAAABhFeQrAAAAd0lEQVR4nO3WsRGAIAyF4QTXYYJMR8EADActDStQcjwr9bTUcDb5B/jIpQkMgBbkVqDmLncJRznnTSMRAXBztWZtrT33EGPEh0IIRNR7X7LfMYa55pprrrnm/uny+e8rpXjvmdm594/NOQGklPTvvIjUWq95ddsBjiC9YgVd91AAAAAASUVORK5CYII=)

To finish this section we state the Cordes-Nirenberg type estimate. The proof is similar to that of Theorem 5.20.

THEOREM 5.21 Suppose $u \in C(B_1)$ is a viscosity solution of

$$
a_{ij} D_{ij} u = f \quad \text{in } B_1.
$$

Then for any $\alpha \in (0, 1)$ there exists an $\theta > 0$, depending only on $n, \lambda, \Lambda$, and $\alpha$, such that if

$$
\left( \frac{1}{|B_r|} \int_{B_r} |a_{ij} - a_{ij}(0)|^n \right)^{\frac{1}{n}} \le \theta \quad \text{for any } 0 < r \le 1,
$$

then $u$ is $C^{1,\alpha}$ at 0; that is, there exists an affine function $L$ such that

$$
|u - L|_{L^{\infty}(B_r(0))} \le C_* r^{1+\alpha} \quad \text{for any } 0 < r < 1,
$$

$$
|L(0)| + |DL(0)| \le C_*,
$$

$$
C_* \le C \left\{ |u|_{L^{\infty}(B_1)} + \sup_{0<r<1} r^{1-\alpha} \left( \frac{1}{|B_r|} \int_{B_r} |f|^n \right)^{\frac{1}{n}} \right\},
$$

where $C$ is a positive constant depending only on $n, \lambda, \Lambda$, and $\alpha$.