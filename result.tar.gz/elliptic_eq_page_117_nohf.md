Take $\delta = \varepsilon^{1/2} < \frac{1}{4}$ and then $\gamma = \frac{\alpha}{4}$. This finishes the proof.

□

For the next result we need to introduce the following concept.

DEFINITION 5.19 A function $g$ is Hölder-continuous at 0 with exponent $\alpha$ in the $L^n$ sense if

$$
[g]_{C_{L^n}^\alpha}(0) \equiv \sup_{0<r<1} \frac{1}{r^\alpha} \left( \frac{1}{|B_r|} \int_{B_r} |g - g(0)|^n \right)^{\frac{1}{n}} < \infty.
$$

Now we state the Schauder estimates.

THEOREM 5.20 Suppose $u \in C(B_1)$ is a viscosity solution of

$$
a_{ij} D_{ij} u = f \quad \text{in } B_1.
$$

Assume $\{a_{ij}\}$ is Hölder-continuous at 0 with exponent $\alpha$ in the $L^n$ sense for some $\alpha \in (0, 1)$. If $f$ is Hölder-continuous at 0 with exponent $\alpha$ in the $L^n$-sense, then $u$ is $C^{2,\alpha}$ at 0. Moreover, there exists a polynomial $P$ of degree 2 such that

$$
\begin{aligned} |u - P|_{L^\infty(B_r(0))} &\le C_* r^{2+\alpha} && \text{for any } 0 < r < 1, \\ |P(0)| + |DP(0)| + |D^2 P(0)| &\le C_*, \\ C_* &\le C\{|u|_{L^\infty(B_1)} + |f(0)| + [f]_{C_{L^n}^\alpha}(0)\} \end{aligned}
$$

where $C$ is a positive constant depending only on $n$, $\lambda$, $\Lambda$, $\alpha$, and $[a_{ij}]_{C_{L^n}^\alpha}(0)$.

PROOF: First we assume $f(0) = 0$. For that we may consider $v = u - b_{ij}x_i x_j f(0)/2$ for some constant matrix $\{b_{ij}\}$ such that $a_{ij}(0)b_{ij} = 1$. By scaling we also assume that $[a_{ij}]_{C_{L^n}^\alpha}(0)$ is small. Next by considering for $\delta > 0$

$$
\frac{u}{|u|_{L^\infty(B_1)} + \frac{1}{\delta}[f]_{C_{L^n}^\alpha}(0)}
$$

we may assume $|u|_{L^\infty(B_1)} \le 1$ and $[f]_{C_{L^n}^\alpha}(0) \le \delta$.

In the following we prove that there is a constant $\delta > 0$, depending only on $n$, $\lambda$, $\Lambda$, and $\alpha$, such that if $u \in C(B_1)$ is a viscosity solution of

$$
a_{ij} D_{ij} u = f \quad \text{in } B_1
$$

with

$$
|u|_{L^\infty(B_1)} \le 1, \quad [a_{ij}]_{C_{L^n}^\alpha}(0) \le \delta, \quad \left( \frac{1}{|B_r|} \int_{B_r} |f|^n \right)^{\frac{1}{n}} \le \delta r^\alpha \quad \text{for any } 0 < r < 1,
$$

then there exists a polynomial $P$ of degree 2 such that

$$
(5.17) \qquad |u - P|_{L^\infty(B_r(0))} \le C r^{2+\alpha} \quad \text{for any } 0 < r < 1
$$

and

$$
(5.18) \qquad |P(0)| + |DP(0)| + |D^2 P(0)| \le C
$$

for some positive constant $C$ depending only on $n$, $\lambda$, $\Lambda$, and $\alpha$.