THEOREM 4.13 Assume $a_{ij} \in L^\infty(B_1)$ and $c \in L^n(B_1)$ satisfies

$$
\lambda|\xi|^2 \le a_{ij}(x)\xi_i\xi_j \le \Lambda|\xi|^2 \quad \text{for any } x \in B_1, \xi \in \mathbb{R}^n,
$$

for some $0 < \lambda \le \Lambda < +\infty$. Suppose that $u \in H^1(B_1)$ satisfies

$$
\int_{B_1} a_{ij} D_j u D_i \varphi + cu\varphi = \int_{B_1} f\varphi \quad \text{for any } \varphi \in H_0^1(B_1).
$$

If $f \in L^q(B_1)$ for some $q > \frac{n}{2}$, then $u \in C^\alpha(B_1)$ for some $\alpha = \alpha(n, q, \lambda, \Lambda, \|c\|_{L^n}) \in (0, 1)$. Moreover, there exists $R_0 = R_0(q, \lambda, \Lambda, \|c\|_{L^n})$ such that for any $x \in B_{1/2}$ and $r \le R_0$ there holds

$$
\int_{B_r(x)} |Du|^2 \le C r^{n-2+2\alpha} \{\|f\|_{L^q(B_1)}^2 + \|u\|_{H^1(B_1)}^2\}
$$

where $C = C(n, q, \lambda, \Lambda, \|c\|_{L^n})$ is a positive constant.

## 4.4. Moser's Harnack Inequality

In this section we only discuss equations without lower-order terms. Suppose $\Omega$ is a domain in $\mathbb{R}^n$. We always assume that $a_{ij} \in L^\infty(\Omega)$ satisfies

$$
\lambda|\xi|^2 \le a_{ij}(x)\xi_i\xi_j \le \Lambda|\xi|^2 \quad \text{for all } x \in \Omega \text{ and } \xi \in \mathbb{R}^n
$$

for some positive constants $\lambda$ and $\Lambda$.

THEOREM 4.14 (Local Boundedness) Let $u \in H^1(\Omega)$ be a nonnegative subsolution in $\Omega$ in the following sense:

$$
\int_{\Omega} a_{ij} D_i u D_j \varphi \le \int_{\Omega} f \varphi \quad \text{for any } \varphi \in H_0^1(\Omega) \text{ and } \varphi \ge 0 \text{ in } \Omega.
$$

Suppose $f \in L^q(\Omega)$ for some $q > \frac{n}{2}$. Then there holds for any $B_R \subset \Omega$, any $0 < r < R$, and any $p > 0$

$$
\sup_{B_r} u \le C \left\{ \frac{1}{(R-r)^{n/p}} \|u^+\|_{L^p(B_R)} + R^{2-\frac{n}{q}} \|f\|_{L^q(B_R)} \right\}
$$

where $C = C(n, \lambda, \Lambda, p, q)$ is a positive constant.

PROOF: This is a special case of Theorem 4.1 in the dilated version. $\square$

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAiCAIAAAAs3UUgAAAAhklEQVR4nO3WMQrAIAwF0FgcvIT38FgOHsDBw3gfnZwdxQsopIO0Q8daC0L+FBweISAJQ0RYkGMFSu62Lr+rnLMxZl5USmmtAa/EGOfRkVrrcw7OOZyItRYASilL5ttaW+L23qlfcsn9yaV/Qe7mLn88ee9DCK/FsdSFEN/veSllSoltdv+eyAesclPnlooAAAAASUVORK5CYII=)

THEOREM 4.15 (Weak Harnack Inequality) Let $u \in H^1(\Omega)$ be a nonnegative supersolution in $\Omega$ in the following sense:

$$
(*) \quad \int_{\Omega} a_{ij} D_i u D_j \varphi \ge \int_{\Omega} f \varphi \quad \text{for any } \varphi \in H_0^1(\Omega) \text{ and } \varphi \ge 0 \text{ in } \Omega.
$$