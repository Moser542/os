since $\|T_N\| \le \sup_{P \in \partial\Omega} \|K_N(P, Q)\|_{L^1(\partial\Omega)} \le C < \infty$ where $C$ is independent of $N$, it is rather easy to see that

$$
\|T_N - T_{N+1}\| \le C \left[ \left(\frac{1}{N}\right)^{\frac{1}{n-2}} - \left(\frac{1}{(N+1)}\right)^{\frac{1}{n-2}} \right] \le C N^{-1-\frac{1}{n-2}}.
$$

We therefore conclude that $T = \lim_{N \to \infty} T_n$ is a compact operator on $C(\partial\Omega)$.

Next we apply the divergence theorem on $\Omega \mid B_\delta(P)$ for small positive $\delta$'s with $\delta \to 0^+$ to obtain

$$
(6.18) \qquad \int_{\partial \Omega} \frac{\partial}{\partial n_Q} R(P, Q) d\mathcal{H}^{n-1}(Q) = 1 \quad \text{if } P \in \Omega,
$$

$$
(6.19) \qquad \int_{\partial \Omega} K(P, Q) d\mathcal{H}^{n-1}(Q) = \frac{1}{2} \quad \text{if } P \in \partial \Omega.
$$

Let $P_0 \in \partial\Omega$ and $P \in \Omega$ such that $P \to P_0$. We want to verify that

$$
(6.20) \qquad \mathcal{D}f(P) \Rightarrow \frac{1}{2}f(P_0) + Tf(P_0).
$$

Here we observe that $\int_{\partial\Omega} |\frac{\partial}{\partial n_Q} R(P, Q)| d\mathcal{H}^{n-1}(Q) \le C < \infty$ for all $P \notin \partial\Omega$. Thus, in particular, $\|\mathcal{D}f\|_{L^\infty(\mathbb{R}^n|\partial\Omega)} \le C \|f\|_{L^\infty(\partial\Omega)}$.

If $P_0 \notin$ support of $f$, then it is obvious that

$$
\int_{\partial \Omega} \frac{\partial}{\partial n_Q} R(P, Q) f(Q) d\mathcal{H}^{n-1}(Q) \xrightarrow{P \to P_0} \int_{\partial \Omega} K(P_0, Q) f(Q) d\mathcal{H}^{n-1}(Q) = Tf(P_0).
$$

If $P_0 \in$ support of $f$ and $f(P_0) = 0$, then we let $\{f_k\} \subset C(\partial\Omega)$ such that

$$
\|f - f_k\|_{L^\infty(\partial\Omega)} \xrightarrow{k \to \infty} 0,
$$

and $P_0 \notin$ support of $f_k$ for each $k, k = 1, 2, \dots$. Then

$$
\begin{aligned} |\mathcal{D}f(P) - Tf(P)| &\le |\mathcal{D}(f - f_k)(P)| + |T(f - f_k)|(P) \\ &\quad + |\mathcal{D}f_k(P) - Tf_k(P)| \\ &\le C \|f - f_k\|_{L^\infty(\partial\Omega)} + \|T\| \|f - f_k\|_{L^\infty(\partial\Omega)} \\ &\quad + |\mathcal{D}f_k(P) - Tf_k(P)|. \end{aligned}
$$

We initially choose $k$ large so that the first two terms on the right-hand side of the above inequality will be small. We then observe that for fixed $k$ (large) as $P \to P_0$, the last term in the inequality also goes to 0.

To complete the proof it suffices to verify the case when $f \equiv 1$, for which the result is trivial. If we replace $\Omega$ by $\Omega^c$, then all the other statements in Lemmas 6.16 and 6.17 follow. $\square$

To conclude our consideration of double-layer potentials we need to show how to use them to solve the Dirichlet problem (6.10).