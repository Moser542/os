PROPOSITION 2.27 Suppose that $u \in C(\bar{\Omega}) \cap C^2(\Omega)$ satisfies

$$
Qu \equiv a_{ij}(x, u, Du)D_{ij}u + b(x, u, Du) = 0 \quad \text{in } \Omega
$$

where $a_{ij} \in C(\Omega \times \mathbb{R} \times \mathbb{R}^n)$ satisfies

$$
a_{ij}(x, z, p)\xi_i\xi_j > 0 \quad \text{for any } (x, z, p) \in \Omega \times \mathbb{R} \times \mathbb{R}^n \text{ and } \xi \in \mathbb{R}^n.
$$

Suppose there exist nonnegative functions $g \in L_{\text{loc}}^n(\mathbb{R}^n)$ and $h \in L^n(\Omega)$ such that

$$
\frac{|b(x, z, p)|}{nD^*} \le \frac{h(x)}{g(p)} \quad \text{for any } (x, z, p) \in \Omega \times \mathbb{R} \times \mathbb{R}^n, \\ \int_{\Omega} h^n(x)dx < \int_{\mathbb{R}^n} g^n(p)dp \equiv g_{\infty}.
$$

Then there holds $\sup_{\Omega} |u| \le \sup_{\partial \Omega} |u| + C \text{diam}(\Omega)$ where $C$ is a positive constant depending only on $g$ and $h$.

EXAMPLE. The prescribed mean curvature equation is given by

$$
(1 + |Du|^2)\Delta u - D_i u D_j u D_{ij} u = nH(x)(1 + |Du|^2)^{3/2}
$$

for some $H \in C(\Omega)$. We have

$$
a_{ij}(x, z, p) = (1 + |p|^2)\delta_{ij} - p_i p_j \Rightarrow D = (1 + |p|^2)^{n-1} \\ b = -nH(x)(1 + |p|^2)^{3/2}.
$$

This implies

$$
\frac{|b(x, z, p)|}{nD^*} \le \frac{|H(x)|(1 + |p|^2)^{3/2}}{(1 + |p|^2)^{\frac{n-1}{n}}} = |H(x)|(1 + |p|^2)^{\frac{n+2}{2n}}
$$

and in particular

$$
g_{\infty} = \int_{\mathbb{R}^n} g^n(p)dp = \int_{\mathbb{R}^n} \frac{d}{p}(1 + |p|^2)^{\frac{n+2}{2}} = \omega_n.
$$

COROLLARY 2.28 Suppose $u \in C(\bar{\Omega}) \cap C^2(\Omega)$ satisfies

$$
(1 + |Du|^2)\Delta u - D_i u D_j u D_{ij} u = nH(x)(1 + |Du|^2)^{3/2} \quad \text{in } \Omega
$$

for some $H \in C(\Omega)$. Then if

$$
H_0 \equiv \int_{\Omega} |H(x)|^n dx < \omega_n,
$$

we have

$$
\sup_{\Omega} |u| \le \sup_{\partial \Omega} |u| + C \text{diam}(\Omega)
$$

where $C$ is a positive constant depending only on $n$ and $H_0$.