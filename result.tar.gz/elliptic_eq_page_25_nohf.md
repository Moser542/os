It is easy to check by integration by parts that the harmonic functions satisfy the above equation for $a_{ij} = \delta_{ij}$.

LEMMA 1.36 (Cacciopolli's Inequality) Suppose $u \in C^1(B_1)$ satisfies

$$
\int_{B_1} a_{ij} D_i u D_j \varphi = 0 \quad \text{for any } \varphi \in C_0^1(B_1).
$$

Then for any function $\eta \in C_0^1(B_1)$, we have

$$
\int_{B_1} \eta^2 |Du|^2 \le C \int_{B_1} |D\eta|^2 u^2
$$

where $C$ is a positive constant depending only on $\lambda$ and $\Lambda$.

PROOF: For any $\eta \in C_0^1(B_1)$ set $\varphi = \eta^2 u$. Then we have

$$
\lambda \int_{B_1} \eta^2 |Du|^2 \le \Lambda \int_{B_1} \eta |u| |D\eta| |Du|.
$$

We obtain the result by the Hölder inequality.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAAgCAIAAABl4DQWAAAA4klEQVR4nO2WMQ5EQBSG/xGJcQeVygkmcQP3UTqC3iE0zuEGNKLRaUQhgve2sAVZFTvZ2Pi6yWS+zPz/FE8wM7Rh6FM/9p/Zze2i7/sgCLquu2Q0Td/3kyQRQojtjyzL0vM8KaXrukKIE2oiqqpqHMc8z5VS4A1FUQCIoogvEIYhgCzLmPkgd9u2z6YCAFJKANM0QV+ry7I89kOISKP9zsnc2f60+o/2O7c6z7NG+49yH4bhinc9vtrNz+04jtM0NYwzzyKiuq4BOI4DYDcTNE1jWdaFe79RSrVty8y7eebrvACbANNGWU3CJgAAAABJRU5ErkJggg==)

COROLLARY 1.37 Let $u$ be as in Lemma 1.36. Then for any $0 \le r < R \le 1$ there holds

$$
\int_{B_r} |Du|^2 \le \frac{C}{(R-r)^2} \int_{B_R} u^2
$$

where $C$ is a positive constant depending only on $\lambda$ and $\Lambda$.

PROOF: Take $\eta$ such that $\eta = 1$ on $B_r$, $\eta = 0$ outside $B_R$, and $|D\eta| \le 2(R-r)^{-1}$. $\square$

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAAfCAIAAACQzIFuAAAA4klEQVR4nO2WMQ5EQBSG/xGJcQeVygkmcQP3UTqC3iE0zuEGNKLRaUQhgve2sAXZzRbsZGPj6yaT+TLz/1M8wczQhqFPfds/YG4Xfd8HQdB13Smjafq+nySJEEJs/0xZlp7nSSld1xVCHFATUVVV4zjmea6UAm8oigJAFEV8gjAMAWRZxsxvcrdt+2gqACClBDBNE/S1uizLbX8LEWm0XzmZK9vvVv/RfuVW53nWaP9R7sMwnPGux1e7+bodx3GapoZx5FlEVNc1AMdxAOxmgqZpLMs6ce8nSqm2bZl5N898nQdqi9NEzHDhcwAAAABJRU5ErkJggg==)

COROLLARY 1.38 Let $u$ be as in Lemma 1.36. Then for any $0 < R \le 1$ there hold

$$
\int_{B_{R/2}} u^2 \le \theta \int_{B_R} u^2 \quad \text{and} \quad \int_{B_{R/2}} |Du|^2 \le \theta \int_{B_R} |Du|^2
$$

where $\theta = \theta(n, \lambda, \Lambda) \in (0, 1)$.

PROOF: Take $\eta \in C_0^1(B_R)$ with $\eta = 1$ on $B_{R/2}$ and $|D\eta| \le 2R^{-1}$. Then Lemma 1.36 yields

$$
\int_{B_R} |D(\eta u)|^2 \le C \int_{B_R} |D\eta|^2 u^2 \le \frac{C}{R^2} \int_{B_R \setminus B_{R/2}} u^2
$$

by noting $D\eta = 0$ in $B_{R/2}$. Hence by the Poincaré inequality we get

$$
\int_{B_R} (\eta u)^2 \le c(n) R^2 \int_{B_R} |D(\eta u)|^2.
$$