The convergence of $J(u_k)$ obviously implies that $\{J(u_k)\}$ is a bounded sequence; then $\|u_k\|_{H_0^1}$ is uniformly bounded. By Rellich's theorem, there exists a subsequence $\{u_{k'}\}$ and a $u \in H_0^1(\Omega)$ such that

$$
u_{k'} \to u \quad \text{in the } L^2\text{-norm as } k' \to \infty.
$$

Next, with the help of the Hilbert space structure of $H_0^1(\Omega)$ it is not difficult to prove

$$
J(u) \le \liminf_{k' \to \infty} J(u_{k'}).
$$

This implies $J(u) = J_0$. We conclude that $J_0$ is attained in $H_0^1(\Omega)$. $\square$

We point out that the minimizing process is an important method in the calculus of variation.

## 6.3. Continuity Method

In this section we discuss how to solve Dirichlet problems by the method of continuity. We illustrate this method by solving the Dirichlet problem for uniformly elliptic equations on $C^{2,\alpha}$-domains by assuming that a similar problem for the Laplace equation can be solved. The method of continuity can be applied to nonlinear elliptic equations. The crucial ingredient is the a priori estimates.

Let $\Omega$ be a bounded domain in $\mathbb{R}^n$, and let $a_{ij}, b_i$, and $c$ be defined in $\Omega$, with $a_{ij} = a_{ji}$. We consider the operator $L$ given by

$$
(6.7) \qquad Lu = a_{ij} D_{ij} u + b_i D_i u + cu \quad \text{in } \Omega
$$

for any $u \in C^2(\Omega)$. The operator $L$ is always assumed to be *uniformly elliptic* in $\Omega$; namely,

$$
(6.8) \qquad a_{ij} \xi_i \xi_j \ge \lambda |\xi|^2 \quad \text{for any } x \in \Omega \text{ and } \xi \in \mathbb{R}^n
$$

for some positive constant $\lambda$.

Now we state a general existence result for solutions of the Dirichlet problem with $C^{2,\alpha}$ boundary values for general uniformly elliptic equations with $C^\alpha$ coefficients.

**THEOREM 6.11** Let $\Omega$ be a bounded $C^{2,\alpha}$-domain in $\mathbb{R}^n$ and $L$ be a uniformly elliptic operator in $\Omega$ as defined in (6.7), with (6.8) satisfied, $c \le 0$ in $\Omega$, and $a_{ij}, b_i, c \in C^\alpha(\bar{\Omega})$ for some $\alpha \in (0, 1)$. Then for any $f \in C^\alpha(\bar{\Omega})$ and $\varphi \in C^{2,\alpha}(\bar{\Omega})$, there exists a (unique) solution $u \in C^{2,\alpha}(\bar{\Omega})$ of the Dirichlet problem

$$
\begin{aligned} Lu &= f \quad \text{in } \Omega, \\ u &= \varphi \quad \text{on } \partial\Omega. \end{aligned}
$$

Theorem 6.11 plays an extremely important role in the theory of elliptic differential equations of the second order. The crucial step in solving the Dirichlet problem for $L$ is to assume that the similar Dirichlet problem for the Laplace operator is solved. Specifically, we prove the following result.