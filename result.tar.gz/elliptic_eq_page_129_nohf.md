By Lemma 6.3, $w_i \in \mathcal{S}$ and $v_i \le w_i$ in $\Omega$. Moreover, $w_i$ is harmonic in $B_r(x_0)$ and satisfies

$$
\begin{aligned}
\lim_{i \to \infty} w_i(x_0) &= u_\varphi(x_0), \\
m \le w_i \le u_\varphi &\quad \text{in } \Omega,
\end{aligned}
$$

for any $i = 1, 2, \dots$. By the compactness of bounded harmonic functions, there exists a harmonic function $w$ in $B_r(x_0)$ such that a subsequence of $\{w_i\}$, still denoted by $\{w_i\}$, converges to $w$ in any compact subset of $B_r(x_0)$. We then easily conclude

$$
w \le u_{\varphi} \quad \text{in } B_r(x_0) \quad \text{and} \quad w(x_0) = u_{\varphi}(x_0).
$$

We now claim $u_\varphi = w$ in $B_r(x_0)$. To see this, we take any $\bar{x} \in B_r(x_0)$ and proceed similarly as before, with $\bar{x}$ replacing $x_0$. By the definition of $u_\varphi$, there exists a sequence of functions $\bar{v}_i \in \mathcal{S}$ such that

$$
\lim_{i \to \infty} \bar{v}_i(\bar{x}) = u_\varphi(\bar{x}).
$$

Replacing, if necessary, $\bar{v}_i$ by $\max\{\bar{v}_i, w_i\} \in \mathcal{S}$, we may also assume

$$
w_i \le \bar{v}_i \le u_\varphi \quad \text{in } \Omega.
$$

For the fixed $B_r(x_0)$ and each $\bar{v}_i$, we let $\bar{w}_i$ be the harmonic lifting in Lemma 6.3. Then, $\bar{w}_i \in \mathcal{S}$ and $\bar{v}_i \le \bar{w}_i$ in $\Omega$. Moreover, $\bar{w}_i$ is harmonic in $B_r(x_0)$ and satisfies

$$
\begin{aligned}
\lim_{i \to \infty} \bar{w}_i(\bar{x}) &= u_\varphi(\bar{x}), \\
m \le \max\{\bar{v}_i, w_i\} \le \bar{w}_i \le u_\varphi &\quad \text{in } \Omega,
\end{aligned}
$$

for any $i = 1, 2, \dots$. By the compactness of bounded harmonic functions again, there exists a harmonic function $\bar{w}$ in $B_r(x_0)$ such that a subsequence of $\bar{w}_i$ converges to $\bar{w}$ in any compact subset of $B_r(x_0)$. We then easily conclude

$$
\begin{aligned}
w \le \bar{w} \le u_{\varphi} &\quad \text{in } B_r(x_0), \\
w(x_0) &= \bar{w}(x_0) = u_{\varphi}(x_0), \\
\bar{w}(\bar{x}) &= u_{\varphi}(\bar{x}).
\end{aligned}
$$

We first note that $w - \bar{w}$ is a harmonic function in $B_r(x_0)$ with a maximum attained at $x_0$. By applying the strong maximum principle to $w - \bar{w}$ in $B_{r'}(x_0)$ for any $r' < r$, we conclude that $w - \bar{w}$ is constant, which is obviously 0. This implies $w = \bar{w}$ in $B_r(x_0)$, and in particular, $w(\bar{x}) = \bar{w}(\bar{x}) = u_\varphi(\bar{x})$. We then have $w = u_\varphi$ in $B_r(x_0)$ since $\bar{x}$ is arbitrary in $B_r(x_0)$. Therefore, $u_\varphi$ is harmonic in $B_r(x_0)$. $\square$

We note that $u_\varphi$ in Lemma 6.4 is defined only in $\Omega$. To discuss limits of $u_\varphi(x)$ as $x$ approaches the boundary, we need to impose additional assumptions on the boundary $\partial\Omega$.