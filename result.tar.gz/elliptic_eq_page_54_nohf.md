PROOF: As before, denote $R_0 = \text{dist}(\Omega', \partial\Omega)$. For any $x_0 \in \Omega'$ and $0 < r \le R_0$, the Poincaré inequality yields

$$
\int_{B_r(x_0)} |u - u_{x_0, r}|^2 \le c r^2 \int_{B_r(x_0)} |Du|^2 dx \le c(n) M r^{\mu+2}.
$$

This implies that

$$
\int_{B_r(x_0)} |u - u_{x_0, r}|^2 \le c(n) M r^{\lambda}
$$

where $\lambda$ is as in Theorem 3.3. For any $0 < \rho < r \le R_0$ we have

$$
\begin{align} \int_{B_{\rho}(x_0)} u^2 &\le 2 \int_{B_{\rho}(x_0)} |u_{x_0, r}|^2 + 2 \int_{B_{\rho}(x_0)} |u - u_{x_0, r}|^2 \tag{3.3} \\ &\le c(n) \rho^n |u_{x_0, r}|^2 + 2 \int_{B_r(x_0)} |u - u_{x_0, r}|^2 \nonumber \\ &\le c(n) \left(\frac{\rho}{r}\right)^n \int_{B_r(x_0)} u^2 + M r^{\lambda} \nonumber \end{align}
$$

where we used

$$
|u_{x_0, r}|^2 \le \frac{c(n)}{r^n} \int_{B_r(x_0)} u^2.
$$

Hence the function $\phi(r) = \int_{B_r(x_0)} u^2$ satisfies the inequality

$$
(3.4) \quad \phi(\rho) \le c(n) \left\{ \left(\frac{\rho}{r}\right)^n \phi(r) + M r^{\lambda} \right\} \quad \text{for any } 0 < \rho < r \le R_0
$$

for some $\lambda \in (0, n)$. If we may replace the term $M r^{\lambda}$ in the right by $M \rho^{\lambda}$, we are done. In fact, we would obtain that for any $0 < \rho < r \le R_0$ there holds

$$
(3.5) \quad \int_{B_{\rho}(x_0)} u^2 \le c \left\{ \left(\frac{\rho}{r}\right)^{\lambda} \int_{B_r(x_0)} u^2 + M \rho^{\lambda} \right\}.
$$

Choose $r = R_0$. This implies

$$
\int_{B_{\rho}(x_0)} u^2 \le c \rho^{\lambda} \left\{ \int_{\Omega} u^2 + M \right\} \quad \text{for any } \rho \le R_0.
$$

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAeCAIAAABSe/KxAAAAaElEQVR4nO3WMQrAMAgF0Ko5jFfMmFsmd6n8Tg0lY5VAwL+5PEQEJQBXaDiWO0Qs38LMAki86b0HcDvm2Fq7Ham1lkUUERH53yDzCduTYoopppjiLpHm3zPGUFUi8pwKM1svFwDnH/AAIfZevHfOHYEAAAAASUVORK5CYII=)

For this purpose, we need the following technical lemma.