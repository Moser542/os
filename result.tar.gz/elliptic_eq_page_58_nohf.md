Continue this process. For any integer $k \ge 1$ there exists a sequence of disjoint cubes $\{Q_j^{(k)}\}$ such that

$$
\sum_j |Q_j^{(k)}| \le \frac{1}{\alpha^k} |Q_0|
$$

and

$$
|u(x) - u_{Q_0}| \le k 2^n \alpha \quad \text{a.e. } x \in Q_0 \setminus \bigcup_j Q_j^{(k)}.
$$

Thus

$$
|\{x \in Q_0 : |u - u_{Q_0}| > 2^n k \alpha\}| \le \sum_{j=1}^{\infty} |Q_j^{(k)}| \le \frac{1}{\alpha^k} |Q_0|.
$$

For any $t$ there exists an integer $k$ such that $t \in [2^n k \alpha, 2^n (k+1) \alpha)$. This implies

$$
\alpha^{-k} = \alpha \alpha^{-(k+1)} = \alpha e^{-(k+1) \log \alpha} \le \alpha e^{-\frac{\log \alpha}{2^n \alpha} t}.
$$

This finishes the proof.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAAgCAIAAABl4DQWAAAAfElEQVR4nO3WoQ3AIBCF4aOtYAkWYToEw7APKCwrIEleBYaUpoKCaHq/JflCTj0BgJa1raNZfwpNIYR9RlrrCl71WZ9OKQG4uYy1Fi8yxhBRzpnW3b2UwjrrrLPOOuu/04/+wTnnvR9267CQUhJ1e2YYbVNKxRgBiA9v4BOSHchFVnlwRgAAAABJRU5ErkJggg==)

### 3.3. Hölder Continuity of Solutions

In this section we will prove Hölder regularity for solutions. The basic idea is to freeze the leading coefficients and then to compare solutions with harmonic functions. The regularity of solutions depends on how close solutions are to harmonic functions. Hence we need some regularity assumption on the leading coefficients.

Suppose $a_{ij} \in L^\infty(B_1)$ is uniformly elliptic in $B_1 = B_1(0)$, that is,

$$
\lambda |\xi|^2 \le a_{ij}(x) \xi_i \xi_j \le \Lambda |\xi|^2 \quad \text{for any } x \in B_1, \xi \in \mathbb{R}^n.
$$

In the following we assume that $a_{ij}$ is at least continuous. We assume that $u \in H^1(B_1)$ satisfies

$$
(*) \quad \int_{B_1} a_{ij} D_i u D_j \varphi + c u \varphi = \int_{B_1} f \varphi \quad \text{for any } \varphi \in H_0^1(B_1).
$$

The main theorem we will prove are the following Hölder estimates for solutions.

THEOREM 3.8 Let $u \in H^1(B_1)$ solve $(*)$. Assume $a_{ij} \in C^0(\bar{B}_1)$, $c \in L^n(B_1)$, and $f \in L^q(B_1)$ for some $q \in (\frac{n}{2}, n)$. Then $u \in C^\alpha(B_1)$ with $\alpha = 2 - \frac{n}{q} \in (0, 1)$. Moreover, there exists an $R_0 = R_0(\lambda, \Lambda, \tau, \|c\|_{L^n})$ such that for any $x \in B_{1/2}$ and $r \le R_0$ there holds

$$
\int_{B_r(x)} |Du|^2 \le C r^{n-2+2\alpha} \{\|f\|_{L^q(B_1)}^2 + \|u\|_{H^1(B_1)}^2\}
$$

where $C = C(\lambda, \Lambda, \tau, \|c\|_{L^n})$ is a positive constant with

$$
|a_{ij}(x) - a_{ij}(y)| \le \tau(|x - y|) \quad \text{for any } x, y \in B_1.
$$

REMARK 3.9. In the case where $c \equiv 0$, we may replace $\|u\|_{H^1(B_1)}$ with $\|Du\|_{L^2(B_1)}$.