Titles in This Series

1. R. **Qing Han and Fanghua Lin**, Elliptic partial differential equations, Second edition, 2011
21. Frank C. Hoppensteadt, Quasi-static state analysis of differential, difference, integral, and gradient systems, 2010
20. Pierpaolo Esposito, Nassif Ghoussoub, and Yujin Guo, Mathematical analysis of partial differential equations modeling electrostatic MEMS, 2009
19. Stephen Childress, An introduction to theoretical fluid mechanics, 2009
18. Percy Deift and Dimitri Gioev, Random matrix theory: Invariant ensembles and universality, 2009
17. Ping Zhang, Wigner measure and semiclassical limits of nonlinear Schrödinger equations, 2008
16. S. R. S. Varadhan, Stochastic processes, 2007
15. Emil Artin, Algebra with Galois theory, 2007
14. Peter D. Lax, Hyperbolic partial differential equations, 2006
13. Oliver Bühler, A brief introduction to classical, statistical, and quantum mechanics, 2006
12. Jürgen Moser and Eduard J. Zehnder, Notes on dynamical systems, 2005
11. V. S. Varadarajan, Supersymmetry for mathematicians: An introduction, 2004
10. Thierry Cazenave, Semilinear Schrödinger equations, 2003
9. Andrew Majda, Introduction to PDEs and waves for the atmosphere and ocean, 2003
8. Fedor Bogomolov and Tihomir Petrov, Algebraic curves and one-dimensional fields, 2003
7. S. R. S. Varadhan, Probability theory, 2001
6. Louis Nirenberg, Topics in nonlinear functional analysis, 2001
5. Emmanuel Hebey, Nonlinear analysis on manifolds: Sobolev spaces and inequalities, 2000
3. Percy Deift, Orthogonal polynomials and random matrices: A Riemann-Hilbert approach, 2000
2. Jalal Shatah and Michael Struwe, Geometric wave equations, 2000
1. Qing Han and Fanghua Lin, Elliptic partial differential equations, 2000