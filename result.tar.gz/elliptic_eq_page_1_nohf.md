2000 *Mathematics Subject Classification*. Primary 35-01, 35Jxx.

For additional information and updates on this book, visit
**www.ams.org/bookpages/cln-1**

**Library of Congress Cataloging-in-Publication Data**

Han, Qing.

Elliptic partial differential equations / Qing Han, Fanghua Lin. — 2nd ed.
p. cm. — (Courant lecture notes ; v. 1)

Includes bibliographical references.

ISBN 978-0-8218-5313-9 (alk. paper)

1. Differential equations, Elliptic. I. Lin, Fanghua. II. Title.

QA377.H3182 2011
515'.3533—dc22

2010051489

**Copying and reprinting.** Individual readers of this publication, and nonprofit libraries acting for them, are permitted to make fair use of the material, such as to copy a chapter for use in teaching or research. Permission is granted to quote brief passages from this publication in reviews, provided the customary acknowledgment of the source is given.

Republication, systematic copying, or multiple reproduction of any material in this publication is permitted only under license from the American Mathematical Society. Requests for such permission should be addressed to the Acquisitions Department, American Mathematical Society, 201 Charles Street, Providence, Rhode Island 02904-2294 USA. Requests can also be made by e-mail to reprint-permission@ams.org.

© 2011 by the authors. All rights reserved.
Printed in the United States of America.

∞ The paper used in this book is acid-free and falls within the guidelines established to ensure permanence and durability.
Visit the AMS home page at http://www.ams.org/

10 9 8 7 6 5 4 3 2 1 16 15 14 13 12 11