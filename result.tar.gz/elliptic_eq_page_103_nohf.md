$\mathcal{S}^{-}(\lambda, \Lambda, f)$ if for any $x_0 \in \Omega$ and any function $\varphi \in C^2(\Omega)$ such that $u - \varphi$ has a local minimum (respectively, maximum) at $x_0$ there holds

$$
\lambda \sum_{e_i > 0} e_i(x_0) + \Lambda \sum_{e_i < 0} e_i(x_0) \le f(x_0) \\ \left( \text{respectively, } \Lambda \sum_{e_i > 0} e_i(x_0) + \lambda \sum_{e_i < 0} e_i(x_0) \ge f(x_0) \right)
$$

where $e_1(x_0), \dots, e_n(x_0)$ are eigenvalues of the Hessian matrix $D^2\varphi(x_0)$.

We denote $\mathcal{S}(\lambda, \Lambda, f) = \mathcal{S}^{+}(\lambda, \Lambda, f) \cap \mathcal{S}^{-}(\lambda, \Lambda, f)$.

REMARK 5.6. Any viscosity supersolutions of

$$
a_{ij} D_{ij} u = f \quad \text{in } \Omega
$$

belong to the class $\mathcal{S}^{+}(\lambda, \Lambda, f)$ where there holds

$$
\lambda |\xi|^2 \le a_{ij}(x) \xi_i \xi_j \le \Lambda |\xi|^2 \quad \text{for any } x \in \Omega \text{ and any } \xi \in \mathbb{R}^n.
$$

The class $\mathcal{S}^{+}(\lambda, \Lambda, f)$ and $\mathcal{S}^{-}(\lambda, \Lambda, f)$ also include solutions to fully nonlinear equations. Among them are the Pucci equations.

EXAMPLE. For any two positive constants $\lambda \le \Lambda$ let $A$ be a symmetric matrix whose eigenvalues belong to $[\lambda, \Lambda]$, that is, $\lambda|\xi|^2 \le A_{ij}\xi_i\xi_j \le \Lambda|\xi|^2$ for any $\xi \in \mathbb{R}^n$. Let $\mathcal{A}_{\lambda, \Lambda}$ denote the class of all such matrices. For any symmetric matrix $M$ we define the Pucci extremal operators

$$
\mathcal{M}^{-}(M) = \mathcal{M}^{-}(\lambda, \Lambda, M) = \inf_{A \in \mathcal{A}_{\lambda, \Lambda}} A_{ij} M_{ij},
$$

$$
\mathcal{M}^{+}(M) = \mathcal{M}^{+}(\lambda, \Lambda, M) = \sup_{A \in \mathcal{A}_{\lambda, \Lambda}} A_{ij} M_{ij}.
$$

Pucci's equations are given by

$$
\mathcal{M}^{-}(\lambda, \Lambda, M) = f, \quad \mathcal{M}^{+}(\lambda, \Lambda, M) = g,
$$

for continuous functions $f$ and $g$ in $\Omega$. It is easy to see that

$$
\mathcal{M}^{-}(\lambda, \Lambda, M) = \lambda \sum_{e_i > 0} e_i + \Lambda \sum_{e_i < 0} e_i,
$$

$$
\mathcal{M}^{+}(\lambda, \Lambda, M) = \Lambda \sum_{e_i > 0} e_i + \lambda \sum_{e_i < 0} e_i,
$$

where $e_1, \dots, e_n$ are eigenvalues of $M$. Therefore $u \in \mathcal{S}^{+}(\lambda, \Lambda, f)$ if and only if $\mathcal{M}^{-}(\lambda, \Lambda, D^2u) \le f$ in the viscosity sense; that is, for any $\varphi \in C^2(\Omega)$ such that $u - \varphi$ has a local minimum at $x_0 \in \Omega$ there holds

$$
\mathcal{M}^{-}(\lambda, \Lambda, D^2\varphi(x_0)) \le f(x_0).
$$

By the definition of $\mathcal{M}^{-}$ and $\mathcal{M}^{+}$ it is easy to check that for any two symmetric matrices $M$ and $N$

$$
\mathcal{M}^{-}(M) + \mathcal{M}^{-}(N) \le \mathcal{M}^{-}(M + N) \le \mathcal{M}^{+}(M) + \mathcal{M}^{-}(N) \\ \le \mathcal{M}^{+}(M + N) \le \mathcal{M}^{+}(M) + \mathcal{M}^{+}(N).
$$