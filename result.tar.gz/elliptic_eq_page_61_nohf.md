has a unique solution with $w$ with $w - u \in H_0^1(B_r(x_0))$. Obviously the function $v = u - w \in H_0^1(B_r(x_0))$ satisfies the equation

$$
\int_{B_r(x_0)} a_{ij}(x_0) D_i v \bar{D}_j \varphi = \int_{B_r(x_0)} f \varphi - c u \varphi + (a_{ij}(x_0) - a_{ij}(x)) D_i u \bar{D}_j \varphi \\ \text{for any } \varphi \in H_0^1(B_r(x_0)).
$$

By taking the test function $\varphi = v$ we obtain

$$
\int_{B_r(x_0)} |Dv|^2 \le c \left\{ \tau^2(r) \int_{B_r(x_0)} |Du|^2 + \left( \int_{B_r(x_0)} |c|^n \right)^{2/n} \int_{B_r(x_0)} u^2 \right. \\ \left. + \left( \int_{B_r(x_0)} |f|^{\frac{2n}{n+2}} \right)^{\frac{n+2}{n}} \right\}
$$

where we use the Sobolev inequality

$$
\left( \int_{B_r(x_0)} v^{\frac{2n}{n-2}} \right)^{\frac{n-2}{2n}} \le c(n) \left( \int_{B_r(x_0)} |Dv|^2 \right)^{1/2}
$$

for $v \in H_0^1(B_r(x_0))$. Therefore Corollary 3.11 implies for any $0 < \rho \le r$

$$
(3.7) \quad \int_{B_\rho(x_0)} |Du|^2 \le c \left\{ \left[ \left( \frac{\rho}{r} \right)^n + \tau^2(r) \right] \int_{B_r(x_0)} |Du|^2 \right. \\ \left. + \left( \int_{B_r(x_0)} |c|^n \right)^{2/n} \int_{B_r(x_0)} u^2 + \left( \int_{B_r(x_0)} |f|^{\frac{2n}{n+2}} \right)^{\frac{n+2}{n}} \right\}
$$

where $c$ is a positive constant depending only on $\lambda$ and $\Lambda$. By Hölder inequality there holds

$$
\left( \int_{B_r(x_0)} |f|^{\frac{2n}{n+2}} \right)^{\frac{n+2}{n}} \le \left( \int_{B_r(x_0)} |f|^q \right)^{2/q} r^{n-2+2\alpha}
$$

where $\alpha = 2 - \frac{n}{q} \in (0, 1)$ if $\frac{n}{2} < q < n$. Hence (3.7) implies for any $B_r(x_0) \subset B_1$ and any $0 < \rho \le r$

$$
\int_{B_\rho(x_0)} |Du|^2 \le C \left\{ \left[ \left( \frac{\rho}{r} \right)^n + \tau^2(r) \right] \int_{B_r(x_0)} |Du|^2 + r^{n-2+2\alpha} \|f\|_{L^q(B_1)}^2 \right. \\ \left. + \left( \int_{B_r(x_0)} |c|^n \right)^{2/n} \int_{B_r(x_0)} u^2 \right\}.
$$