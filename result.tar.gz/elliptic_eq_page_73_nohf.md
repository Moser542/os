if $|A(k, R)|$ is small. Note

$$
|A(k, R)| \le \frac{1}{k} \int_{A(k,R)} u^+ \le \frac{1}{k} \|u^+\|_{L^2}.
$$

Hence (4.2) holds if $k \ge k_0 = C \|u^+\|_{L^2}$ for some large $C$ depending only on $\lambda$ and $\Lambda$.

Next we would show that there exists some $k = C(k_0 + F)$ such that

$$
\int_{A(k,1/2)} (u-k)^2 = 0.
$$

To continue we take any $h > k \ge k_0$ and any $0 < r < 1$. It is obvious that $A(k, r) \supset A(h, r)$. Hence we have

$$
\int_{A(h,r)} (u-h)^2 \le \int_{A(k,r)} (u-k)^2
$$

and

$$
|A(h, r)| = |B_r \cap \{u - k > h - k\}| \le \frac{1}{(h-k)^2} \int_{A(k,r)} (u-k)^2.
$$

Therefore by (4.2) we have for any $h > k \ge k_0$ and $\frac{1}{2} \le r < R \le 1$

$$
\begin{aligned} \int_{A(h,r)} (u-h)^2 &\le C \left\{ \frac{1}{(R-r)^2} \int_{A(h,R)} (u-h)^2 + (h+F)^2 |A(h,R)| \right\} |A(h,R)|^{\varepsilon} \\ &\le C \left\{ \frac{1}{(R-r)^2} + \frac{(h+F)^2}{(h-k)^2} \right\} \frac{1}{(h-k)^{2\varepsilon}} \left( \int_{A(k,R)} (u-k)^2 \right)^{1+\varepsilon} \end{aligned}
$$

or

$$
(4.3) \quad \|(u-h)^+\|_{L^2(B_r)} \le C \left\{ \frac{1}{R-r} + \frac{h+F}{h-k} \right\} \frac{1}{(h-k)^\varepsilon} \|(u-k)^+\|_{L^2(B_R)}^{1+\varepsilon}.
$$

Now we carry out the iteration. Set $\varphi(k, r) = \|(u-k)^+\|_{L^2(B_r)}$. For $\tau = \frac{1}{2}$ and some $k > 0$ to be determined. Define for $\ell = 0, 1, \dots$,

$$
\begin{aligned} k_{\ell} &= k_0 + k \left(1 - \frac{1}{2^{\ell}}\right) \quad (\le k_0 + k), \\ r_{\ell} &= \tau + \frac{1}{2^{\ell}}(1 - \tau). \end{aligned}
$$

Obviously we have

$$
k_{\ell} - k_{\ell-1} = \frac{k}{2^{\ell}}, \quad r_{\ell-1} - r_{\ell} = \frac{1}{2^{\ell}}(1 - \tau).
$$