Suppose $f \in L^q(\Omega)$ for some $q > \frac{n}{2}$. Then for any $B_R \subset \Omega$ there holds for any $0 < p < \frac{n}{n-2}$ and any $0 < \theta < \tau < 1$

$$
\inf_{B_{\theta R}} u + R^{2-\frac{n}{q}} \|f\|_{L^q(B_R)} \geq C \left( \frac{1}{R^n} \int_{B_{\tau R}} u^p \right)^{\frac{1}{p}}
$$

where $C$ depends only on $n, p, q, \lambda, \Lambda, \theta$, and $\tau$.

PROOF: We prove for $R = 1$.

Step 1. We prove that the result holds for some $p_0 > 0$.

Set $\bar{u} = u + k > 0$ for some $k > 0$ to be determined and $v = \bar{u}^{-1}$. First we will derive the equation for $v$. For any $\varphi \in H_0^1(B_1)$ with $\varphi \ge 0$ in $B_1$ consider $\bar{u}^{-2}\varphi$ as the test function in $(*)$. We have

$$
\int_{B_1} a_{ij} D_i u \frac{D_j \varphi}{\bar{u}^2} - 2 \int_{B_1} a_{ij} D_i u D_j \bar{u} \frac{\varphi}{\bar{u}^3} \geq \int_{B_1} f \frac{\varphi}{\bar{u}^2}.
$$

Note $D\bar{u} = Du$ and $Dv = -\bar{u}^2 D\bar{u}$. Therefore we obtain

$$
\int_{B_1} a_{ij} D_j v D_i \varphi + \tilde{f} v \varphi \le 0 \quad \text{where we set} \quad \tilde{f} = \frac{f}{\bar{u}}.
$$

In other words, $v$ is a nonnegative subsolution to some homogeneous equation. Choose $k = \|f\|_{L^q}$ if $f$ is not identically 0. Otherwise choose arbitrary $k > 0$ and then let $k \to 0^+$. Note

$$
\|\tilde{f}\|_{L^q(B_1)} \le 1.
$$

Thus Theorem 4.1 implies that for any $\tau \in (\theta, 1)$ and any $p > 0$

$$
\sup_{B_{\theta}} \bar{u}^{-p} \le C \int_{B_{\tau}} \bar{u}^{-p},
$$

that is,

$$
\inf_{B_{\theta}} \bar{u} \ge C \left( \int_{B_{\tau}} \bar{u}^{-p} dx \right)^{-\frac{1}{p}} = C \left( \int_{B_{\tau}} \bar{u}^{-p} \int_{B_{\tau}} \bar{u}^{p} \right)^{-\frac{1}{p}} \left( \int_{B_{\tau}} \bar{u}^{p} \right)^{\frac{1}{p}}
$$

where $C = C(n, q, p, \lambda, \Lambda, \tau, \theta) > 0$.

The key point is to show that there exists a $p_0 > 0$ such that

$$
\int_{B_{\tau}} \bar{u}^{-p_0} \cdot \int_{B_{\tau}} \bar{u}^{p_0} \le C(n, q, \lambda, \Lambda, \tau).
$$

We will show that for any $\tau < 1$ there holds

$$
(4.8) \qquad \int_{B_{\tau}} e^{p_0 |w|} \le C(n, q, \lambda, \Lambda, \tau)
$$

where $w = \log \bar{u} - \beta$ with $\beta = |B_{\tau}|^{-1} \int_{B_{\tau}} \log \bar{u}$.

We have two methods: