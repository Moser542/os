Step 1. There exist constants $M > 1$ and $0 < \sigma < 1$ such that

$$
(5.13) \qquad |G_M^-(u, \Omega) \cap Q_1| \ge 1 - \sigma.
$$

It is easy to see that $|u|_{L^\infty(\Omega)} \le 1$ implies that

$$
G_{c(n)}^-(u, \Omega) \cap Q_3 \ne \emptyset
$$

for some constant $c(n)$ depending only on $n$. We may apply Lemma 5.15 to $u/c(n)$ to get (5.13). By a simple adjustment we may assume that $\delta_0$, $M$, and $\sigma$ in Step 1 are the same as those in Lemma 5.15.

Step 2. We extend $f$ by 0 outside $B_{6\sqrt{n}}$ and set for $k = 0, 1, \dots$,

$$
A = A_{M^{k+1}}^-(u, \Omega) \cap Q_1,
$$

$$
B = (A_{M^k}^-(u, \Omega) \cap Q_1) \cup \{x \in Q_1 : m(f^n)(x) \ge (c_1 M^k)^n\},
$$

for some $c_1 > 0$ to be determined. Then there holds

$$
|A| \le \sigma |B|
$$

where $M > 1$ and $0 < \sigma < 1$ are as before. Recall that $m(f^n)$ denotes the maximal function of $f^n$.

We prove this by Lemma 5.9. It is easy to see that $|A| \le \sigma$ since we have $|G_{M^{k+1}}^-(u, \Omega) \cap Q_1| \ge |G_M^-(u, \Omega) \cap Q_1| \ge 1 - \sigma$ by Step 1.

Next we claim that if $Q = Q_r(x_0)$ is a cube in $Q_1$ such that

$$
(5.14) \qquad |A_{M^{k+1}}^-(u, \Omega) \cap Q| = |A \cap Q| > \sigma |Q|,
$$

then $\tilde{Q} \cap Q_1 \subset B$ for $\tilde{Q} = Q_{3r}(x_0)$.

We prove this by contradiction. Suppose not. We may take an $\tilde{x}$ such that

$$
\tilde{x} \in G_{M^k}^-(u, \Omega) \cap \tilde{Q} \quad \text{and} \quad \sup_{r>0} \frac{1}{|Q_r(\tilde{x})|} \int_{Q_r(\tilde{x})} |f|^n \le (c_1 M^k)^n.
$$

Consider the transformation

$$
x = x_0 + ry \quad \text{for } y \in Q_1 \text{ and } x \in Q = Q_r(x_0)
$$

and the function

$$
\tilde{u}(y) = \frac{1}{r^2 M^k} u(x).
$$

It is easy to check that $B_{6\sqrt{n}} \subset \tilde{\Omega}$, the image of $\Omega$ under the transformation above, and that $\tilde{u} \in S^+(\lambda, \Lambda, \tilde{f})$ in $B_{6\sqrt{n}}$ with

$$
\tilde{f}(y) = \frac{1}{M^k} f(x) \quad \text{for } y \in B_{6\sqrt{n}}.
$$

By the choice of $\tilde{x}$ we have

$$
G_1^-(\tilde{u}, \tilde{\Omega}) \cap Q_3 \ne \emptyset.
$$

Since $B_{6\sqrt{n}r}(x_0) \subset Q_{15\sqrt{n}r}(\tilde{x})$ there holds

$$
\|\tilde{f}\|_{L^n(B_{6\sqrt{n}})} \le \frac{1}{rM^k} \|f\|_{L^n(Q_{15\sqrt{n}r}(\tilde{x}))} \le c(n)c_1 \le \delta_0
$$