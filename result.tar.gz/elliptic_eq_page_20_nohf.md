where $M_r = \max_{\partial B_r} |v - u| \le \max_{\partial B_r} |v| + \max_{\partial B_r} |u| \le M + \max_{\partial B_r} |u|$ with $M = \max_{\partial B_R} |u|$. Hence we have for each fixed $x \ne 0$

$$
|w(x)| \le \frac{r^{n-2}}{|x|^{n-2}} M + \frac{1}{|x|^{n-2}} r^{n-2} \max_{\partial B_r} |u| \to 0 \quad \text{as } r \to 0,
$$

that is $w = 0$ in $B_R \setminus \{0\}$.

□

1.4. Maximum Principles

In this section we will use the maximum principle to derive the interior gradient estimate and the Harnack inequality.

THEOREM 1.29 Suppose $u \in C^2(B_1) \cap C(\bar{B}_1)$ is a subharmonic function in $B_1$; that is, $\Delta u \ge 0$. Then there holds

$$
\sup_{B_1} u \le \sup_{\partial B_1} u.
$$

PROOF: For $\varepsilon > 0$ we consider $u_\varepsilon(x) = u(x) + \varepsilon|x|^2$ in $B_1$. Then simple calculation yields

$$
\Delta u_{\varepsilon} = \Delta u + 2n\varepsilon \ge 2n\varepsilon > 0.
$$

It is easy to see, by a contradiction argument, that $u_\varepsilon$ cannot have an interior maximum, in particular,

$$
\sup_{B_1} u_{\varepsilon} \le \sup_{\partial B_1} u_{\varepsilon}.
$$

Therefore we have

$$
\sup_{B_1} u \le \sup_{B_1} u_{\varepsilon} \le \sup_{\partial B_1} u + \varepsilon.
$$

We finish the proof by letting $\varepsilon \to 0$.

□

REMARK 1.30. The result still holds if $B_1$ is replaced by any bounded domain.

The next result is the interior gradient estimate for harmonic functions. The method is due to Bernstein back in 1910.

PROPOSITION 1.31 Suppose $u$ is harmonic in $B_1$. Then there holds

$$
\sup_{B_{1/2}} |Du| \le c \sup_{\partial B_1} |u|
$$

where $c = c(n)$ is a positive constant. In particular, for any $\alpha \in [0, 1]$ there holds

$$
|u(x) - u(y)| \le c|x - y|^\alpha \sup_{\partial B_1} |u| \quad \text{for any } x, y \in B_{1/2}
$$

where $c = c(n, \alpha)$ is a positive constant.

PROOF: Direct calculation shows that

$$
\Delta(|Du|^2) = 2 \sum_{i,j=1}^{n} (D_{ij}u)^2 + 2 \sum_{i=1}^{n} D_i u D_i (\Delta u) = 2 \sum_{i,j=1}^{n} (D_{ij}u)^2
$$