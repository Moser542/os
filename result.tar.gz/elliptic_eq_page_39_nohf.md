Similarly, we can discuss the interior gradient bound. In this case, we just require the bound of $\sup_{\Omega} |u|$.

PROPOSITION 2.19 Suppose $u \in C^3(\Omega)$ satisfies

$$
a_{ij}(x)D_{ij}u + b_i(x)D_i u = f(x, u) \quad \text{in } \Omega
$$

for $a_{ij}, b_i \in C^1(\bar{\Omega})$ and $f \in C^1(\bar{\Omega} \times \mathbb{R})$. Then there holds for any compact subset $\Omega' \subset \Omega$

$$
\sup_{\Omega'} |Du| \le C
$$

where $C$ is a positive constant that depends only on $\lambda$, $\text{diam}(\Omega)$, $\text{dist}(\Omega', \partial\Omega)$, $|a_{ij}, b_i|_{C^1(\bar{\Omega})}$, $M = |u|_{L^\infty(\Omega)}$, and $|f|_{C^1(\bar{\Omega} \times [-M, M])}$.

PROOF: We need to take a cutoff function $\gamma \in C_0^\infty(\Omega)$ with $\gamma \ge 0$ and consider the auxiliary function with the following form:

$$
w = \gamma |Du|^2 + \alpha |u|^2 + e^{\beta x_1}.
$$

Set $v = \gamma |Du|^2$. Then we have for operator $L$ defined as before

$$
Lv = (L\gamma)|Du|^2 + \gamma L(|Du|^2) + 2a_{ij} D_i \gamma D_j |Du|^2.
$$

Recall an inequality in the proof of Proposition 2.18,

$$
L(|Du|^2) \ge \lambda |D^2 u|^2 - C |Du|^2 - C.
$$

Hence we have

$$
Lv \ge \lambda \gamma |D^2 u|^2 + 2a_{ij} D_k u D_i \gamma D_{kj} u - C |Du|^2 + (L\gamma)|Du|^2 - C.
$$

The Cauchy inequality implies for any $\varepsilon > 0$

$$
|2a_{ij} D_k u D_i \gamma D_{kj} u| \le \varepsilon |D\gamma|^2 |D^2 u|^2 + c(\varepsilon) |Du|^2.
$$

For the cutoff function $\gamma$, we require that

$$
|D\gamma|^2 \le C\gamma \quad \text{in } \Omega.
$$

Therefore we have by taking $\varepsilon > 0$ small

$$
\begin{aligned} Lv &\ge \lambda \gamma |D^2 u|^2 \left( 1 - \varepsilon \frac{|D\gamma|^2}{\gamma} \right) - C |Du|^2 - C \\ &\ge \frac{1}{2} \lambda \gamma |D^2 u|^2 - C |Du|^2 - C. \end{aligned}
$$

Now we may proceed as before.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAgCAIAAABhFeQrAAAAh0lEQVR4nO3WsQnAIBBA0TuxdATncQ6xchxLR7BzB6dxAGsvRUiIpLykSLjfafEQOVAkIngh9QYq7pm+LlprOec5J0c0xoQQgC5571mHPLLWLvcwxgCAUgoxAoDe++I+NctE9LV5EFdcccUV91+uvm+llGqtHFQptbzzMUYOt4eIzjn82H9yAygWdwFnjaquAAAAAElFTkSuQmCC)

In the rest of this section we use barrier functions to derive the boundary gradient estimates. We need to assume that the domain $\Omega$ satisfies the uniform exterior sphere property.

PROPOSITION 2.20 Suppose $u \in C^2(\Omega) \cap C(\bar{\Omega})$ satisfies

$$
a_{ij}(x)D_{ij}u + b_i(x)D_i u = f(x, u) \quad \text{in } \Omega
$$

for $a_{ij}, b_i \in C(\bar{\Omega})$ and $f \in C(\bar{\Omega} \times \mathbb{R})$. Then there holds

$$
|u(x) - u(x_0)| \le C |x - x_0| \quad \text{for any } x \in \Omega \text{ and } x_0 \in \partial\Omega
$$