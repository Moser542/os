# Maximum Principles

## 2.1. Guide

In this chapter we discuss maximum principles and their applications. Two kinds of maximum principles are discussed. One is due to Hopf and the other to Alexandroff. The former gives the estimates of solutions in terms of the $L^\infty$-norm of the nonhomogeneous terms, while the latter gives the estimates in terms of the $L^n$-norm. Applications include various a priori estimates and the moving plane method.

Most of the statements in Section 2.2 are rather simple. One probably needs to go over Theorem 2.11 and Proposition 2.13. Section 2.3 is often the starting point of the a priori estimates. Section 2.4 can be omitted in the first reading, as we will look at it again in Section 5.2. The moving plane method explained in Section 2.6 has many recent applications. We choose a very simple example to illustrate such a method. The result goes back to Gidas-Ni-Nirenberg, but the proof contains some recent observations in the paper [1]. The classical paper of Gilbarg-Serrin [7] may be a very good supplement to this chapter. It may also be a good idea to assume the Harnack inequality of Krylov-Safanov in Section 5.3 and to ask students to improve some of the results in the paper [7].

## 2.2. Strong Maximum Principle

Suppose $\Omega$ is a bounded and connected domain in $\mathbb{R}^n$. Consider the operator $L$ in $\Omega$,

$$
Lu \equiv a_{ij}(x)D_{ij}u + b_i(x)D_i u + c(x)u
$$

for $u \in C^2(\Omega) \cap C(\bar{\Omega})$. We always assume that $a_{ij}$, $b_i$, and $c$ are continuous and hence bounded in $\bar{\Omega}$ and that $L$ is uniformly elliptic in $\Omega$ in the following sense:

$$
a_{ij}(x)\xi_i\xi_j \ge \lambda|\xi|^2 \quad \text{for any } x \in \Omega \text{ and any } \xi \in \mathbb{R}^n
$$

for some positive constant $\lambda$.

LEMMA 2.1 Suppose $u \in C^2(\Omega) \cap C(\bar{\Omega})$ satisfies $Lu > 0$ in $\Omega$ with $c(x) \le 0$ in $\Omega$. If $u$ has a nonnegative maximum in $\bar{\Omega}$, then $u$ cannot attain this maximum in $\Omega$.

PROOF: Suppose $u$ attains its nonnegative maximum of $\bar{\Omega}$ in $x_0 \in \Omega$. Then $D_i u(x_0) = 0$ and the matrix $B = (D_{ij}(x_0))$ is seminegative definite. By the ellipticity condition the matrix $A = (a_{ij}(x_0))$ is positive definite. Hence the matrix $AB$ is seminegative definite with a nonpositive trace, that is, $a_{ij}(x_0)D_{ij}u(x_0) \le 0$. This implies $Lu(x_0) \le 0$, which is a contradiction. $\square$