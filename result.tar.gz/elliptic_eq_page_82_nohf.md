(ii) If $u$ is a supersolution and $\Phi' \le 0$, then $v = \Phi(u)$ is a subsolution provided $v \in H_{\text{loc}}^1(B_1)$.

REMARK 4.7. If $u$ is a subsolution, then $(u-k)^+$ is also a subsolution, where $(u-k)^+ = \max\{0, u-k\}$. In this case $\Phi(s) = (s-k)^+$.

PROOF: We prove by direct computation.

(i) Assume first $\Phi \in C_{\text{loc}}^2(\mathbb{R})$. Then

$$
\Phi'(s) \ge 0, \quad \Phi''(s) \ge 0.
$$

Consider $\varphi \in C_0^1(B_1)$ with $\varphi \ge 0$. Direct calculation yields

$$
\begin{aligned} \int_{B_1} a_{ij} D_i v D_j \varphi &= \int_{B_1} a_{ij} \Phi'(u) D_i u D_j \varphi \\ &= \int_{B_1} a_{ij} D_i u D_j (\Phi'(u)\varphi) - \int_{B_1} (a_{ij} D_i u D_j u) \varphi \Phi''(u) \le 0, \end{aligned}
$$

where $\Phi'(u)\varphi \in H_0^1(B_1)$ is nonnegative. In general, set $\Phi_\varepsilon(s) = \rho_\varepsilon * \Phi(s)$ with $\rho_\varepsilon$ as the standard mollifier. Then $\Phi'_\varepsilon(s) = \rho_\varepsilon * \Phi'(s) \ge 0$ and $\Phi''_\varepsilon(s) \ge 0$. Hence $\Phi_\varepsilon(u)$ is a subsolution by what we just proved. Note $\Phi'_\varepsilon(s) \to \Phi'(s)$ a.e. as $\varepsilon \to 0^+$. Hence the Lebesgue dominant convergence theorem implies the result.

(ii) This is proved similarly.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAeCAIAAABfZYL2AAAAx0lEQVR4nO2VMQ6EIBBFP6wJhbHFg1hzIA/ieTyBR/AC0hFao52hYbYgLpstRTbZDa8imeTz82FmGBEhAzyHaNGN0Im1VgjxSKbrunVdq9cFx3E45wBIKZumuWDROWetned5HMfoV2sNQClFCfR9D2AYhphv+MhSypRU27YNUlne7Su69zb0T+WAd7835pDLr/e+5BAofYEyH07+YD7s+56iuG1bOFQfhWmaOOecX8mHiLz3AOq6jvvYGCOESDELgDGmlFqW5QmQO8RjICCiEQAAAABJRU5ErkJggg==)

We need the following Poincaré-Sobolev inequality:

LEMMA 4.8 For any $\varepsilon > 0$ there exists a $C = C(\varepsilon, n)$ such that for $u \in H^1(B_1)$ with

$$
|\{x \in B_1; u = 0\}| \ge \varepsilon|B_1| \quad \text{there holds} \quad \int_{B_1} u^2 \le C \int_{B_1} |Du|^2.
$$

PROOF: Suppose not. Then there exists a sequence $\{u_m\} \subset H^1(B_1)$ such that

$$
|\{x \in B_1; u_m = 0\}| \ge \varepsilon|B_1|, \quad \int_{B_1} u_m^2 = 1, \quad \int_{B_1} |Du_m|^2 \to 0 \text{ as } m \to \infty.
$$

Hence we may assume $u_m \to u_0 \in H^1(B_1)$ strongly in $L^2(B_1)$ and weakly in $H^1(B_1)$. Clearly $u_0$ is a nonzero constant. So

$$
\begin{aligned} 0 = \lim_{m \to \infty} \int_{B_1} |u_m - u_0|^2 &\ge \lim_{m \to \infty} \int_{\{u_m=0\}} |u_m - u_0|^2 \\ &\ge |u_0|^2 \inf_m |\{u_m = 0\}| > 0. \end{aligned}
$$

Contradiction.

![](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB0AAAAeCAIAAABfZYL2AAAAtklEQVR4nO2VMQ7DIAxFTYGVLd64SZbcJgvXyA04TE6EUJaEHdHBUpukndwStRJvQrL0MB+QRSkFKnCrIW3eJ2XHOI7yY4wx3nu13yOllHPWWltrhRCMLkMIKaVpmtRrbZ7nYRh4p1+WBRFjjId86S0jIk8KAF3XkafKvV3l/eKf/qsc4NTvr+dwlbflQLQciJYDUTeHdV3Zum3baPFmbvZ9L6XkeXPOAKCUOnhp6j3KPBDROXcHZoVYm3JNKEwAAAAASUVORK5CYII=)