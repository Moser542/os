PROOF: Suppose $u$ is a harmonic function in $\Omega$. For fixed $x \in \Omega$, take $B_{2R}(x) \subset \Omega$ and $h \in \mathbb{R}^n$ with $|h| \le R$. We have by Taylor expansion

$$
u(x + h) = u(x) + \sum_{i=1}^{m-1} \frac{1}{i!} \left[ \left( h_1 \frac{\partial}{\partial x_1} + \cdots + h_n \frac{\partial}{\partial x_n} \right)^i u \right] (x) + R_m(h)
$$

where

$$
R_m(h) = \frac{1}{m!} \left[ \left( h_1 \frac{\partial}{\partial x_1} + \cdots + h_n \frac{\partial}{\partial x_n} \right)^m u \right] (x_1 + \theta h_1, \dots, x_n + \theta h_n)
$$

for some $\theta \in (0, 1)$. Note $x + h \in B_R(x)$ for $|h| < R$. Hence by Proposition 1.13 we obtain

$$
|R_m(h)| \le \frac{1}{m!} |h|^m \cdot n^m \cdot \frac{n^m e^{m-1} m!}{R^m} \max_{\bar{B}_{2R}} |u| \le \left( \frac{|h| n^2 e}{R} \right)^m \max_{\bar{B}_{2R}} |u|.
$$

Then for any $h$ with $|h|n^2e < \frac{R}{2}$ there holds $R_m(h) \to 0$ as $m \to \infty$. $\square$

Next we prove the Harnack inequality.

THEOREM 1.15 Suppose $u$ is harmonic in $\Omega$. Then for any compact subset $K$ of $\Omega$ there exists a positive constant $C = (\Omega, K)$ such that if $u \ge 0$ in $\Omega$, then

$$
\frac{1}{C}u(y) \le u(x) \le Cu(y) \quad \text{for any } x, y \in K.
$$

PROOF: By mean value property, we can prove if $B_{4R}(x_0) \subset \Omega$, then

$$
\frac{1}{c}u(y) \le u(x) \le cu(y) \quad \text{for any } x, y \in B_R(x_0)
$$

where $c$ is a positive constant depending only on $n$. Now for the given compact subset $K$, take $x_1, \dots, x_N \in K$ such that $\{B_R(x_i)\}$ covers $K$ with $4R < \text{dist}(K, \partial\Omega)$. Then we can choose $C = c^N$. $\square$

We finish this section by proving a result, originally due to Weyl. Suppose $u$ is harmonic in $\Omega$. Then integrating by parts we have

$$
\int_{\Omega} u \Delta \varphi = 0 \quad \text{for any } \varphi \in C_0^2(\Omega).
$$

The converse is also true.

THEOREM 1.16 Suppose $u \in C(\Omega)$ satisfies

$$
(1.1) \qquad \int_{\Omega} u \Delta \varphi = 0 \quad \text{for any } \varphi \in C_0^2(\Omega).
$$

Then $u$ is harmonic in $\Omega$.

PROOF: We claim for any $B_r(x) \subset \Omega$ there holds

$$
(1.2) \qquad r \int_{\partial B_r(x)} u(y) dS_y = n \int_{B_r(x)} u(y) dy.
$$